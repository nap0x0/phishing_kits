/*******************************************************/
/* 2014-07-31 Default.js v1.3.9.7  
/*******************************************************/


/*PLUGINS------------------------------------------*/
/* Metadata - jQuery plugin for parsing metadata from elements Copyright (c) 2006 John Resig, Yehuda Katz, J�örn Zaefferer, Paul McLanahan Dual licensed under the MIT and GPL licenses:*/ 
(function($){$.extend({metadata:{defaults:{type:"class",name:"metadata",cre:/({.*})/,single:"metadata"},setType:function(type,name){this.defaults.type=type;this.defaults.name=name},get:function(elem,opts){var settings=$.extend({},this.defaults,opts);if(!settings.single.length){settings.single="metadata"}var data=$.data(elem,settings.single);if(data){return data}data="{}";var getData=function(data){if(typeof data!="string"){return data}if(data.indexOf("{")<0){data=eval("("+data+")")}};var getObject=function(data){if(typeof data!="string"){return data}data=eval("("+data+")");return data};if(settings.type=="html5"){var object={};$(elem.attributes).each(function(){var name=this.nodeName;if(name.match(/^data-/)){name=name.replace(/^data-/,"")}else{return true}object[name]=getObject(this.nodeValue)})}else{if(settings.type=="class"){var m=settings.cre.exec(elem.className);if(m){data=m[1]}}else{if(settings.type=="elem"){if(!elem.getElementsByTagName){return}var e=elem.getElementsByTagName(settings.name);if(e.length){data=$.trim(e[0].innerHTML)}}else{if(elem.getAttribute!=undefined){var attr=elem.getAttribute(settings.name);if(attr){data=attr}}}}object=getObject(data.indexOf("{")<0?"{"+data+"}":data)}$.data(elem,settings.single,object);return object}}});$.fn.metadata=function(opts){return $.metadata.get(this[0],opts)}})(jQuery);
/*! http://mths.be/placeholder v2.0.8 by @mathias modified 05-28-2014 */
;(function(i,k,f){var b=Object.prototype.toString.call(i.operamini)=="[object OperaMini]";var a="placeholder" in k.createElement("input")&&!b;var g="placeholder" in k.createElement("textarea")&&!b;var l=f.fn;var e=f.valHooks;var c=f.propHooks;var n;var m;if(a&&g){m=l.placeholder=function(){return this};m.input=m.textarea=true}else{m=l.placeholder=function(){var p=this;p.filter((a?"textarea":":input")+"[placeholder]").not(".placeholder").bind({"focus.placeholder":d,"blur.placeholder":h}).data("placeholder-enabled",true).trigger("blur.placeholder");return p};m.input=a;m.textarea=g;n={get:function(q){var p=f(q);var r=p.data("placeholder-password");if(r){return r[0].value}return p.data("placeholder-enabled")&&p.hasClass("placeholder")?"":q.value},set:function(q,s){var p=f(q);var r=p.data("placeholder-password");if(r){return r[0].value=s}if(!p.data("placeholder-enabled")){return q.value=s}if(s==""){q.value=s;if(q!=o()){h.call(q)}}else{if(p.hasClass("placeholder")){d.call(q,true,s)||(q.value=s)}else{q.value=s}}return p}};if(!a){e.input=n;c.value=n}if(!g){e.textarea=n;c.value=n}f(function(){f(k).delegate("form","submit.placeholder",function(){var p=f(".placeholder",this).each(d);setTimeout(function(){p.each(h)},10)})});f(i).bind("beforeunload.placeholder",function(){f(".placeholder").each(function(){this.value=""})})}function j(q){var p={};var r=/^jQuery\d+$/;f.each(q.attributes,function(t,s){if(s.specified&&!r.test(s.name)){p[s.name]=s.value}});return p}function d(q,r){var p=this;var s=f(p);if(p.value==s.attr("placeholder")&&s.hasClass("placeholder")){if(s.data("placeholder-password")){s=s.hide().next(":input").show();if(q===true){return s[0].value=r}s.focus()}else{p.value="";s.removeClass("placeholder");p==o()&&p.select()}}}function h(){var t;var p=this;var s=f(p);var r=this.id;if(p.value==""){if(p.type=="password"){if(!s.data("placeholder-textinput")){try{t=s.clone().attr({type:"text"})}catch(q){t=f("<input>").attr(f.extend(j(this),{type:"text"}))}t.removeAttr("name").removeAttr("aria-describedby").removeClass("required").removeClass("d-help").data({"placeholder-password":s,"placeholder-id":r}).bind("focus.placeholder",d);s.data({"placeholder-textinput":t,"placeholder-id":r}).before(t)}s=s.hide().prev().show()}s.addClass("placeholder");s[0].value=s.attr("placeholder")}else{s.removeClass("placeholder")}}function o(){try{return k.activeElement}catch(p){}}}(this,document,jQuery));
/* CSS Browser Selector v0.4.0 (Nov 02, 2010) Rafael Lima (http://rafael.adm.br) http://rafael.adm.br/css_browser_selector License: http://creativecommons.org/licenses/by/2.5/Contributors: http://rafael.adm.br/css_browser_selector#contributors	*/
$.css_browser_selector=function(n){var a=n.toLowerCase(),i=function(b){return a.indexOf(b)>-1},j="gecko",l="webkit",p="safari",d="opera",e="mobile",f=document.documentElement,k=[(!(/opera|webtv/i.test(a))&&/msie\s(\d)/.test(a))?("ie ie"+RegExp.$1):i("firefox/2")?j+" ff2":i("firefox/3.5")?j+" ff3 ff3_5":i("firefox/3.6")?j+" ff3 ff3_6":i("firefox/3")?j+" ff3":i("gecko/")?j:i("opera")?d+(/version\/(\d+)/.test(a)?" "+d+RegExp.$1:(/opera(\s|\/)(\d+)/.test(a)?" "+d+RegExp.$2:"")):i("konqueror")?"konqueror":i("blackberry")?e+" blackberry":i("android")?e+" android":i("chrome")?l+" chrome":i("iron")?l+" iron":i("applewebkit/")?l+" "+p+(/version\/(\d+)/.test(a)?" "+p+RegExp.$1:""):i("mozilla/")?j:"",i("j2me")?e+" j2me":i("iphone")?e+" iphone":i("ipod")?e+" ipod":i("ipad")?e+" ipad":i("mac")?"mac":i("darwin")?"mac":i("webtv")?"webtv":i("win")?"win"+(i("windows nt 6.0")?" vista":""):i("freebsd")?"freebsd":(i("x11")||i("linux"))?"linux":"","js"],c=k.join(" ");f.className+=" "+c;return c};
/* Equal heights plugin Copyright (c) 2012 Ewen Elder Dual licensed under the MIT and GPL licenses @author: Ewen Elder <glomainn at yah0o d0t c0 dot uk> <ewen at jainaewen d0t-com> @version: 2.0*/
"use strict";(function(e){e.equalHeightColumns={version:2};e.equalHeightColumns.defaults={speed:0,height:0,minHeight:0,maxHeight:0};e.equalHeightColumns.defaults.resize=function(){var t=e(this).data("equalHeightColumns.options"),n=+t.height,r;if(!n){e(this).each(function(){r=e(this).height();e(this).css("height","auto");if(e(this).height()>n){n=e(this).height()}e(this).height(r)})}n=t.minHeight&&n<t.minHeight?t.minHeight:n;n=+t.maxHeight&&n>+t.maxHeight?+t.maxHeight:n;e(this).animate({height:n},+t.speed)};e.equalHeightColumns.defaults.actions=function(t,n,r){var i=e(this).data("equalHeightColumns.options"),s;switch(t){case"option":if(i&&typeof i[n]!=="undefined"){if(typeof r!=="undefined"){i[n]=r;e(this).data("equalHeightColumns.options",i)}else{return i[n]}}return false;break;case"destroy":e(this).removeData("equalHeightColumns.options").each(function(){s=e(this).data("equalHeightColumns.originalHeight");if(s){e(this).height(s)}});return false;break;case"refresh":return true;break;default:return false;break}};e.fn.equalHeightColumns=function(t,n,r){var i=typeof t==="string"?t:false,s,o,u;if(i){t=e.extend({},e.equalHeightColumns.defaults,e(this).data("equalHeightColumns.options"));s=e.proxy(t.actions,this);if(i==="option"&&typeof r==="undefined"){return s(i,n)}else if(s(i,n,r)===false){return e(this)}}t=e.extend({},e.equalHeightColumns.defaults,t);e(this).data("equalHeightColumns.options",t);e(this).each(function(){if(typeof e(this).data("equalHeightColumns.originalHeight")==="undefined"){e(this).data("equalHeightColumns.originalHeight",e(this).height())}});s=e.proxy(t.resize,this);s();return e(this)}})($)

/* Modernizr 2.8.2 (Custom Build) | MIT & BSD
 * Build: http://modernizr.com/download/#-fontface-backgroundsize-borderimage-borderradius-boxshadow-flexbox-flexboxlegacy-hsla-multiplebgs-opacity-rgba-textshadow-cssanimations-csscolumns-generatedcontent-cssgradients-cssreflections-csstransforms-csstransforms3d-csstransitions-applicationcache-canvas-canvastext-draganddrop-hashchange-history-audio-video-indexeddb-input-inputtypes-localstorage-postmessage-sessionstorage-websockets-websqldatabase-webworkers-geolocation-inlinesvg-smil-svg-svgclippaths-touch-webgl-shiv-cssclasses-teststyles-testprop-testallprops-hasevent-prefixes-domprefixes-load
 Use only for standards site - otherwise keep commented*/
/*;window.Modernizr=function(a,b,c){function C(a){j.cssText=a}function D(a,b){return C(n.join(a+";")+(b||""))}function E(a,b){return typeof a===b}function F(a,b){return!!~(""+a).indexOf(b)}function G(a,b){for(var d in a){var e=a[d];if(!F(e,"-")&&j[e]!==c)return b=="pfx"?e:!0}return!1}function H(a,b,d){for(var e in a){var f=b[a[e]];if(f!==c)return d===!1?a[e]:E(f,"function")?f.bind(d||b):f}return!1}function I(a,b,c){var d=a.charAt(0).toUpperCase()+a.slice(1),e=(a+" "+p.join(d+" ")+d).split(" ");return E(b,"string")||E(b,"undefined")?G(e,b):(e=(a+" "+q.join(d+" ")+d).split(" "),H(e,b,c))}function J(){e.input=function(c){for(var d=0,e=c.length;d<e;d++)u[c[d]]=c[d]in k;return u.list&&(u.list=!!b.createElement("datalist")&&!!a.HTMLDataListElement),u}("autocomplete autofocus list placeholder max min multiple pattern required step".split(" ")),e.inputtypes=function(a){for(var d=0,e,f,h,i=a.length;d<i;d++)k.setAttribute("type",f=a[d]),e=k.type!=="text",e&&(k.value=l,k.style.cssText="position:absolute;visibility:hidden;",/^range$/.test(f)&&k.style.WebkitAppearance!==c?(g.appendChild(k),h=b.defaultView,e=h.getComputedStyle&&h.getComputedStyle(k,null).WebkitAppearance!=="textfield"&&k.offsetHeight!==0,g.removeChild(k)):/^(search|tel)$/.test(f)||(/^(url|email)$/.test(f)?e=k.checkValidity&&k.checkValidity()===!1:e=k.value!=l)),t[a[d]]=!!e;return t}("search tel url email datetime date month week time datetime-local number range color".split(" "))}var d="2.8.2",e={},f=!0,g=b.documentElement,h="modernizr",i=b.createElement(h),j=i.style,k=b.createElement("input"),l=":)",m={}.toString,n=" -webkit- -moz- -o- -ms- ".split(" "),o="Webkit Moz O ms",p=o.split(" "),q=o.toLowerCase().split(" "),r={svg:"http://www.w3.org/2000/svg"},s={},t={},u={},v=[],w=v.slice,x,y=function(a,c,d,e){var f,i,j,k,l=b.createElement("div"),m=b.body,n=m||b.createElement("body");if(parseInt(d,10))while(d--)j=b.createElement("div"),j.id=e?e[d]:h+(d+1),l.appendChild(j);return f=["&#173;",'<style id="s',h,'">',a,"</style>"].join(""),l.id=h,(m?l:n).innerHTML+=f,n.appendChild(l),m||(n.style.background="",n.style.overflow="hidden",k=g.style.overflow,g.style.overflow="hidden",g.appendChild(n)),i=c(l,a),m?l.parentNode.removeChild(l):(n.parentNode.removeChild(n),g.style.overflow=k),!!i},z=function(){function d(d,e){e=e||b.createElement(a[d]||"div"),d="on"+d;var f=d in e;return f||(e.setAttribute||(e=b.createElement("div")),e.setAttribute&&e.removeAttribute&&(e.setAttribute(d,""),f=E(e[d],"function"),E(e[d],"undefined")||(e[d]=c),e.removeAttribute(d))),e=null,f}var a={select:"input",change:"input",submit:"form",reset:"form",error:"img",load:"img",abort:"img"};return d}(),A={}.hasOwnProperty,B;!E(A,"undefined")&&!E(A.call,"undefined")?B=function(a,b){return A.call(a,b)}:B=function(a,b){return b in a&&E(a.constructor.prototype[b],"undefined")},Function.prototype.bind||(Function.prototype.bind=function(b){var c=this;if(typeof c!="function")throw new TypeError;var d=w.call(arguments,1),e=function(){if(this instanceof e){var a=function(){};a.prototype=c.prototype;var f=new a,g=c.apply(f,d.concat(w.call(arguments)));return Object(g)===g?g:f}return c.apply(b,d.concat(w.call(arguments)))};return e}),s.flexbox=function(){return I("flexWrap")},s.flexboxlegacy=function(){return I("boxDirection")},s.canvas=function(){var a=b.createElement("canvas");return!!a.getContext&&!!a.getContext("2d")},s.canvastext=function(){return!!e.canvas&&!!E(b.createElement("canvas").getContext("2d").fillText,"function")},s.webgl=function(){return!!a.WebGLRenderingContext},s.touch=function(){var c;return"ontouchstart"in a||a.DocumentTouch&&b instanceof DocumentTouch?c=!0:y(["@media (",n.join("touch-enabled),("),h,")","{#modernizr{top:9px;position:absolute}}"].join(""),function(a){c=a.offsetTop===9}),c},s.geolocation=function(){return"geolocation"in navigator},s.postmessage=function(){return!!a.postMessage},s.websqldatabase=function(){return!!a.openDatabase},s.indexedDB=function(){return!!I("indexedDB",a)},s.hashchange=function(){return z("hashchange",a)&&(b.documentMode===c||b.documentMode>7)},s.history=function(){return!!a.history&&!!history.pushState},s.draganddrop=function(){var a=b.createElement("div");return"draggable"in a||"ondragstart"in a&&"ondrop"in a},s.websockets=function(){return"WebSocket"in a||"MozWebSocket"in a},s.rgba=function(){return C("background-color:rgba(150,255,150,.5)"),F(j.backgroundColor,"rgba")},s.hsla=function(){return C("background-color:hsla(120,40%,100%,.5)"),F(j.backgroundColor,"rgba")||F(j.backgroundColor,"hsla")},s.multiplebgs=function(){return C("background:url(https://),url(https://),red url(https://)"),/(url\s*\(.*?){3}/.test(j.background)},s.backgroundsize=function(){return I("backgroundSize")},s.borderimage=function(){return I("borderImage")},s.borderradius=function(){return I("borderRadius")},s.boxshadow=function(){return I("boxShadow")},s.textshadow=function(){return b.createElement("div").style.textShadow===""},s.opacity=function(){return D("opacity:.55"),/^0.55$/.test(j.opacity)},s.cssanimations=function(){return I("animationName")},s.csscolumns=function(){return I("columnCount")},s.cssgradients=function(){var a="background-image:",b="gradient(linear,left top,right bottom,from(#9f9),to(white));",c="linear-gradient(left top,#9f9, white);";return C((a+"-webkit- ".split(" ").join(b+a)+n.join(c+a)).slice(0,-a.length)),F(j.backgroundImage,"gradient")},s.cssreflections=function(){return I("boxReflect")},s.csstransforms=function(){return!!I("transform")},s.csstransforms3d=function(){var a=!!I("perspective");return a&&"webkitPerspective"in g.style&&y("@media (transform-3d),(-webkit-transform-3d){#modernizr{left:9px;position:absolute;height:3px;}}",function(b,c){a=b.offsetLeft===9&&b.offsetHeight===3}),a},s.csstransitions=function(){return I("transition")},s.fontface=function(){var a;return y('@font-face {font-family:"font";src:url("https://")}',function(c,d){var e=b.getElementById("smodernizr"),f=e.sheet||e.styleSheet,g=f?f.cssRules&&f.cssRules[0]?f.cssRules[0].cssText:f.cssText||"":"";a=/src/i.test(g)&&g.indexOf(d.split(" ")[0])===0}),a},s.generatedcontent=function(){var a;return y(["#",h,"{font:0/0 a}#",h,':after{content:"',l,'";visibility:hidden;font:3px/1 a}'].join(""),function(b){a=b.offsetHeight>=3}),a},s.video=function(){var a=b.createElement("video"),c=!1;try{if(c=!!a.canPlayType)c=new Boolean(c),c.ogg=a.canPlayType('video/ogg; codecs="theora"').replace(/^no$/,""),c.h264=a.canPlayType('video/mp4; codecs="avc1.42E01E"').replace(/^no$/,""),c.webm=a.canPlayType('video/webm; codecs="vp8, vorbis"').replace(/^no$/,"")}catch(d){}return c},s.audio=function(){var a=b.createElement("audio"),c=!1;try{if(c=!!a.canPlayType)c=new Boolean(c),c.ogg=a.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),c.mp3=a.canPlayType("audio/mpeg;").replace(/^no$/,""),c.wav=a.canPlayType('audio/wav; codecs="1"').replace(/^no$/,""),c.m4a=(a.canPlayType("audio/x-m4a;")||a.canPlayType("audio/aac;")).replace(/^no$/,"")}catch(d){}return c},s.localstorage=function(){try{return localStorage.setItem(h,h),localStorage.removeItem(h),!0}catch(a){return!1}},s.sessionstorage=function(){try{return sessionStorage.setItem(h,h),sessionStorage.removeItem(h),!0}catch(a){return!1}},s.webworkers=function(){return!!a.Worker},s.applicationcache=function(){return!!a.applicationCache},s.svg=function(){return!!b.createElementNS&&!!b.createElementNS(r.svg,"svg").createSVGRect},s.inlinesvg=function(){var a=b.createElement("div");return a.innerHTML="<svg/>",(a.firstChild&&a.firstChild.namespaceURI)==r.svg},s.smil=function(){return!!b.createElementNS&&/SVGAnimate/.test(m.call(b.createElementNS(r.svg,"animate")))},s.svgclippaths=function(){return!!b.createElementNS&&/SVGClipPath/.test(m.call(b.createElementNS(r.svg,"clipPath")))};for(var K in s)B(s,K)&&(x=K.toLowerCase(),e[x]=s[K](),v.push((e[x]?"":"no-")+x));return e.input||J(),e.addTest=function(a,b){if(typeof a=="object")for(var d in a)B(a,d)&&e.addTest(d,a[d]);else{a=a.toLowerCase();if(e[a]!==c)return e;b=typeof b=="function"?b():b,typeof f!="undefined"&&f&&(g.className+=" "+(b?"":"no-")+a),e[a]=b}return e},C(""),i=k=null,function(a,b){function l(a,b){var c=a.createElement("p"),d=a.getElementsByTagName("head")[0]||a.documentElement;return c.innerHTML="x<style>"+b+"</style>",d.insertBefore(c.lastChild,d.firstChild)}function m(){var a=s.elements;return typeof a=="string"?a.split(" "):a}function n(a){var b=j[a[h]];return b||(b={},i++,a[h]=i,j[i]=b),b}function o(a,c,d){c||(c=b);if(k)return c.createElement(a);d||(d=n(c));var g;return d.cache[a]?g=d.cache[a].cloneNode():f.test(a)?g=(d.cache[a]=d.createElem(a)).cloneNode():g=d.createElem(a),g.canHaveChildren&&!e.test(a)&&!g.tagUrn?d.frag.appendChild(g):g}function p(a,c){a||(a=b);if(k)return a.createDocumentFragment();c=c||n(a);var d=c.frag.cloneNode(),e=0,f=m(),g=f.length;for(;e<g;e++)d.createElement(f[e]);return d}function q(a,b){b.cache||(b.cache={},b.createElem=a.createElement,b.createFrag=a.createDocumentFragment,b.frag=b.createFrag()),a.createElement=function(c){return s.shivMethods?o(c,a,b):b.createElem(c)},a.createDocumentFragment=Function("h,f","return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&("+m().join().replace(/[\w\-]+/g,function(a){return b.createElem(a),b.frag.createElement(a),'c("'+a+'")'})+");return n}")(s,b.frag)}function r(a){a||(a=b);var c=n(a);return s.shivCSS&&!g&&!c.hasCSS&&(c.hasCSS=!!l(a,"article,aside,dialog,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}mark{background:#FF0;color:#000}template{display:none}")),k||q(a,c),a}var c="3.7.0",d=a.html5||{},e=/^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,f=/^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i,g,h="_html5shiv",i=0,j={},k;(function(){try{var a=b.createElement("a");a.innerHTML="<xyz></xyz>",g="hidden"in a,k=a.childNodes.length==1||function(){b.createElement("a");var a=b.createDocumentFragment();return typeof a.cloneNode=="undefined"||typeof a.createDocumentFragment=="undefined"||typeof a.createElement=="undefined"}()}catch(c){g=!0,k=!0}})();var s={elements:d.elements||"abbr article aside audio bdi canvas data datalist details dialog figcaption figure footer header hgroup main mark meter nav output progress section summary template time video",version:c,shivCSS:d.shivCSS!==!1,supportsUnknownElements:k,shivMethods:d.shivMethods!==!1,type:"default",shivDocument:r,createElement:o,createDocumentFragment:p};a.html5=s,r(b)}(this,b),e._version=d,e._prefixes=n,e._domPrefixes=q,e._cssomPrefixes=p,e.hasEvent=z,e.testProp=function(a){return G([a])},e.testAllProps=I,e.testStyles=y,g.className=g.className.replace(/(^|\s)no-js(\s|$)/,"$1$2")+(f?" js "+v.join(" "):""),e}(this,this.document),function(a,b,c){function d(a){return"[object Function]"==o.call(a)}function e(a){return"string"==typeof a}function f(){}function g(a){return!a||"loaded"==a||"complete"==a||"uninitialized"==a}function h(){var a=p.shift();q=1,a?a.t?m(function(){("c"==a.t?B.injectCss:B.injectJs)(a.s,0,a.a,a.x,a.e,1)},0):(a(),h()):q=0}function i(a,c,d,e,f,i,j){function k(b){if(!o&&g(l.readyState)&&(u.r=o=1,!q&&h(),l.onload=l.onreadystatechange=null,b)){"img"!=a&&m(function(){t.removeChild(l)},50);for(var d in y[c])y[c].hasOwnProperty(d)&&y[c][d].onload()}}var j=j||B.errorTimeout,l=b.createElement(a),o=0,r=0,u={t:d,s:c,e:f,a:i,x:j};1===y[c]&&(r=1,y[c]=[]),"object"==a?l.data=c:(l.src=c,l.type=a),l.width=l.height="0",l.onerror=l.onload=l.onreadystatechange=function(){k.call(this,r)},p.splice(e,0,u),"img"!=a&&(r||2===y[c]?(t.insertBefore(l,s?null:n),m(k,j)):y[c].push(l))}function j(a,b,c,d,f){return q=0,b=b||"j",e(a)?i("c"==b?v:u,a,b,this.i++,c,d,f):(p.splice(this.i++,0,a),1==p.length&&h()),this}function k(){var a=B;return a.loader={load:j,i:0},a}var l=b.documentElement,m=a.setTimeout,n=b.getElementsByTagName("script")[0],o={}.toString,p=[],q=0,r="MozAppearance"in l.style,s=r&&!!b.createRange().compareNode,t=s?l:n.parentNode,l=a.opera&&"[object Opera]"==o.call(a.opera),l=!!b.attachEvent&&!l,u=r?"object":l?"script":"img",v=l?"script":u,w=Array.isArray||function(a){return"[object Array]"==o.call(a)},x=[],y={},z={timeout:function(a,b){return b.length&&(a.timeout=b[0]),a}},A,B;B=function(a){function b(a){var a=a.split("!"),b=x.length,c=a.pop(),d=a.length,c={url:c,origUrl:c,prefixes:a},e,f,g;for(f=0;f<d;f++)g=a[f].split("="),(e=z[g.shift()])&&(c=e(c,g));for(f=0;f<b;f++)c=x[f](c);return c}function g(a,e,f,g,h){var i=b(a),j=i.autoCallback;i.url.split(".").pop().split("?").shift(),i.bypass||(e&&(e=d(e)?e:e[a]||e[g]||e[a.split("/").pop().split("?")[0]]),i.instead?i.instead(a,e,f,g,h):(y[i.url]?i.noexec=!0:y[i.url]=1,f.load(i.url,i.forceCSS||!i.forceJS&&"css"==i.url.split(".").pop().split("?").shift()?"c":c,i.noexec,i.attrs,i.timeout),(d(e)||d(j))&&f.load(function(){k(),e&&e(i.origUrl,h,g),j&&j(i.origUrl,h,g),y[i.url]=2})))}function h(a,b){function c(a,c){if(a){if(e(a))c||(j=function(){var a=[].slice.call(arguments);k.apply(this,a),l()}),g(a,j,b,0,h);else if(Object(a)===a)for(n in m=function(){var b=0,c;for(c in a)a.hasOwnProperty(c)&&b++;return b}(),a)a.hasOwnProperty(n)&&(!c&&!--m&&(d(j)?j=function(){var a=[].slice.call(arguments);k.apply(this,a),l()}:j[n]=function(a){return function(){var b=[].slice.call(arguments);a&&a.apply(this,b),l()}}(k[n])),g(a[n],j,b,n,h))}else!c&&l()}var h=!!a.test,i=a.load||a.both,j=a.callback||f,k=j,l=a.complete||f,m,n;c(h?a.yep:a.nope,!!i),i&&c(i)}var i,j,l=this.yepnope.loader;if(e(a))g(a,0,l,0);else if(w(a))for(i=0;i<a.length;i++)j=a[i],e(j)?g(j,0,l,0):w(j)?B(j):Object(j)===j&&h(j,l);else Object(a)===a&&h(a,l)},B.addPrefix=function(a,b){z[a]=b},B.addFilter=function(a){x.push(a)},B.errorTimeout=1e4,null==b.readyState&&b.addEventListener&&(b.readyState="loading",b.addEventListener("DOMContentLoaded",A=function(){b.removeEventListener("DOMContentLoaded",A,0),b.readyState="complete"},0)),a.yepnope=k(),a.yepnope.executeStack=h,a.yepnope.injectJs=function(a,c,d,e,i,j){var k=b.createElement("script"),l,o,e=e||B.errorTimeout;k.src=a;for(o in d)k.setAttribute(o,d[o]);c=j?h:c||f,k.onreadystatechange=k.onload=function(){!l&&g(k.readyState)&&(l=1,c(),k.onload=k.onreadystatechange=null)},m(function(){l||(l=1,c(1))},e),i?k.onload():n.parentNode.insertBefore(k,n)},a.yepnope.injectCss=function(a,c,d,e,g,i){var e=b.createElement("link"),j,c=i?h:c||f;e.href=a,e.rel="stylesheet",e.type="text/css";for(j in d)e.setAttribute(j,d[j]);g||(n.parentNode.insertBefore(e,n),m(c,0))}}(this,document),Modernizr.load=function(){yepnope.apply(window,[].slice.call(arguments,0))};
*/
//=======================FORM VALIDATION============================
// validate only if form has td-form-validate class
//==================================================================
jQuery.fn.tdValidate = function() {
    if ($(this).is('.td-form-validate') || $(this).parents('form').is('.td-form-validate')) {
        return true;
    }
    return false;
};
$.css_browser_selector(navigator.userAgent);
//check for ie11
var rv = -1,
    ua = navigator.userAgent,
    re = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");
if (re.exec(ua) != null) rv = parseFloat(RegExp.$1);

/*var arrowPressed = false;*/
if($.validation){
    $.validation.formMaster = [];
}
$(document).ready(function($) {
    $(".td-form, .td-form-compact").each(function(index, element) {
        var currentFormId = '#' + $(this).attr('id'),
            currIdx = index,
            currFormAction = $(this).attr('action');
        //add td-hidden to all form elements inside dep
        $(currentFormId).find('.dep input, .dep select, .dep textarea').addClass('td-hidden');
        if ($(this).tdValidate()) {
            $.validation.formMaster[currIdx] = $(currentFormId).validate({
                //debug:true,
                focusInvalid: false,
                ignore: '.td-hidden',
                errorClass: "td-error",
                invalidHandler: function() {
                    $.validateCustom2(currentFormId, currIdx);
                },
                submitHandler: function(form) {				
                    //select and cache all the fields
                    var $inputs = $(this).find("input, select, button, textarea");
                    //disable non data form fields and optional dependant fields 
                    var $toggles = $(form).find('.td-dependant-trigger input.toggle').prop('disabled', true);
                    // serialize form data with non-empty fields and filter out dependant fields that are toggled off
                    var serializedData = $(currentFormId + ' :input[value!=""]').not('.hiddenDisable').serialize();
                    // let's disable the inputs for the duration of the ajax request
                    $inputs.prop("disabled", true);
                    if ($('html').hasClass('ie8') ) {
                        var allInputs = $( ":input" );
                        allInputs.each( function(){
                            if($(this).attr('placeholder') != undefined){
                              if ($(this).attr('placeholder') == $(this).attr('value')){
                                    $(this).removeAttr('placeholder');
                                    $(this).attr('value',''); ;
                              }
                            }
                        })
                    }
					if ($(currentFormId).hasClass('td-ajax-submit')) {
						// fire off the request
						request = $.ajax({
							url: currFormAction,
							type: "POST",
							dataType: "json",
							data: serializedData
						});
						// success callback handler 
						request.done(function respond(response, textStatus, jqXHR) {
							if (response.$valid == 'true') {
								//route to success function
								$.successRedirect(response.$successMsg, response.$redirect, currentFormId);
							} else {
								//present errors from server validation
								errorList = {};
								$.each(response, function(key, value) {
									if (key.substring(0, 1) != "$") {
										errorList[key] = value;
										//console.log( key + " : " + value );
									}
								});
								$.validation.formMaster[currIdx].showErrors(errorList);
                                //find first error and set focus
                               /* firstErrorField = $($.validation.formMaster[currIdx].errorList[0].element);
                                $('html, body').animate({
                                      scrollTop: firstErrorField.offset().top - 50
                                }, 800, function() {
                                  $(firstErrorField).focus();
                                  //repeat error show function to override default error replacement of first error field
                                  $.validation.formMaster[currIdx].showErrors(errorList);
                                });*/
							}
							// log a message to the console
							// activate form toggles again (disabled earlier to avoid serialization)
							//$toggles.prop('disabled', false);
							//resultDiv.html('<p><strong>' + response.msg + '</strong></p>').show('fast');
							//.delay('3000').hide('slow');
							//either reset/hide form or take to another page...
						});
						// callback handler that will be called on failure
						request.fail(function(jqXHR, textStatus, errorThrown) {
							// log the error to the console
							//console.error(jqXHR)
							//textStatus + " : " + errorThrown);
						});
						// callback handler that will be called regardless
						// if the request failed or succeeded
						request.always(function() {
							// reenable the inputs
							$inputs.prop("disabled", false);
							$toggles.prop('disabled', false);
						});
					} else {
						//allow custom submission
                         try {
                             $.customSubmit(form, serializedData); 
                         } catch(e) {
                             form.submit();
                         }
                      
					}
                },
                success: function(label, element) {
                    label.html('');
                },
                highlight: function(element) {
                    var errorLabel = $("label[for='" + $(element).attr('name') + "'].td-error");
                    errorLabel.css('margin-top', '5px').hide().fadeIn();
                    var errorFieldsetRadios = "<label for="+ $(element).attr('name') +" class='td-error'></label>";
                    var label = $("label[for='" + $(element).attr('id') + "']");
                    var labelParent = $(label).parents('fieldset');
                    //console.log(errorLabel);
                    if (label.is('.card, .td-label')) {
                        if (labelParent.length) { // apply to fieldset or individual field
                            labelParent.addClass('td-radio-checkbox-error').removeClass('td-valid');
                            //add error at bottom of radio buttons if in stacked form
                            if( errorLabel.length == 0 ){;
                            	labelParent.after(errorFieldsetRadios);
                        	}
                        } else {
                            //otherwise apply to individual element
                            label.addClass('td-radio-checkbox-error').removeClass('td-valid');
                        }
                        return;
                    }
                    // input fields & dropdown
                    $(element).parents('.form-group').removeClass("td-group-valid").addClass("td-group-error");
                },
                unhighlight: function(element) {
                    // radio and checkboxes
                    var errorLabel = $("label[for='" + $(element).attr('name') + "'].td-error");
                    errorLabel.css('margin-top', 0);
                    var label = $("label[for='" + $(element).attr('id') + "']");
                    var labelParent = $(label).parents('fieldset');
                    if (label.is('.card, .td-label')) {
                        if (labelParent.length) { // apply to fieldset or individual field
                            labelParent.removeClass('td-radio-checkbox-error').addClass('td-valid');
                        } else {
                            label.removeClass('td-radio-checkbox-error').addClass('td-valid');
                        }
                        return;
                    }
                    // input fields & dropdowns
                    if ($(element).val().length > 0) {
                        $(element).parents('.form-group').addClass("td-group-valid").removeClass("td-group-error");
                    }else {
                        $(element).parents('.form-group').removeClass("td-group-valid");
                    }
                }
            });
        }
        // prevent enter key from submiting form except for inputs that have class 'enterToSubmit'
        $(currentFormId).keypress(function(e) {
            var charCode = e.charCode || e.keyCode || e.which,
			currentElement = $(document.activeElement);
            if (!currentElement.hasClass('enterToSubmit') && charCode == 13) {
				if(currentElement.is('input, textarea')) {
                return false;
				}
            }
        });
        //reset form on reload
        $(currentFormId).get(0).reset();
		//reset on cancel button
		$(currentFormId).find('.td-cancel').on('click', function(e) {
			e.preventDefault();
			$(currentFormId).find('.form-group').removeClass('td-group-error');
			$(currentFormId).find('label, fieldset').removeClass('td-radio-checkbox-error');
			$.validation.formMaster[currIdx].resetForm();
			$(currentFormId).get(0).reset();
		});
	
/*add remote validation  rule
==============================*/
        if ($(this).tdValidate()) {
           
            $(currentFormId).find('.remote-valid').each(function() {
                var elem = $(this);
                elem.rules('add', {
                    remote: {
                        url: elem.attr('data-remote-valid'),
                        type: "post"
                    }
                });
            });
        }
        //validate each field on exit and update numberOfInvalids
        if ($(currentFormId).hasClass('td-form-dynamic')) {
            var prevName, currName, previous, current, focusTargetid;
            //set previous to a dummy object to avoid undefined error on clicking into an input for the first time
            previous = $(currentFormId).find('h1');
            $(currentFormId).find('input, select, textarea').each(function() {
                // set the aria-describedby for all dynamic help form elements
                var thisElement = $(this),
                    targetId, ariaTargetId, siblings;
                if (thisElement.hasClass('d-help')) {
                    targetId = thisElement.metadata().dynamic, ariaTargetId = targetId + '-' + unique('aria');
                    $(targetId).after('<span id="' + ariaTargetId + '" class="td-forscreenreader" aria-hidden="true">' + $(targetId).text() + '</span>');
                    if (thisElement.parents('fieldset').length > 0 && (thisElement.is(':checkbox') || thisElement.is(':radio'))) {
                       thisLegend = thisElement.parents('fieldset').find('legend');
                       if (thisLegend.length == 0){
                            $(this).parents('fieldset').prepend('<legend class="td-forscreenreader" aria-hidden="true">' + $(targetId).text() + '</legend>');
                       } else {
                            hasScreenReader = thisLegend.find('span').hasClass('td-forscreenreader');
                            if ( $(targetId).text().length > 0 && !hasScreenReader ){
                                thisLegend.append( '<span class="td-forscreenreader" aria-hidden="true">' + $(targetId).text() +'</span>');
                            }
                       }
                    } else {
						var currentAriaTargetId = thisElement.attr('aria-describedby');
						if (typeof currentAriaTargetId !== "undefined") {
							currentAriaTargetId = currentAriaTargetId + ' ';
						} else {
							currentAriaTargetId = '';
						}
                        thisElement.attr('aria-describedby', currentAriaTargetId + ariaTargetId);
                    }
                }
            }).on('blur', function() {
                // if its a checkbox or radio that is a part of a fieldset, donot valid untill 
                // user clicks more than one checkbox or outside the fieldset
                //  var label = $("label[for='" + $(this).attr('id') + "']");
                // var labelParent = $(label).parent('fieldset');
                previous = $(this);
                prevName = previous.attr('name');
                targetid = $(this).metadata().dynamic;
                $.debuglog('previous from blur ' + prevName);
                var isRadioOrCheckbox = (previous.is(':checkbox') || previous.is(':radio')) ? true : false;
                if (isRadioOrCheckbox) {
                    setTimeout(function() {
                        $.validateRadioCheckbox(prevName, previous);
                        prevName = currName = '';
                    }, 0);
                } else {
                    if ($(this).tdValidate()) {
                        setTimeout(function() {
                            previous.valid();
                        }, 1000);
                    }
                }
            }).on('focus', function() {
                current = $(this), currName = (typeof current.attr('name') != 'undefined') ? current.attr('name') : '';
                //show dynamic help
                var range = $('input[name=' + currName + ']');
                //pick the dynamic help id from input or the 1st input from fieldset
                if (range.length <= 1) {
                    focusTargetid = $(this).metadata().dynamic;
                } else {
                    focusTargetid = $('input[name=' + currName + ']').first().metadata().dynamic;
                }
                //set the arrow position based on the trigger input field
                var currentDynamicPos = current.parent().is('.form-group') ? (current.parent().position().left - 812) : -812;
                $(focusTargetid).find('.dynamic-arrow').css('background-position', currentDynamicPos);
                var dynamicWrapper = $(focusTargetid).parent(),
                    tranSpeed = 200;
                // show hide help    			
                if (prevName != currName) {
                    if ($(focusTargetid).parent().hasClass('td-donotanimate')) {
                        //do not use transitions for horizontal input fields
                        if (previous.parents('fieldset')[0] !== current.parents('fieldset')[0]) {
                            $('.dynamic-help').not(focusTargetid).slideUp('fast');
                            setTimeout(function() {
                                $(focusTargetid).fadeIn('fast');
                            }, tranSpeed);
                        } else {
                            $('.dynamic-help').not(focusTargetid).hide();
                            $(focusTargetid).show();
                        }
                    } else {
                        $('.dynamic-help').not(focusTargetid).slideUp('fast');
                        setTimeout(function() {
                            $(focusTargetid).fadeIn('fast');
                        }, tranSpeed);
                    }
                    $(focusTargetid).css('overflow', 'visible');
                }
                // workaround for remote validation bug not validating on re-entry
                if ($(this).tdValidate()) {
                    if (current.hasClass('remote-valid') && current.parent().hasClass('td-group-error')) {
                        $(this).valid();
                    }
                }
            }); /*dynamic override (hide if clicked outside form elements*/
            $("body").click(function(event) {
                var target = $(event.target);
                if (target.is(".td-form-dynamic input,.td-form-dynamic label, .td-form-dynamic select,  .td-form-dynamic textarea") || target.parents('label').length > 0) {} else {
                    //target.css( "background-color", "red" );
                    $('.dynamic-help').slideUp('fast');
                    prevName = "";
                }
            });
        }
		if ($(currentFormId).tdValidate()) {
        $(currentFormId).find('.tdCurrencyFr').on('focus', function(e) {
            var value = $(this).val().replace(/ +/g, '');
			$(this).val(value).select();
			//$(this).caret(-1)
		}).on('blur', function(e) {
            var value = $(this).val().replace(/ +/g, '');
            value = value.replace(/\.(\d?\d)$/g, ',$1');
            if (/(?=.)^\$?(([1-9][0-9]{0,2}( [0-9]{3})*)|[0-9]+)?(\,[0-9]{0,2})?$/i.test(value)) {
                value = value.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1 ");
				var lastChar = value.charAt(value.length - 1),		
					secondLastChar = value.charAt(value.length - 2);		
				if (lastChar == ',') {
					value = value.slice(0,-1); // remove trailing comma 
				}
				if ( secondLastChar == ',') {
					value = value + '0'; // add zero to make decimal two units
				}
                $(this).val(value);
                $(this).valid();
            }
        });
        $(currentFormId).find('.tdCurrencyEn').on('focus', function(e) {
			var value = $(this).val().replace(/ |,+/g, '');
			$(this).val(value).select();
			//$(this).caret(-1);
		})
		.on('blur', function(e) {
            var value = $(this).val().replace(/ |,+/g, '');
            if (/(?=.)^\$?(([1-9][0-9]{0,2}( [0-9]{3})*)|[0-9]+)?(\.[0-9]{0,2})?$/i.test(value)) {
                value = value.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
				var lastChar = value.charAt(value.length - 1),
					secondLastChar = value.charAt(value.length - 2);		
				if ( lastChar == '.') {
					value = value.slice(0,-1); // remove trailing decimal
				}
				if ( secondLastChar == '.') {
					value = value + '0'; // add zero to make decimal two units
				}
                $(this).val(value)
                $(this).valid();
            }
        });
            // find and format dateEn in form
            //===============================
            $(currentFormId).find('.tdDateEn').on('focus', function(e) {
                if ($(this).val() == 'Invalid date')$(this).val('');
            }).on('blur', function(e) {
				var thisElem = $(this);
				if (!thisElem.hasClass('td-valid-date') ) return false;
                if (thisElem.val().length > 0) {
                   thisElem.val(
				   //reformat date to verbose format 
				   moment($.validation.dateFormat(thisElem)).format('MMM. DD, YYYY')
				   ); $.validation.birthday(thisElem);
                }
            });
            $(currentFormId).find('.tdDateFr').on('focus', function(e) {
                if ($(this).val() == 'Invalid date')$(this).val('');
            }).on('blur', function(e) {
				var thisElem = $(this);
				if (!thisElem.hasClass('td-valid-date') ) return false;
                if (thisElem.val().length > 0) {
					//format date
                   thisElem.val($.validation.dateFormat(thisElem)); $.validation.birthday(thisElem); 
                }
            });
		}
    });
    // Toggle
    // add dependency rule
    //=================================================== 
    $('.toggle-on').each(function(index, element) {
        var targetId, currentDependantRule;
        if ($(this).parent().hasClass('td-dependant-trigger')) {
            targetId = '#' + $(this).parent().metadata().targetId, currentDependantRule = "#" + $(this).attr('id') + ":checked";
            //console.log(targetId);
        }
        var hiddenFields = $(targetId).find('.hiddenReq');
        hiddenFields.each(function(index, element) {
            if ($(this).tdValidate()) {
                $(this).rules('add', {
                    required: currentDependantRule
                });
            }
        });
    });
    // Toggle
    // show hide
    //=================================================== 
    $('.toggle').each(function() {
        $(this).on('click', function() {
            var currentToggle = $(this);
            if (currentToggle.parent().hasClass('td-dependant-trigger')) {
                var targetId = '#' + $(this).parent().metadata().targetId;
                //console.log(targetId);
            }
            if (typeof targetId !== "undefined") {
                var toHide = $(targetId).find('input, select, textarea');
                if (currentToggle.hasClass('toggle-on')) {
                    $(targetId).slideDown('fast');
                    toHide.removeClass('hiddenDisable');
                    if (currentToggle.is(':checkbox')) currentToggle.removeClass('toggle-on').addClass('toggle-off');
                } else {
                    $(targetId).slideUp('fast');
                    toHide.addClass('hiddenDisable');
                    if (currentToggle.is(':checkbox')) currentToggle.removeClass('toggle-off').addClass('toggle-on');
                }
            }
        });
    });
    // Submit disable for invalid form states
    //=================================================== 
    $('form.check-enable').each(function() {
        var $this = $(this),
        	submit = $this.find($this.metadata().checkEnableTarget),
        	inputs = $this.find("input:not([type=submit])"),
        	disabledClass = "td-button-disabled";
        
        submit.addClass(disabledClass).attr("disabled", true);
        
        inputs.on("change", function() {
			if (inputs.filter(":checked").length > 0) {
        		submit.removeClass(disabledClass).attr("disabled", false);
			} else {
        		submit.addClass(disabledClass).attr("disabled", true);
			}
        });
    });
    //workaround for callout based labels in ie8 not changing due to click on images
	if ($('html').hasClass('ie8') || rv > 10) {    
		$('label.td-label img').on('click', function() {
            var inputId = $("#" + $(this).parents('label').attr("for"));
            $(this).parent('label').addClass('label-focused');
            inputId.click();
            if ($(this).tdValidate()) {
                inputId.valid();
            }
            inputId.focus();
        });
    }
    //setup select dropdowns for ie8
    if ($.browser.msie) {
        if ($('html').hasClass('ie8')) {
            //ie 8
            $('.td-select select').each(function(index, element) {
                $(this)
                //restyle for ie8
                .parent('.td-select') //.addClass('td-select-ie8')
                //.removeClass('td-select')
                .parent('.form-group').addClass('form-group-ie8');
                //.removeClass('form-group')
                //alternatively remove styles for ie8
                //.unwrap().unwrap()
                $(this).siblings('span').remove();
            });
        } else {
            //ie 9 and above    
            $('body').addClass('ie9above'); // for ie9 css hack
            $('.td-select select').each(function(index, element) {
                $.getOption($(this));
            });
        }
    } else {
        // not ie
        $('.td-select select').each(function(index, element) {
            $.getOption($(this));
        });
    }
    $('.td-select select').on('keyup', function(e) {
        if (e.keyCode != 38 && e.keyCode != 40) {
            return;
        }
        $.getOption($(this));
    });
    $('.td-select select').on('change', function(e) {
        $.getOption($(this));
        if ($('html').hasClass('chrome')) {
            //alert('çhrome');
        } else {
            //$(this).blur().valid();
        }
    });
/*======================================
    ASSISTIVE TECHNOLOGY 
=======================================*/
    //ALL BROWSERS: add described by tag to td-error for checkboxes that require more than one selected
    $('fieldset input.td-checkmin:checkbox').each(function(index, element) {
        var thisElem = $(this),
            thisName = $(this).attr('name'),
            errorAriaId = unique('aria'),
            errorLabel = $("label[for='" + thisName + "'].td-error");
        $('[name=' + thisName + ']').attr('aria-describedby', errorAriaId); // add to described by id to each checkbox input
        errorLabel.attr('id', errorAriaId); // tie error label to described by by adding unique id
    });
/*
	Non IE8 assistive technology addon 
    ==================================
	*/
    if (!$('html').hasClass('ie8')) {
        //add legend description for non-ie8 browsers 
        $('.td-legend-block legend').each(function(index, element) {
            var legendAriaId = unique('aria');
            $(this).attr('id', legendAriaId);
            $(this).parents('fieldset').find('input:not(:radio, :checkbox), select, textarea').each(function(index, element) {
                var ariaIdAll = "",
                    thisLabel = 'label[for="' + $(this).attr('id') + '"]';
                $(thisLabel).each(function(index, element) {
                    var ariaId = unique('aria');
                    ariaIdAll = ariaIdAll + " " + ariaId;
                    $(this).attr({
                        'id': ariaId
                    });
                });
                $(this).attr({
                    'aria-labelledby': legendAriaId + " " + ariaIdAll
                });
            });
        });
    } else {
/*
	IE8 assistive technology addon 
    ==================================
	*/
        //add image descriptor for ie8 in labels that have images
/*        $('.td-label img').each(function(index, element) {
            var imgDesc = $(this).attr('alt');
            if (imgDesc != "") {
                $(this).before('<span class="td-forscreenreader">' + 'image of ' + imgDesc + '</span>');
            }
        });*/
    }
    //add aria-labelledby attribute to select, textarea & input fields (that are not checkbox or radio)that have the required class
    $('body').find('input:not(:radio, :checkbox), select, textarea').each(function() {
        if ($('html').hasClass('ie8')) {
            if ($(this).hasClass('required')) {
                var ariaIdAll = "",
                    thisLabel = 'label[for="' + $(this).attr('id') + '"]';
                $(thisLabel).each(function(index, element) {
                    var ariaId = unique('aria');
                    ariaIdAll = ariaIdAll + ariaId + " ";
                    $(this).attr({
                        'id': ariaId
                    });
                });
                $(this).attr({
                    'aria-labelledby': ariaIdAll
                });
            }
        }
        //Add Placeholders
        //================
        $(this).placeholder();
    });

    //assistive technology addon for all browsers
    //Add required for screen readers
    //================================
    $('fieldset').find('input:first, select:first').each(function() {
		// for required fieldsets
		var requiredLegend = $("html").attr("lang") === "fr-CA" ? "Ce champ est obligatoire." : "This is a required fieldset";
		var optionalLegend = $("html").attr("lang") === "fr-CA" ? "Ce champ est optionnel" : "This is an optional fieldset";

		if ($(this).hasClass('required') || $(this).hasClass('hiddenReq') || $(this).attr('data-rule-required') == 'true') {
			var thisLegend = $(this).parents('fieldset').find('legend');
			if (thisLegend.length == 0) {
				$(this).parents('fieldset').prepend('<legend class="td-forscreenreader" aria-hidden="true"> ' + requiredLegend + '</legend>');
			} else {
				thisLegend.append('<span class="td-forscreenreader" aria-hidden="true"> ' + requiredLegend + '</span>');
			}
		} else {
			var thisLegend = $(this).parents('fieldset').find('legend');
			if (thisLegend.length == 0) {
				$(this).parents('fieldset').prepend('<legend class="td-forscreenreader" aria-hidden="true"> ' + optionalLegend + '</legend>');
			} else {
				thisLegend.append('<span class="td-forscreenreader" aria-hidden="true"> ' + optionalLegend + '</span>');
			}
		}
	});
    
	
    $('body').find('input').each(function() {
    	var requiredLabel = $("html").attr("lang") === "fr" ? "Ce champ est obligatoire." : "This is a required field";
    	var optionalLabel = $("html").attr("lang") === "fr" ? "Ce champ est optionnel" : "This is an optional field";
		
    	if ((($(this).hasClass('required') || $(this).hasClass('hiddenReq') || $(this).attr('data-rule-required') == 'true')) && $(this).parents('fieldset').length == 0) {
		var thisLabel = 'label[for="' + $(this).attr('id') + '"]';
		$(thisLabel).not(".td-error").append('<span class="td-forscreenreader" aria-hidden="true">'+requiredLabel+'</span>');
    	} else if ( $(this).parents('fieldset').length == 0 ){
		var thisLabel = 'label[for="' + $(this).attr('id') + '"]';
    		$(thisLabel).not(".td-error").append('<span class="td-forscreenreader" aria-hidden="true">'+optionalLabel+'</span>');
    	}
    });
	   

    // set focus to input field if its not already in focus
    $('.form-group').on(' click', function(e) {
        var clickedInput = $(this).find('input');
        if (!($(clickedInput).is(":focus"))) {
            $(clickedInput).focus()
        }
    });
    // set hover classes
    $('.form-group').on('mouseenter', function(e) {
        $(this).addClass("td-group-hover");
    }).on(' mouseleave', function(e) {
        //check :: if input or select is in focus or if input or select is valid, then let the hover colour remain
        $(this).removeClass("td-group-hover");
    }).on(' focusin', function(e) {
        $(this).addClass("td-group-focus");
    }).on(' focusout', function(e) {
        $(this).removeClass("td-group-focus");
    });
    // checkbox and radio buttons 
    $('input[type=radio]').on('click', function(e) {
        var thisName = $(this).attr('name'),
            thisId = $(this).attr('id');
        $('input[name=' + thisName + ']').removeClass('checked');
        $(this).addClass('checked').parents('fieldset').find('label.td-label').removeClass('label-checked');
        $("label[for='" + thisId + "']").addClass('label-checked');
    });
    $('input[type=checkbox]').on('click', function(e) {
        var thisName = $(this).attr('name'),
            thisId = $(this).attr('id');
        if ($(this).hasClass('checked')) {
            $(this).removeClass('checked');
            $("label[for='" + thisId + "']").removeClass('label-checked');
        } else {
            $(this).addClass('checked');
            $("label[for='" + thisId + "']").addClass('label-checked');
        }
    });
    $('input[type=radio],input[type=checkbox]').on('focus', function(e) {
        var thisId = $(this).attr('id');
        $('#' + thisId).addClass('focused');
        $('label[for="' + thisId + '"]').addClass('label-focused');
    });
    $('input[type=radio],input[type=checkbox]').on('blur', function(e) {
        var thisId = $(this).attr('id');
        $('#' + thisId).removeClass('focused');
        $('label[for="' + thisId + '"]').removeClass('label-focused');
    });
    //add last-child class for ie8
    $('.ie8 fieldset label:last-child, .ie8 .radiosplit .label-column:last-child').addClass('last-child');

/*******************************************************/
/* Add class if JavaScript is enabled
/*******************************************************/
    $("body").addClass("td-JS-enabled"); 
/*******************************************************/
/* Add First/Last classes to nested grid
/*******************************************************/
    $(".td-layout-row .td-layout-column:first-child").addClass("td-layout-column-first");
    $(".td-layout-row .td-layout-column:last-child").addClass("td-layout-column-last");
    $(".td-callout .td-layout-column:first-child").addClass("td-layout-column-first");
    $(".td-callout .td-layout-column:last-child").addClass("td-layout-column-last"); 
/*******************************************************/
/* Add First/Last classes to left nav
/*******************************************************/
    $("#td-nav-left ul li ul li:first-child").addClass("td-nav-left-first-child");
    $("#td-nav-left ul li ul li:last-child").addClass("td-nav-left-last-child");
    $("#td-nav-left ul li.td-nav-left-fauxlevel1:last-child").addClass("td-nav-left-fauxlevel1-last-child");
/*******************************************************/
/* Detect Internet Explorer
/*******************************************************/
    if ($.browser.msie) {
        $("body").addClass("browser-IE");
    } 
/*******************************************************/
/* Find query string
/*******************************************************/
    // http://jquery-howto.blogspot.ca/2009/09/get-url-parameters-values-with-jquery.html
    $.extend({
        getUrlVars: function() {
            var vars = [],
                hash;
            var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
            for (var i = 0; i < hashes.length; i++) {
                hash = hashes[i].split('=');
                vars.push(hash[0]);
                vars[hash[0]] = hash[1];
            }
            return vars;
        },
        getUrlVar: function(name) {
            return $.getUrlVars()[name];
        }
    });
    // var allVars = $.getUrlVars(); // Get object of URL parameters
    // var byName = $.getUrlVar('name'); // Getting URL var by its name

/*******************************************************/
/* Add last class to last element in callout
/*******************************************************/
    if ($.browser.msie) {
        $(".td-callout-content").each(function() {
            $(this).children().last().addClass("td-lastelement");
        });
    } 
/*******************************************************/
/* Add extra width to callout if it will have scrollbars
/*******************************************************/
    $(".td-callout-withscrollbar").each(function() {
        var width = $(this).innerWidth();
        $(this).width(width);
    });
	
	

/*******************************************************/
/* Function calls 
/*******************************************************/
flushBottom(); 
PIErefresh();
/*******************************************************/
/* Popup Windows
/*******************************************************/
    $(function() {
        $.fn.popupwindow = function(p) {
            var profiles = p || {};
            return this.each(function(index) {
                var settings, parameters, mysettings, b, a, winObj;
                // for overrideing the default settings
                mysettings = ($(this).attr("rel") || "").split(",");
                settings = {
                    height: 530,
                    // sets the height in pixels of the window.
                    width: 400,
                    // sets the width in pixels of the window.
                    toolbar: 0,
                    // determines whether a toolbar (includes the forward and back buttons) is displayed {1 (YES) or 0 (NO)}.
                    scrollbars: 1,
                    // determines whether scrollbars appear on the window {1 (YES) or 0 (NO)}.
                    status: 0,
                    // whether a status line appears at the bottom of the window {1 (YES) or 0 (NO)}.
                    resizable: 1,
                    // whether the window can be resized {1 (YES) or 0 (NO)}. Can also be overloaded using resizable.
                    left: 0,
                    // left position when the window appears.
                    top: 0,
                    // top position when the window appears.
                    center: 1,
                    // should we center the window? {1 (YES) or 0 (NO)}. overrides top and left
                    createnew: 1,
                    // should we create a new window for each occurance {1 (YES) or 0 (NO)}.
                    location: 0,
                    // determines whether the address bar is displayed {1 (YES) or 0 (NO)}.
                    menubar: 0,
                    // determines whether the menu bar is displayed {1 (YES) or 0 (NO)}.
                    onUnload: null // function to call when the window is closed
                };
                // if mysettings length is 1 and not a value pair then assume it is a profile declaration
                // and see if the profile settings exists
                if (mysettings.length == 1 && mysettings[0].split(":").length == 1) {
                    a = mysettings[0];
                    // see if a profile has been defined
                    if (typeof profiles[a] != "undefined") {
                        settings = $.extend(settings, profiles[a]);
                    }
                } else {
                    // overrides the settings with parameter passed in using the rel tag.
                    for (var i = 0; i < mysettings.length; i++) {
                        b = mysettings[i].split(":");
                        if (typeof settings[b[0]] != "undefined" && b.length == 2) {
                            settings[b[0]] = b[1];
                        }
                    }
                }
                // center the window
                if (settings.center == 1) {
                    settings.top = ((screen.height - (settings.height)) / 2) - 50;
                    settings.left = (screen.width - settings.width) / 2;
                }
                parameters = "location=" + settings.location + ",menubar=" + settings.menubar + ",height=" + settings.height + ",width=" + settings.width + ",toolbar=" + settings.toolbar + ",scrollbars=" + settings.scrollbars + ",status=" + settings.status + ",resizable=" + settings.resizable + ",left=" + settings.left + ",screenX=" + settings.left + ",top=" + settings.top + ",screenY=" + settings.top;
                $(this).bind("click", function() {
                    var name = settings.createnew ? "PopUpWindow" + index : "PopUpWindow";
                    winObj = window.open(this.href, name, parameters);
                    if (settings.onUnload) {
                        // Incremental check for window status
                        // Attaching directly to window.onunlaod event causes invoke when document within window is reloaded
                        // (i.e. an inner refresh)
                        unloadInterval = setInterval(function() {
                            if (!winObj || winObj.closed) {
                                clearInterval(unloadInterval);
                                settings.onUnload.call($(this));
                            }
                        }, 500);
                    }
                    //winObj.focus();
                    return false;
                });
            });
        };
        $(".td-popupwindow").popupwindow();
    });
/*******************************************************/
/* Stand Alone Links (updated Feb 2014)
/*******************************************************/
    $(".td-link-header, .td-link-standalone").html(function() {
		//setup variables for checking if link has child nodes and 
		//to determine if last word is part of child node or plain text
		var linkHtml = $.trim($(this).html()),
			linkHtmlSplit = linkHtml.split(" "),
			dummyPop = linkHtmlSplit.pop(),
			lastChild = $(this).children().last(),
			linkText = $.trim($(this).text()).split(" "),
			linkComplile;

		if (lastChild.length>0) {
			//check if link has plain text or child node
			var textSub = $.trim(lastChild.html());
			lastChild.html(textSub);
		}
			lastText = linkText.pop();		

		if(lastChild.text() == lastText) {
			 lastChild.html('<span class="td-copy-nowrap">' + lastChild.html() + '&#65279;<span class="td-link-icon">&#8250;</span></span>')
			 linkComplile = $.trim($(this).html());		
		}else {
			linkComplile = linkHtmlSplit.join(" ") + (" <span class='td-copy-nowrap'>" + lastText + "&#65279;<span class='td-link-icon'>&#8250;</span></span>");
		}
        return linkComplile;
    });
/*******************************************************/
/* Expand/Collapse (Toggle)
/*******************************************************/
    $(".td-link-toggle").each(function() {
        var triggerelement = $(this);
        var targetelement = $(this).metadata().targetelement;
        var triggericon = $(this).find(".td-triggericon");
        var fx = $(this).metadata().fx;
        
        
        $(targetelement).attr("tabindex", "-1");

        function toggleClose() {
            $(triggericon).removeClass("td-triggericon-expanded");
            if ($(triggericon).length) {
                var alt = $(triggericon).html();
                alt = alt.replace("Collapse", "Expand");
                $(triggericon).text(alt);
            }
            if (($(targetelement).is("table,tr,th,td")) || fx == 'quickfade') {
                $(targetelement).animate({
                    opacity: 0
                }, 250, function() {
                    $(targetelement).hide();
                });
            } else if (fx == 'none') {
                $(targetelement).animate({
                    opacity: 0
                }, 0, function() {
                    $(targetelement).hide();
                });
            } else {
                $(targetelement).animate({
                    height: "toggle",
                    opacity: "toggle"
                });
            }
        }

        function toggleOpen() {
            $(triggericon).addClass("td-triggericon-expanded");
            if ($(triggericon).length) {
                var alt = $(triggericon).html();
                alt = alt.replace("Expand", "Collapse");
                $(triggericon).text(alt);
            }
            if (($(targetelement).is("table,tr,th,td")) || fx == 'quickfade') {
                $(targetelement).show();
                $(targetelement).css({
                    'opacity': '0'
                });
                $(targetelement).animate({
                    opacity: 1
                }, 500, function() {});
            } else if (fx == 'none') {
                $(targetelement).show();
                $(targetelement).css({
                    'opacity': '0'
                });
                $(targetelement).animate({
                    opacity: 1
                }, 0, function() {});
            } else {
                $(targetelement).animate({
                    height: "toggle",
                    opacity: "toggle"
                });
            }
        }
        $(triggerelement).click(function() {
            if (!($(targetelement).is(":visible"))) {
                toggleOpen();
                $(targetelement).focus();
                return false;
            }
            if ($(targetelement).is(":visible")) {
                toggleClose();
				$(triggerelement).focus();
                return false;
            }
        });
    }); 
/*******************************************************/
/* Tables
/*******************************************************/
(function(e){var t=function(e){var t=e.rows;var n=t.length;var r=[];for(var i=0;i<n;i++){var s=t[i].cells;var o=s.length;for(var u=0;u<o;u++){var a=s[u];var f=a.rowSpan||1;var l=a.colSpan||1;var c=-1;if(!r[i]){r[i]=[]}var h=r[i];while(h[++c]){}a.realIndex=c;for(var p=i;p<i+f;p++){if(!r[p]){r[p]=[]}var d=r[p];for(var v=c;v<c+l;v++){d[v]=1}}}}};var n=function(e){var t=0,n,r,i=e.tHead?e.tHead.rows:0;if(i){for(n=0;n<i.length;n++){i[n].realRIndex=t++}}for(r=0;r<e.tBodies.length;r++){i=e.tBodies[r].rows;if(i){for(n=0;n<i.length;n++){i[n].realRIndex=t++}}}i=e.tFoot?e.tFoot.rows:0;if(i){for(n=0;n<i.length;n++){i[n].realRIndex=t++}}};e.fn.tableHover=function(r){var i=e.extend({allowHead:true,allowBody:true,allowFoot:true,headRows:false,bodyRows:true,footRows:false,spanRows:true,headCols:false,bodyCols:true,footCols:false,spanCols:true,ignoreCols:[],headCells:false,bodyCells:true,footCells:false,rowClass:"hover",colClass:"",cellClass:"",clickClass:""},r);return this.each(function(){var r=[],s=[],o=this,u,a=0,f=[-1,-1];if(!o.tBodies||!o.tBodies.length){return}var l=function(t,n){var o,u,f,l,c,h;for(f=0;f<t.length;f++,a++){u=t[f];for(l=0;l<u.cells.length;l++){o=u.cells[l];if(n=="TBODY"&&i.bodyRows||n=="TFOOT"&&i.footRows||n=="THEAD"&&i.headRows){h=o.rowSpan;while(--h>=0){s[a+h].push(o)}}if(n=="TBODY"&&i.bodyCols||n=="THEAD"&&i.headCols||n=="TFOOT"&&i.footCols){h=o.colSpan;while(--h>=0){c=o.realIndex+h;if(e.inArray(c+1,i.ignoreCols)>-1){break}if(!r[c]){r[c]=[]}r[c].push(o)}}if(n=="TBODY"&&i.allowBody||n=="THEAD"&&i.allowHead||n=="TFOOT"&&i.allowFoot){o.thover=true}}}};var c=function(e){var t=e.target;while(t!=this&&t.thover!==true){t=t.parentNode}if(t.thover===true){d(t,true)}};var h=function(e){var t=e.target;while(t!=this&&t.thover!==true){t=t.parentNode}if(t.thover===true){d(t,false)}};var p=function(t){var n=t.target;while(n&&n!=o&&!n.thover){n=n.parentNode}if(n.thover&&i.clickClass!=""){var r=n.realIndex,s=n.parentNode.realRIndex,u="";e("td."+i.clickClass+", th."+i.clickClass,o).removeClass(i.clickClass);if(r!=f[0]||s!=f[1]){if(i.rowClass!=""){u+=",."+i.rowClass}if(i.colClass!=""){u+=",."+i.colClass}if(i.cellClass!=""){u+=",."+i.cellClass}if(u!=""){e("td, th",o).filter(u.substring(1)).addClass(i.clickClass)}f=[r,s]}else{f=[-1,-1]}}};var d=function(t,n){if(n){e.fn.tableHoverHover=e.fn.addClass}else{e.fn.tableHoverHover=e.fn.removeClass}var o=r[t.realIndex]||[],u=[],a=0,f,l;if(i.colClass!=""){while(i.spanCols&&++a<t.colSpan&&r[t.realIndex+a]){o=o.concat(r[t.realIndex+a])}e(o).tableHoverHover(i.colClass)}if(i.rowClass!=""){f=t.parentNode.realRIndex;if(s[f]){u=u.concat(s[f])}a=0;while(i.spanRows&&++a<t.rowSpan){if(s[f+a]){u=u.concat(s[f+a])}}e(u).tableHoverHover(i.rowClass)}if(i.cellClass!=""){l=t.parentNode.parentNode.nodeName.toUpperCase();if(l=="TBODY"&&i.bodyCells||l=="THEAD"&&i.headCells||l=="TFOOT"&&i.footCells){e(t).tableHoverHover(i.cellClass)}}};t(o);n(o);for(u=0;u<o.rows.length;u++){s[u]=[]}if(o.tHead){l(o.tHead.rows,"THEAD")}for(u=0;u<o.tBodies.length;u++){l(o.tBodies[u].rows,"TBODY")}if(o.tFoot){l(o.tFoot.rows,"TFOOT")}e(this).bind("mouseover",c).bind("mouseout",h).click(p)})}})($)

    /*row / column stripping*/
	$("table.td-table-stripe-row tr:odd").addClass("td-table-alt-row"); /* Add row striping */
    $("table.td-table-stripe-column td:nth-child(even)").addClass("td-table-alt-column"); /* Add column striping */
	$("table.td-table-stripe-row-grey").each(function(index, element) {
        $(this).find("tr:odd").addClass("td-table-alt-row");
		$(this).find("tr:even").removeClass("td-table-alt-row");
    });
	$("table.td-table-stripe-row-white").each(function(index, element) {
        $(this).find("tr:even").addClass("td-table-alt-row");
		$(this).find("tr:odd").removeClass("td-table-alt-row");
    });
	
	
    $("table.td-table-hover-row").tableHover({
        rowClass: 'td-table-hover-row',
        spanRows: false,
        spanCols: false
    }); /* Add column hover */
    $("table.td-table-hover-column").tableHover({
        colClass: 'td-table-hover-column',
        spanRows: false,
        spanCols: false
    });
    $("table.td-table tr:first-child").addClass("td-table-row-first");
    $("table.td-table tr:last-child").addClass("td-table-row-last");
    $(".td-table-superhighlight-column").prev().addClass("td-table-superhighlight-column-before");
    $(".td-table-superhighlight-column").next().addClass("td-table-superhighlight-column-after");
    $(".td-table-superhighlight-row").prev().addClass("td-table-superhighlight-row-before");
    $(".td-table-superhighlight-row").next().addClass("td-table-superhighlight-row-after");
    $(".td-table-superhighlight-row td:last-child").addClass("td-table-superhighlight-column-last");
 /*******************************************************/
/* Make parent div clickable
/*******************************************************/
    $(".td-makeclickable").click(function(event) {
        //var url = $(this).find("a.td-makeclickable-target").attr("href");
        var url = $(this).find("a.td-makeclickable-target").get(0).href;
        var name = $(this).find("a.td-makeclickable-target").attr("target");
        var popup = $(this).find(".td-popupwindow");
        var $target = $(event.target);
        if (($target.is("a") || ($target.parent().is("a")))) {} else {
            if (!(name)) {
                window.open(url, '_self', '', '');
            }
            if (name) {
                if (popup){
                    poprel = popup.attr("rel");
                    //console.log('poprel' + poprel);
                    window.open(url, name, poprel , '');
                } else {
                    window.open(url, name, '', '');
                }
            }
            return false;
        }
    }); 
/*******************************************************/
/* Open link in new window
/*******************************************************/
    $("a.td-link-newwindow").each(function() {
        var titlevar = $(this).attr("title");
        var randomNumber = Math.floor(Math.random() * 99999);
        $(this).attr("aria-describedby", "aria-" + randomNumber);
        $(this).append("<span class='td-forscreenreader' id='aria-" + randomNumber + "' aria-hidden='true'>" + titlevar + "</span>");
        $(this).removeAttr("title");
    });
    $("a.td-link-newwindow-withicon").each(function() {
        var titlevar = $(this).attr("title");
        var randomNumber = Math.floor(Math.random() * 99999);
        $(this).attr("aria-describedby", "aria-" + randomNumber);
        $(this).wrapInner("<span class='td-link-newwindow-label'></span>");
        
        $(this).append("&nbsp;<span class='td-link-newwindow-icon' id='aria-" + randomNumber + "' aria-hidden='true'>" + titlevar + "</span>");
        $(this).removeAttr("title");
    }); 
/*******************************************************/
/* Tabs
/*******************************************************/
    /* General Tabs */
    $(".td-tabs-vertical ul li").prepend("<span class='td-tabs-vertical-top'></span>");
    $(".td-tabs-vertical ul li").append("<span class='td-tabs-vertical-bottom'></span>");
    $(".td-tabs ul li span a").focus(function() {
        $(this).parent().parent().addClass("td-tabs-focused");
    });
    $(".td-tabs ul li span a").blur(function() {
        $(this).parent().parent().removeClass("td-tabs-focused");
    });
    $(".td-tabs ul li").hover(function() {
        $(this).addClass("td-tabs-focused");
    }, function() {
        $(this).removeClass("td-tabs-focused");
    });
    $("li.td-tabs-active").each(function() {
        var titlevar = $(this).find("a").attr("title");
        $(this).find("a").prepend("<span class='td-accesstext' aria-hidden='true'>" + titlevar + "</span> ");
        $(this).find("a").removeAttr("title");
    });
    $(".td-tabs-vertical.td-tabs ul li.td-tabs-active").each(function() {
        $(this).next().addClass("td-tabs-afteractive");
    }); /* Dynamic Tabs */
    $(".td-tabs-dynamic").each(function() {
        var titlevar = $(this).find(".td-accesstext").html();
        var contentwrapper = $(this).metadata().contentwrapper;
        var contentwrapperID = "#" + contentwrapper;
        var equalizecontentheight = $(this).metadata().equalizecontentheight;
        var fx = $(this).metadata().fx;
        var initialactivecontent = $(this).find(".td-tabs-active span a").attr("href");
        $(contentwrapperID).find(".td-tabs-content").hide();
        $(initialactivecontent).show();
        if (equalizecontentheight == 'true') {
            var heights = $(contentwrapperID).find(".td-tabs-content").map(function() {
                return $(this).height();
            }).get(),
                maxHeight = Math.max.apply(null, heights);
            $(contentwrapperID).height(maxHeight);
        }

        function tabsDeactivate() {
            $(clickedtab).parent().find("li").removeClass("td-tabs-active");
            $(clickedtab).parent().find("li").removeClass("td-tabs-afteractive");
            $(clickedtab).parent().find(".td-accesstext").remove();
        }

        function tabActivate() {
            $(clickedtab).addClass("td-tabs-active");
            $(clickedtab).next().addClass("td-tabs-afteractive");
            $(clickedtab).find("a").prepend("<span class='td-accesstext' aria-hidden='true'>" + titlevar + "</span> ");
        }

        function tabContentToggle() {
            $(contentwrapperID).find(".td-tabs-content").hide();
            $(activecontent)
            	
		.attr("tabindex","-1")
            	.show()
            	.focus();
            if ($.browser.msie) {
                PIErefresh();
            }
            if (fx == 'fade') {
                $(activecontent).css({
                    opacity: 0
                });
                $(activecontent).animate({
                    opacity: 1
                });
            }
            if (fx == 'slide') {
                var activecontentwidth = $(activecontent).width();
                $(activecontent).css({
                    opacity: 0
                });
                $(activecontent).css({
                    width: activecontentwidth,
                    position: 'absolute',
                    left: '-200px'
                });
                $(activecontent).animate({
                    opacity: 1,
                    left: '12px'
                });
            }
            if (fx == '') {
                $(activecontent).css({
                    opacity: 1
                });
            }
        }
        if (typeof $.getUrlVar(contentwrapper) != 'undefined') {
            var queryactivecontent = $.getUrlVar(contentwrapper);
            activecontent = '#' + queryactivecontent;
            clickedtab = $(this).find("a[href=" + activecontent + "]").parent().parent();
            tabsDeactivate();
            tabActivate();
            tabContentToggle();
        }
        $(this).find("ul li").click(function() {
            clickedtab = $(this);
            if (clickedtab.hasClass("td-tabs-active")) return false;
            activecontent = $(clickedtab).find("a").attr("href");
            
	    $(clickedtab).parent().find("li").removeClass("td-tabs-active").attr("aria-selected","false");
            $(clickedtab).attr("aria-selected","true");
            tabsDeactivate();
            tabActivate();
            tabContentToggle();
            return false;
        });
    }); 
/*******************************************************/
/* Swap image with active state on hover
/*******************************************************/
    $(".td-link-activeimageonhover").each(function() {
        $(this).mouseenter(function() {
            if ($(this).find("img").length != 0) {
                var src = $(this).find("img").attr("src");
                src = src.replace(".", "-active.");
                $(this).find("img").attr("src", src);
            }
            $(this).find(".td-link-icon").addClass("td-link-icon-active");
        }).mouseleave(function() {
            if ($(this).find("img").length != 0) {
                var src = $(this).find("img").attr("src");
                src = src.replace("-active.", ".");
                $(this).find("img").attr("src", src);
            }
            $(this).find(".td-link-icon").removeClass("td-link-icon-active");
        });
    }); 
/*******************************************************/
/* Hide element via JS
/*******************************************************/
/*    $(".td-JShide").hide(); */
/*******************************************************/
/* Evenly spaced nav
/*******************************************************/
    $(".td-nav-level2-fullwidth-evenlyspaced").each(function() {
        var fullwidth = $(this).outerWidth() - 24;
        var numberofitems = $(this).find("li").length;
        var itemwidth = (fullwidth / numberofitems);
        $(".td-nav-level2-fullwidth-evenlyspaced > ul > li").css({
            width: itemwidth
        });
    });

/*******************************************************/
/* Top Header Flyouts
/*******************************************************/
    $(".td-header-flyouts > ul > li.td-header-flyout, .td-link-taboverlay").each(function() {
        var hideDelayTimer = null;
        var isVIP = false;
        var showDelay = 125;
        var hideDelay = 400;
        var triggerelement = $(this);
        var triggerelementWidth = triggerelement.innerWidth();
        var position = triggerelement.metadata().position;
        var label = triggerelement.find(".td-header-label");
        var labelHeight = label.innerHeight();
        var labelWidth = label.innerWidth();
        var labelOffset = label.offset();
        var labelOffsetTop = labelOffset.top + labelHeight;
        var flyout = triggerelement.find("ul");
        var flyoutWidth = flyout.innerWidth();
        var opentext = $(triggerelement).metadata().opentext;
        var closetext = $(triggerelement).metadata().closetext;
        if (flyoutWidth < triggerelementWidth) flyout.closest('.td-callout').innerWidth(triggerelementWidth-2); 
        if ((position == "left") || (position === undefined) || (position != "right") || (position != "containerleft")) {
            triggerelement.metadata().labelOffsetLeft = labelOffset.left;
        }
        if (position == "right") {
           triggerelement.metadata().labelOffsetLeft = labelOffset.left - flyoutWidth + labelWidth;
        }
        if (position == "containerleft" || position == "containerright") {
            triggerelement.metadata().targetContainer = $("#td-container");
            if (position == "containerleft") {
                triggerelement.metadata().calculateOffset = function() {
                    return this.targetContainer.offset().left;
                };
            } else if (position == "containerright") {
                triggerelement.metadata().flyoutWidth = flyoutWidth;
                triggerelement.metadata().calculateOffset = function() {
                    return this.targetContainer.offset().left + ($("#td-container").innerWidth()) - this.flyoutWidth + 2;
                };
            }
            $(window).resize({
                sender: this
            }, function(eventObject) {
                $(eventObject.data.sender).metadata().labelOffsetLeft = $(eventObject.data.sender).metadata().calculateOffset();
            });
            triggerelement.metadata().labelOffsetLeft = triggerelement.metadata().calculateOffset();
        }

        function showOverlay() {
            $(triggerelement).addClass("td-header-label-hover");
            var css = {};
              
            if($(triggerelement).hasClass("td-link-taboverlay-right")) {
                css.left ="auto";
                css.right = 2;
            } else if ($(triggerelement).hasClass("td-link-taboverlay-center")) {
                css.left = $(triggerelement).width()/2-$(triggerelement).find("ul").width()/2 + 1;
            } else {
                css.left = 0;
            }
            
            $(triggerelement).children("ul").css(css);
          
        }

        function hideOverlay() {
            //console.log("hide");
            $("> ul", triggerelement).css({
                left: -9999
            });
            $(triggerelement).removeClass("td-header-label-hover");
        }
        
        //accessibility concerns
        hideOverlay();
        if (opentext) {
            $(triggerelement).find("a:visible").append("<span class='td-forscreenreader' aria-hidden='true'>" + opentext + "</span>");
        }
        if (closetext) {
            var closelink = "<a class='td-forscreenreader' href='#' aria-hidden='true'>" + closetext + "</a>";
            var targetelement = $("> ul > li", triggerelement);
            targetelement.prepend($(closelink));
            targetelement.append($(closelink));
            targetelement.find("a.td-forscreenreader").on("click", function() {hideOverlay();});
        }
        

        //Detect if user is using keyboard naviagtion
        triggerelement.on('focusin', function() {
            if(isVIP==true) {
                showOverlay();  
            }
        });
        
        triggerelement.on('focusout', function() {
            if(isVIP==true) {
                hideOverlay();
            }
        });
        
        $("body").keydown(function() {
            isVIP=true;
        });
        
        $("body").mousedown(function() {
            isVIP=false;
        });
        
        
        $(this).click(function(e) {
            e.stopPropagation();
            //console.log (this);
            if ($(this).hasClass("td-header-label-hover")){
                hideOverlay();
            }
            else {
                $("#td-nav-level2 > ul > li.td-header-flyout > ul").offset({
                    left: "-9999"
                });
             
                $("#td-nav-level2 > ul > li.td-header-flyout").removeClass("td-header-label-hover");
                    showOverlay();
                $("body").trigger("menuopen", [this]);
            }
        });
        
        //
          $(this).find("ul").click(function(e) {
            e.stopPropagation();
          });
        
        //
        $("body").on("menuopen", function(e, ele) {
            if (ele != triggerelement.get(0)){
            hideOverlay();
            }
        });
         
        //
        $("body").click(function() {
            hideOverlay();
        });
    }); 
/*******************************************************/
/* Top Nav Level 2 Flyouts
/*******************************************************/
    $("#td-nav-level2.td-nav-flyouts > ul > li.td-nav-flyout").each(function() {
        var hideDelayTimer = null;
        var showDelay = 125;
        var hideDelay = 400;
        var triggerelement = $(this);
        var position = $(this).metadata().position;
        var label = $(this).find(".td-nav-level2-label");
        var labelHeight = $(label).innerHeight();
        var labelWidth = $(label).innerWidth();
        var labelOffset = $(label).offset();
        var labelOffsetTop = labelOffset.top + labelHeight;
        var flyout = $(this).find("ul");
        var flyoutWidth = $(this).find("ul").innerWidth();
        var opentext = $(triggerelement).metadata().opentext;
        var closetext = $(triggerelement).metadata().closetext;
        var shimIframe = $("#td-container").find(".shim-iframe");
        var shimIframeHeight = $(this).find("ul").height() - 45;
        if ((position == "left") || (position === undefined) || (position != "right") || (position != "containerleft")) {
            $(this).metadata().labelOffsetLeft = labelOffset.left;
        }
        if (position == "right") {
            $(this).metadata().labelOffsetLeft = labelOffset.left - flyoutWidth + labelWidth;
        }
        if (position == "containerleft" || position == "containerright") {
            $(this).metadata().targetContainer = $("#td-container");
            if (position == "containerleft") {
                $(this).metadata().calculateOffset = function() {
                    return this.targetContainer.offset().left;
                };
            } else if (position == "containerright") {
                $(this).metadata().flyoutWidth = flyoutWidth;
                $(this).metadata().calculateOffset = function() {
                    return this.targetContainer.offset().left + ($("#td-container").innerWidth()) - this.flyoutWidth + 2;
                };
            }
            $(window).resize({
                sender: this
            }, function(eventObject) {
                $(eventObject.data.sender).metadata().labelOffsetLeft = $(eventObject.data.sender).metadata().calculateOffset();
            });
            $(this).metadata().labelOffsetLeft = $(this).metadata().calculateOffset();
        }

        function showOverlay() {
            $(triggerelement).addClass("td-nav-level2-label-hover");
            //was .offset instead of .css
            if (shimIframe.length > 0){
         		shimIframe.css({
         			height: shimIframeHeight,
         			display: 'block',
         			top: $(triggerelement).children("ul").offset().top
         		});
         	}
            $(triggerelement).children("ul").css({
                left: 0
            });
        }

        function hideOverlay() {
            $("> ul", triggerelement).offset({
                left: "-9999"
            });
            $(triggerelement).removeClass("td-nav-level2-label-hover");

            //if ie8 and shim-iframe exists then hide iframe
            
        }

        function hideShimIframe() {
        	if (shimIframe.length > 0 ) {
         		shimIframe.css({
         			display: 'none'
         		});
         	}
        }
        //accessibility concerns
        hideOverlay();
        hideShimIframe();
        if (opentext) {
            //console.log(triggerelement);
            $("> span", triggerelement).append("<span class='td-forscreenreader' aria-hidden='true'>" + opentext + "</span>");
        }
        if (closetext) {
            var closelink = "<a class='td-forscreenreader' href='#' aria-hidden='true'>" + closetext + "</a>";
            var targetelement = $("> ul > li", triggerelement);
            targetelement.prepend($(closelink));
            targetelement.append($(closelink));
            targetelement.find("a.td-forscreenreader").on("click", function() {hideOverlay();});
        }
        
        //add comment
        if(!Modernizr.touch) {

              $(this).mouseenter(function() {
                if (hideDelayTimer) clearTimeout(hideDelayTimer);
                $(triggerelement).data("delay", setTimeout(function() {

                    $("#td-nav-level2 > ul > li.td-nav-flyout > ul").offset({
                        left: "-9999"
                    });
                    $("#td-nav-level2 > ul > li.td-nav-flyout").removeClass("td-nav-level2-label-hover");
                    showOverlay();
                    //$("body").trigger("menuopen", [this]);
                }, showDelay));
            }).mouseleave(function() {
                if (hideDelayTimer) clearTimeout(hideDelayTimer);
                if ($(flyout).not(":visible")) {
                    clearTimeout($(triggerelement).data("delay"));
                    //hideShimIframe();
                }
                hideDelayTimer = setTimeout(function() {
                    hideDelayTimer = null;
                    hideOverlay();
                }, hideDelay);
                
            });
            
            $(this).on('focusin', function() {

                showOverlay();
            });
            
            $(this).on('focusout', function() {
                hideOverlay();
                hideShimIframe();
            });
            
        } 
        else {
         $(this).click(function(e) {
            
            e.stopPropagation();
            
            if ($(this).hasClass("td-nav-level2-label-hover")){
            hideOverlay();
            } 
            else {
                 $("#td-nav-level2 > ul > li.td-nav-flyout > ul").offset({
                     left: "-9999"
                 });
                
                $("#td-nav-level2 > ul > li.td-nav-flyout").removeClass("td-nav-level2-label-hover");
                    showOverlay();
                // $("body").trigger("menuopen", [this]);
            }
          });
          
          $(this).find("ul").click(function(e) {
            e.stopPropagation();
          });
          
          $("body").on("menuopen", function(e, ele) {
            if (ele != triggerelement.get(0)){
            hideOverlay();
            }
          });
           
          $("body").click(function() {
            hideOverlay();
          });
        }
        
    }); 

	$("#td-nav-level2").mouseleave(function() {
		var sIframe = $("#td-container").find(".shim-iframe");
		 	if ( sIframe.length>0){
		 		sIframe.css({
     				display: 'none'
     			});
		 	};
	});
	
/*******************************************************/
/* Overlays
/*******************************************************/
    $(".td-link-overlay").each(function() {
        var distance = 5;
        var time = 250;
        var showDelay = 150;
        var hideDelay = 500;
        var buffer = 4;
        var offsetxvar = 0;
        var offsetyvar = 0;
        var hideDelayTimer = null;
        var triggerelement = $(this);
        var triggertype = $(triggerelement).metadata().triggertype;
        var targetelement = $(triggerelement).metadata().targetelement;
        var targetelement = $(targetelement);
        var position = $(triggerelement).metadata().position;
        var opentext = $(triggerelement).metadata().opentext;
        var closetext = $(triggerelement).metadata().closetext;
        var triggericon = $(triggerelement).find(".td-triggericon");
        if ($(triggericon).length) {
            var alt = $(triggericon).html();
            alt = alt.replace("Expand", "Collapse");
            $(triggericon).text(alt);
        }
        $(targetelement).hide();
        $(triggerelement).prepend("<span class='td-forscreenreader' aria-hidden='true'>" + opentext + "</span> ");
        $(targetelement).prepend("<a class='td-link-icon td-link-icon-close' href='#'>" + closetext + "</a>");
        var closebutton = $(targetelement).find(".td-link-icon-close");
        $(targetelement).append("<a class='td-link-icon td-link-icon-exit' href='#'>" + closetext + "</a>");
        var closebuttonhidden = $(targetelement).find(".td-link-icon-exit");

        function styleOverlay() {
            var triggerelementWidth = triggerelement.innerWidth();
            var triggerelementHeight = triggerelement.innerHeight();
            var triggerposition = $(triggerelement).position();
            offsetx = $(triggerelement).metadata().offsetx;
            offsety = $(triggerelement).metadata().offsety;
            if ((offsetx) != undefined) {
                offsetxvar = offsetx;
            };
            if ((offsety) != undefined) {
                offsetyvar = offsety;
            };
            var targetelementWidth = $(targetelement).outerWidth();
            var targetelementHeight = $(targetelement).outerHeight();
            if (position == "upwardleft") {
                $(targetelement).addClass("td-callout-gradient-ttb");
                $(targetelement).prepend('<div class="td-callout-arrow td-callout-arrow-upwardleft"></div>');
            }
            if (position == "upward") {
                $(targetelement).addClass("td-callout-gradient-ttb");
                $(targetelement).prepend('<div class="td-callout-arrow td-callout-arrow-upward"></div>');
            }
            if (position == "upwardright") {
                $(targetelement).addClass("td-callout-gradient-ttb");
                $(targetelement).prepend('<div class="td-callout-arrow td-callout-arrow-upwardright"></div>');
            }
            if (position == "rightwardup") {
                $(targetelement).addClass("td-callout-gradient-rtl");
                $(targetelement).prepend('<div class="td-callout-arrow td-callout-arrow-rightwardup"></div>');
            }
            if (position == "rightward") {
                $(targetelement).addClass("td-callout-gradient-rtl");
                $(targetelement).prepend('<div class="td-callout-arrow td-callout-arrow-rightward"></div>');
            }
            if (position == "rightwarddown") {
                $(targetelement).addClass("td-callout-gradient-rtl");
                $(targetelement).prepend('<div class="td-callout-arrow td-callout-arrow-rightwarddown"></div>');
            }
            if (position == "downwardright") {
                $(targetelement).addClass("");
                $(targetelement).prepend('<div class="td-callout-arrow td-callout-arrow-downwardright"></div>');
            }
            if (position == "downward") {
                $(targetelement).addClass("");
                $(targetelement).prepend('<div class="td-callout-arrow td-callout-arrow-downward"></div>');
            }
            if (position == "downwardleft") {
                $(targetelement).addClass("");
                $(targetelement).prepend('<div class="td-callout-arrow td-callout-arrow-downwardleft"></div>');
            }
            if (position == "leftwarddown") {
                $(targetelement).addClass("td-callout-gradient-ltr");
                $(targetelement).prepend('<div class="td-callout-arrow td-callout-arrow-leftwarddown"></div>');
            }
            if (position == "leftward") {
                $(targetelement).addClass("td-callout-gradient-ltr");
                $(targetelement).prepend('<div class="td-callout-arrow td-callout-arrow-leftward"></div>');
            }
            if (position == "leftwardup") {
                $(targetelement).addClass("td-callout-gradient-ltr");
                $(targetelement).prepend('<div class="td-callout-arrow td-callout-arrow-leftwardup"></div>');
            }
            if (position == "upwardleft") {
                overlayPositionLeft = -targetelementWidth + triggerelementWidth;
                overlayPositionTop = -targetelementHeight - 15 - buffer;
            };
            if (position == "upward") {
                overlayPositionLeft = -((targetelementWidth / 2) - (triggerelementWidth / 2));
                overlayPositionTop = -targetelementHeight - 15 - buffer;
            };
            if (position == "upwardright") {
                overlayPositionLeft = +0;
                overlayPositionTop = -targetelementHeight - 15 - buffer;
            };
            if (position == "rightwardup") {
                overlayPositionLeft = +triggerelementWidth + 11 + buffer;
                overlayPositionTop = +triggerelementHeight - targetelementHeight - 5;
            };
            if (position == "rightward") {
                overlayPositionLeft = +triggerelementWidth + 11 + buffer;

                overlayPositionTop = -((targetelementHeight / 2) - (triggerelementHeight / 2)) - 5;
            };
            if (position == "rightwarddown") {
                overlayPositionLeft = +triggerelementWidth + 11 + buffer;
                overlayPositionTop = -5;
            };
            if (position == "downwardright") {
                overlayPositionLeft = +0;
                overlayPositionTop = triggerelementHeight + 6 + buffer;
            };
            if (position == "downward") {
                overlayPositionLeft = -((targetelementWidth / 2) - (triggerelementWidth / 2));
                overlayPositionTop = +triggerelementHeight + 6 + buffer;
            };
            if (position == "downwardleft") {
                overlayPositionLeft = +triggerelementWidth - targetelementWidth;
                overlayPositionTop = triggerelementHeight + 6 + buffer;
            };
            if (position == "leftwarddown") {
                overlayPositionLeft = -targetelementWidth - 11 - buffer;
                overlayPositionTop = -5;
            };
            if (position == "leftward") {
                overlayPositionLeft = -targetelementWidth - 11 - buffer;
                overlayPositionTop = -((targetelementHeight / 2) - (triggerelementHeight / 2)) - 5;
            };
            if (position == "leftwardup") {
                overlayPositionLeft = -targetelementWidth - 11 - buffer;
                overlayPositionTop = -targetelementHeight + triggerelementHeight - 5;
            };
            $(targetelement).css({
                top: triggerposition.top + parseInt(offsetyvar) + distance + overlayPositionTop + 'px',
                left: triggerposition.left + parseInt(offsetxvar) + overlayPositionLeft + 'px'
            });
            $(triggericon).addClass("td-triggericon-expanded");
        }

        function unstyleOverlay() {
            $(triggericon).removeClass("td-triggericon-expanded");
            $(targetelement).removeClass("td-callout-gradient-ttb");
            $(targetelement).removeClass("td-callout-gradient-ltr");
            $(targetelement).removeClass("td-callout-gradient-rtl");
            $(targetelement).find(".td-callout-arrow").remove();
        }

        function showOverlay() {
            styleOverlay();
            targetelement.css({
                display: 'block'
            });
            $(targetelement).animate({
                opacity: 1
            });
			$.labelEqualHeight(targetelement);
        }

        function hideOverlay() {
            $(".td-overlay").css({
                display: 'none',
                opacity: 0
            });
            unstyleOverlay();
            forcedOpen = false;
        }
        $(document).click(function() {
            hideOverlay();
        });
        $([targetelement.get(0)]).click(function(e) {
            e.stopPropagation();
        });
        $(closebutton).click(function() {
            hideOverlay();
            $(triggerelement).focus();
            return false;
        });
        $(closebuttonhidden).focus(function() {
            hideOverlay();
            $(triggerelement).focus();
        });

        function isTouchDevice() {
            var el = document.createElement('div');
            el.setAttribute('ongesturestart', 'return;');
            if (typeof el.ongesturestart == "function") {
                return true;
            } else {
                return false;
            }
        }
        if ((triggertype == 'mouseover') && (!(isTouchDevice()))) {
            $([triggerelement.get(0), targetelement.get(0)]).mouseenter(function() {
                if (hideDelayTimer) clearTimeout(hideDelayTimer);
                $(triggerelement).data("delay", setTimeout(function() {
                    showOverlay();
                }, showDelay));
            }).mouseleave(function() {
                if (hideDelayTimer) clearTimeout(hideDelayTimer);
                if ($(targetelement).not(":visible")) {
                    clearTimeout($(triggerelement).data("delay"));
                }
                hideDelayTimer = setTimeout(function() {
                    hideDelayTimer = null;
                    hideOverlay();
                }, hideDelay);
            });
        };
        if ((triggertype == 'click') || (triggertype == 'mouseover')) {
            $([triggerelement.get(0)]).click(function() {
                if ($(targetelement).css('display') == 'none') {
                    $(".td-overlay").css({
                        display: 'none',
                        opacity: 0
                    });
                    showOverlay();
                    $(targetelement).find(".td-link-icon-close").focus();
                    return false;
                } else {
                    if ((triggertype != 'mouseover')) {
                        hideOverlay();
                        $(triggerelement).focus();
                    }
                    return false;
                }
            });
        };
    }); 
/*******************************************************/
/* Modal Windows
/*******************************************************/
    $(".td-link-modal").each(function() {
        var triggerelement = $(this);
        var targetelement = $(triggerelement).metadata().targetelement;
        var truemodal = $(triggerelement).metadata().truemodal;
        var opentext = $(triggerelement).metadata().opentext;
        var closetext = $(triggerelement).metadata().closetext;
        var endtext = $(triggerelement).metadata().endtext;
        var targetelementID = targetelement.substring(1);
        $(triggerelement).append("<span class='td-forscreenreader' id='aria-" + targetelementID + "' aria-hidden='true'> " + opentext + "</span> ");
        $(triggerelement).attr("title", "");
        $(triggerelement).attr("aria-describedby", "aria-" + targetelementID);

        function applyAnchors() {
            if (!(truemodal)) {
                $(targetelement).prepend("<a class='td-link-icon td-link-icon-close' href='#'>" + closetext + "</a>");
                $(targetelement).prepend("<a class='td-link-icon td-link-icon-prefauxclose' tabindex='0'></a>");
                $(targetelement).append("<a class='td-link-icon td-link-icon-exit' href='#'>" + closetext + "</a>");
            }
            if (truemodal) {
                $(targetelement).prepend("<a class='td-link-modal-top' href='#'>Top of window anchor</a>");
                $(targetelement).prepend("<a class='td-link-modal-top-capture' href='#'>Window starts anchor</a>");
                $(targetelement).append("<a class='td-link-modal-bottom' href='#'>Bottom of window anchor</a>");
                $(targetelement).append("<a class='td-link-modal-bottom-capture' href='#'>Window ends anchor</a>");
            }
        }
        applyAnchors();
    });
    $(".td-link-modal").on("click", function(e) {
        var triggerelement = $(this);
        var targetelement = $(triggerelement).metadata().targetelement;
        var truemodal = $(triggerelement).metadata().truemodal;
		var fixedmodal = $(triggerelement).metadata().fixedmodal;
		
        function showModal() {
            $(document.body).append($(targetelement).detach());
            $.fn.center = function() {
				if (fixedmodal) {
				  this.css("position", "fixed");
				  this.css("top", Math.max(0, ($(window).height() - this.outerHeight()) / 2) + "px");
				  this.css("left", Math.max(0, ($(window).width() - this.outerWidth()) / 2) + "px");
				  return this;
				}else {
				  this.css("position", "absolute");
				  this.css("top", Math.max(0, (($(window).height() - this.outerHeight()) / 2) + $(window).scrollTop()) + "px");
				  this.css("left", Math.max(0, (($(window).width() - this.outerWidth()) / 2) + $(window).scrollLeft()) + "px");
				  return this;
				}
            };
            if (!(truemodal)) {
                $("body").prepend("<div class='td-modal-mask td-modal-mask-escapable'>&nbsp;</div>");
            } else {
                $("body").prepend("<div class='td-modal-mask'>&nbsp;</div>");
            }
            $(".td-modal-mask").css("height", $(document).height() + "px");
            $(targetelement).center();
            $(targetelement).show();
            if (!(truemodal)) {
                $(targetelement).find(".td-link-icon-close").focus();
            }
            if (truemodal) {
                $(targetelement).find(".td-link-modal-top").focus();
            }
            $(targetelement).addClass("td-modal-active");
        }

        function hideModal() {
            $(targetelement).removeClass("td-modal-active");
            $(targetelement).hide();
            $(".td-modal-mask").remove();
            $(triggerelement).focus();
        }
        if (!(truemodal)) {
            $(targetelement).on("click", ".td-link-icon-close, .td-link-icon-exit", function(e) {
                hideModal();
                return false;
            });
            $(targetelement).on("focus", ".td-link-icon-exit, .td-link-icon-prefauxclose", function(e) {
                hideModal();
            });
            $('body').on("click", ".td-modal-mask-escapable", function(e) {
                hideModal();
            });
            $(targetelement).on("keyup", function(e) {
                if (e.keyCode == 27) {
                    hideModal();
                }
            });
        }
        if (truemodal) {
            $(targetelement).on("click", ".td-link-closemodal", function(e) {
                hideModal();
                return false;
            });
            $(targetelement).on("focus", ".td-link-modal-top-capture", function(e) {
                $(".td-link-modal-bottom").focus();
            });
            $(targetelement).on("focus", ".td-link-modal-bottom-capture", function(e) {
                $(".td-link-modal-top").focus();
            });
            $(targetelement).on("click", ".td-link-modal-top", function(e) {
                return false;
            });
            $('body').on("click", ".td-modal-mask", function(e) {
                $(".td-link-modal-top").focus();
                return false;
            });
            $(targetelement).on("keyup", function(e) {
                if (e.keyCode == 27) {
                    hideModal();
                }
            });
        } /* Show/hide modal on trigger click */
        if (!$(targetelement).hasClass("td-modal-active")) {
            showModal();
			$.labelEqualHeight(targetelement);
			$(".td-modal-mask").css("height", $(document).height() + "px");

			
        }
        return false;
    }); 
/*******************************************************/
/* Row Lists
/*******************************************************/
    $("ul.td-rowlist li > :first-child").addClass("first-child");
    $("ul.td-rowlist li > :last-child").addClass("last-child");
    $("ul.td-rowlist li:first-child").each(function() {
        $(this).prepend("<div class='td-rowlist-divider td-rowlist-divider-first'>");
    });
    $("ul.td-rowlist li").each(function() {
        $(this).append("<div class='td-rowlist-divider'>");
    });
    $("img.td-rowlist-icon").each(function() {
        var iconHeight = $(this).height();
        iconHeight = 0 - (iconHeight / 2);
        $(this).css("margin-top", iconHeight);
    });
    $("ul.td-rowlist li").has(".td-rowlist-icon-right").each(function() {
        var padding = ($(this).find("img.td-rowlist-icon-right").width()) + 24;
        $(this).css("padding-right", padding);
    });
    $("ul.td-rowlist li").has(".td-rowlist-icon-left").each(function() {
        var padding = ($(this).find("img.td-rowlist-icon-left").width()) + 24;
        $(this).css("padding-left", padding);
    }); 
/*******************************************************/
/* Push-Up 
/*******************************************************/    //
    $('.td-push-up').each(function(index, element) {
        $(this).css('margin-top', '-' + $(this).metadata().val + 'px');
    });
	
	// nested tabs :: load active tab content in nested tabs
	$(".td-tabs li").on("click", function(e) {
        e.preventDefault();
        var hashLink, subHashLink;
        hashLink = $(this).find('a').attr('href');
        subHashLink = $(hashLink).find('.td-tabs-active a').attr('href');
        nestedTabs(subHashLink);
    });
	
	
	
});

/*******************************************************/
/* Force PIE to update when this function is called
/*******************************************************/
function PIErefresh() {
            if (window.PIE) {
                $("a.td-link-toggle span.td-triggericon, hr.td-divider-fade, .td-button, .td-callout:not(.td-modal), .td-fauxbgimage, .td-banner img, .td-modal-mask, .td-cs-primary, .td-cs-secondary, .td-cs-tertiary:not(.td-modal), .td-cs-tertiary-light, .td-label").each(function() {
                    PIE.attach(this);
                });
            }
};
/*******************************************************/
/* Equal Heights V2
/*******************************************************/
$.equalHeights= function () {
	/*address nested callout bug and tolerates application of equal heights to rows that may contain less than two callouts*/
	 $(".td-equalcalloutheight").each(function() {
		var selected = $(this).find(".td-callout:not(.td-modal)").parent().siblings().children('.td-callout');
        if(selected.length>1) selected.equalHeightColumns();
     });
    $(".td-equalcalloutheightanimate").each(function() {
		var selected = $(this).find(".td-callout:not(.td-modal)").parent().siblings().children('.td-callout');
        if(selected.length>1) selected.equalHeightColumns();
     });
};
function flushBottom() {
    //edge stick calculation

    $('.td-flush-bottom').each(function(index, element) {
        $(this).parent().css('line-height', 0);
        var marginCalc, newMargin, rowHeight = $(this).closest('.td-layout-row').outerHeight();
        marginCalc = (rowHeight - $(this).outerHeight());
        newMargin = 'margin-top:' + marginCalc + 'px !important';
        //set top margins for edge stick
        addInlineAttr($(this), newMargin);
    });
};
function addInlineAttr(target, style) {
    //check for inline styles and append if exists
    $(target).attr('style', function(i, s) {
        if (typeof s === 'undefined') {
            return style;
        } else {
            //check if last chr is space / semicolon
            s = $.trim(s);
            if (s.substr(s.length - 1) == ';') {
                return s + newMargin;
            } else {
                return s + ';' + style;
            }
            return s + style;
        }
    });
};

function nestedTabs(subHashLink) {
    if (subHashLink !== undefined) {
        //j(subHashLink);
        $(subHashLink).fadeIn();
        subHashLink = $(subHashLink).find('.td-tabs-active a').attr('href');
        nestedTabs(subHashLink);
    } 
};
$.validateRadioCheckbox = function (prevName, previous) {
    var current = $(document.activeElement),
        currName = current.attr('name');
    if (prevName === currName && previous.attr('type') === current.attr('type')) {
        return;
    }
    if (current.tdValidate()) {
        previous.valid();
    }
};

$.debuglog =function (v) {
    //console.log(v);
};

$.validateCustom2 = function(currentFormId, currIdx) {
    if (!$.validation.formMaster[currIdx].numberOfInvalids()) return;
    firstErrorField = $($.validation.formMaster[currIdx].errorList[0].element);
    $('html, body').animate({
        scrollTop: firstErrorField.offset().top - 50
    }, 800);
    //set focus after a delay allowing scroll to complete and errors displayed
    //this avoids conflict between highlight and errorhandler
    setTimeout(function() {
        $(firstErrorField).focus();
    }, 0);
};

$.validateCustom = function (currentFormId, currIdx) {
    //displays number of invalid required fields in the current form
    if ($(currentFormId).hasClass('td-error-top')) {
        if ($.validation.formMaster[currIdx].numberOfInvalids() === 0) {
            $(currentFormId).find(".errorDisplay").hide();
        } else {
            //console.log('ok');
            $(currentFormId).find(".errorDisplay").show().find('p').text("You missed " + $.validation.formMaster[currIdx].numberOfInvalids() + " field(s)");
        }
    }
};

$.getOption = function(selectOptions) {
    //get the current selected option and display it
    selected = selectOptions.find("option").filter(':selected');
    if (!$('html').hasClass('ie8')) {
        $(selectOptions).siblings('span').html(selected.text());
    }
};
$.labelEqualHeight = function(elem) {
    //equalize height of radio/ checkbox labels with fieldset that has eqheight class
    var thisSel = $(elem).find('.eqheight');
    thisSel.each(function(index, element) {
        var height = 0;
        var allcards = $(this).find('.card'),
            allLabels = $(this).find('.td-label');
        //reset height
        allcards.find('.td-label-content').css('height', '');
        allLabels.find('.td-callout-content').css('height', '');
        allcards.each(function(index, element) {
            if ($(this).outerHeight() > height) {
                height = $(this).outerHeight();
            }
        });
        allLabels.each(function(index, element) {
            if ($(this).outerHeight() > height) {
                height = $(this).outerHeight();
            }
        });
        //set height
        allcards.find('.td-label-content').outerHeight(height);
        allLabels.find('.td-callout-content').outerHeight(height);
    });
};
function unique(prefix) {
    return prefix + '-' + Math.round(Math.random() * 10000);
};
/*function limitText(limitField, limitNum) {
    if (limitField.value.length > limitNum) {
        limitField.value = limitField.value.substring(0, limitNum);
    }
}*/

$(window).load(function() {
    $.labelEqualHeight('body');
	$.equalHeights();
	$(".td-JShide").hide(); 
    //add hidden html to force image load for label states
	var isForm = $('form.td-form, form.td-form-compact');
	if (isForm.length > 0) {
    $('body').append('<span class="td-image-loader"><span id="checkLargeError"></span><span id="checkLargeChecked"></span><span id="checkLargeCheckedHover"></span><span id="checkSmallError"></span><span id="checkSmallChecked"></span><span id="checkSmallCheckedHover"></span><span id="radioLargeError"></span><span id="radioLargeChecked"></span><span id="radioLargeCheckedHover"></span><span id="radioSmallError"></span><span id="radioSmallChecked"></span><span id="radioSmallCheckedHover"></span></span>');
	}	
});

/* 2014-02-17 */
$(window).resize(function() {
// add all functions that require recalculation on mobile orientation change
	$.equalHeights();	
	$.labelEqualHeight('body');	

});
//ajax handler
$(document).ajaxSuccess(function() {
PIErefresh(); // update pie function
});