function BrowserCheck(){
	this.ua = navigator.userAgent.toLowerCase(); 
	
	// get the unmodified (case sensitive) user agent. There was a bug causing some computers to identity to 
	// RSA as a mobile device when the user agent was all lower case.
	this.original_ua = navigator.userAgent;

   	// browser engine name
   	this.isAppleWebKit = (this.ua.indexOf('applewebkit') != -1);
   	this.isGecko       = (this.ua.indexOf('gecko') != -1&&this.ua.indexOf('safari') == -1);

   	// browser name
	this.isSafari = (this.ua.indexOf('safari') != - 1);
   	this.isOpera = (this.ua.indexOf('opera') != -1); 
   	this.isAol = (this.ua.indexOf('aol') != -1); 
   	this.isIE = (this.ua.indexOf('msie') != -1 && !this.isOpera && (this.ua.indexOf('webtv') == -1) ); 
   	this.isMozilla = (this.isGecko && this.ua.indexOf('gecko/') + 14 == this.ua.length);
   	this.isFirefox = (this.ua.indexOf('firefox/') != -1);
   	this.isNS = (this.ua.indexOf('netscape') != -1);
   	this.isNSold = ( ( (this.ua.indexOf('mozilla') != -1) && !this.isNS && !this.isOpera && !this.isSafari && !this.isFirefox && (this.ua.indexOf('spoofer') == -1) && (this.ua.indexOf('compatible') == -1) && (this.ua.indexOf('webtv') == -1) && (this.ua.indexOf('hotjava') == -1) ) );	
   	
   	// spoofing and compatible browsers
   	this.isIECompatible = ( (this.ua.indexOf('msie') != -1) && !this.isIE);
   	this.isNSCompatible = ( (this.ua.indexOf('mozilla') != -1) && !this.isNS && !this.isMozilla);
   
   	// rendering engine versions
   	this.geckoVersion = ( (this.isGecko) ? this.ua.substring( (this.ua.lastIndexOf('gecko/') + 6), (this.ua.lastIndexOf('gecko/') + 14) ) : -1 );
   	this.equivalentMozilla = ( (this.isGecko) ? parseFloat( this.ua.substring( this.ua.indexOf('rv:') + 3 ) ) : -1 );
   	this.appleWebKitVersion = ( (this.isAppleWebKit) ? parseFloat( this.ua.substring( this.ua.indexOf('applewebkit/') + 12) ) : -1 );
   
   	// browser version - this actually has the full version in it, major and minor
   	// correct version number
   	if (this.isNSold) {
   		this.fullVersion = parseFloat(navigator.appVersion);
   	}
   	else if (this.isNS) {
      		this.fullVersion = parseFloat( this.ua.substring( this.ua.indexOf('netscape/') + 9) );
   	}
   	else if (this.isMozilla) {
   	   	this.fullVersion = parseFloat( this.ua.substring( this.ua.indexOf('rv:') + 3 ) );
   	}
   	else if (this.isIE) {
   	   	this.fullVersion = parseFloat( this.ua.substring( this.ua.indexOf('msie ') + 5 ) );
   	}
   	else if (this.isSafari) {
   	   	this.fullVersion = parseFloat( this.ua.substring( this.ua.lastIndexOf('safari/') + 7 ) );
   	}
   	else if (this.isOpera) {
   	   	this.fullVersion = parseFloat( this.ua.substring( this.ua.indexOf('opera') + 6 ) );
   	}
   	else if (this.isFirefox) {
   	   	this.fullVersion = this.ua.substring( this.ua.indexOf('firefox/') + 8 );
   	}
      
   	this.majorVersion = parseInt(this.fullVersion); 
   
   	// os 
   	this.isWin = (this.ua.indexOf('win') != -1);
   	this.isWin32 = (this.isWin && ( this.ua.indexOf('95') != -1 || this.ua.indexOf('98') != -1 || this.ua.indexOf('nt') != -1 || this.ua.indexOf('win32') != -1 || this.ua.indexOf('32bit') != -1) );
   	this.isWinXP = (this.isWin && ( this.ua.indexOf('xp') != -1))
   	this.isMac = (this.ua.indexOf('mac') != -1);
   	this.isUnix = (this.ua.indexOf('unix') != -1 || this.ua.indexOf('sunos') != -1 || this.ua.indexOf('bsd') != -1 || this.ua.indexOf('x11') != -1)
   	this.isLinux = (this.ua.indexOf('linux') != -1);
   
   	// specific browser shortcuts
   	// here we can make any matched version to the existing browser checking
   	this.isNS4x = (this.isNS && this.majorVersion == 4);
   	this.isNS40x = (this.isNS4x && this.fullVersion < 4.5);
   	this.isNS47x = (this.isNS4x && this.fullVersion >= 4.7);
   	this.isNS6x = (this.isNS && this.majorVersion == 6);
   	this.isNS7x = (this.isNS && this.majorVersion == 7);
   	//IE's
   	this.isIE4x = (this.isIE && this.majorVersion == 4);
   	this.isIE5x = (this.isIE && this.majorVersion == 5);
   	this.isIE55 = (this.isIE && this.fullVersion == 5.5);
   	this.isIE6x = (this.isIE && this.majorVersion == 6);
   	//mac crap
   	this.isIE4xMac = (this.isIE4x && this.isMac);
   	
   	this.isOnSupportedBrowserList = ((this.isIE && this.fullVersion >= 5.5) || (this.isNS && this.majorVersion >= 7) || (this.isMozilla && this.majorVersion >= 1) || (this.isSafari && this.majorVersion >= 1) || (this.isFirefox && this.majorVersion >= 1));
}