	String.prototype.trim = function () {
	    return this.replace(/^\s*/, "").replace(/\s*$/, "");
	}

	function setErrorBlock(errMsg)
	{
		if ( errMsg != "" ) {
			document.getElementById('errorMessage').innerHTML=errMsg;
			document.getElementById('errorMessage').style.display = '';
			document.getElementById('errorMessage').focus();
		}
	}
	
	function emptyField(txt)
	{
		return (txt.value.length == 0);
	}

	
	function setDevicePrintFormFields(formName)
	{		
		var browser = new BrowserCheck();
		//alert(document.getElementById(formName+"deviceAgent"));
		
		// Modifying the deviceAgent value to be the case sensitive userAgent value instead.
		// this fixes a bug where some devices were incorrectly identifying to RSA as mobile
		// document.getElementById(formName+":deviceAgent").value = browser.ua;
		document.getElementById(formName+":deviceAgent").value = browser.original_ua;
		
		document.getElementById(formName+":platform").value = navigator.platform;
		document.getElementById(formName+":osVersion").value = navigator.appVersion;
		
	if (browser.isIE) {
		document.getElementById(formName+":osMinorVersion").value = navigator.appMinorVersion;
			document.getElementById(formName+":cpuClass").value = navigator.cpuClass;
			document.getElementById(formName+":browserLanguage").value = navigator.browserLanguage;
		} else if (browser.isMozilla) {
			document.getElementById(formName+":browserLanguage").value =  navigator.language;
		}
		 
		//Display Device Print Data
		if(self.screen){
			document.getElementById(formName+":colorDepth").value = screen.colorDepth;
			document.getElementById(formName+":width").value = screen.width;
			document.getElementById(formName+":height").value = screen.height;
			document.getElementById(formName+":availableHeight").value = screen.availHeight;
		}
		//Installed Software Device Print Data
		SEP = "|";
		isFirst = true;
		if (navigator.plugins.length > 0) {
			// since opera will give the full path of the file, we will
			// just extract the filenames, ignoring descripton and length since filenames are distinguished enough
			if (browser.isOpera)
			{
				temp = "";
				lastDir = "Plugins";
				for (i = 0; i < navigator.plugins.length; i++) {
					plugin = navigator.plugins[i];
					if (isFirst==true) {
						temp += stripFullPath(plugin.filename, lastDir);
						isFirst=false;
					} else {
						temp += SEP + stripFullPath(plugin.filename, lastDir);
					}
				}
				document.getElementById(formName+":browserPlugins").value = screen.availHeight;
				
			} else {
				temp = "";
				for (i = 0; i < navigator.plugins.length; i++) {
					plugin = navigator.plugins[i];
					if (isFirst==true) {
						temp += plugin.filename;
						isFirst=false;
					} else {
						temp += SEP + plugin.filename;
					}
				}							
			}		
		}
	
		document.getElementById(formName+":timeZoneOffset").value = getTimezoneOffset();
		document.getElementById(formName+":clientCanStoreDeviceId").value = canStoreDeviceId();		
		
		//check that the function add_devicePrint() exists
		if(typeof(window.add_deviceprint) == 'function') 
		{
			// function exists, so we can now call it
			document.getElementById(formName+":devicePrint").value=add_deviceprint();
		}
		else
		{
			document.getElementById(formName+":devicePrint").value="add_devicePrint not found";
		}
	}
	function forwardTo(action,form){
		var x=document.getElementById(form);
		x.action = action;
		x.submit();
		return true;
	}
	function getTimezoneOffset () {	
		
		var timezoneOffset = (new Date().getTimezoneOffset());				
		return timezoneOffset;
	}
	
	function activeXDetect(componentClassID) {
	   componentVersion = document.body.getComponentVersion('{'+componentClassID+'}','ComponentID');
	   return (componentVersion != null) ? componentVersion : false;
	}
	var flashCapable;
	function canStoreDeviceId()
	{
		var deviceIdStorable = false;
	
		if(canStoreCookie()){
			
			deviceIdStorable = true;
		
		} else {
			
			deviceIdStorable = flashCapable;
		}
		
		return deviceIdStorable;
	}

	function canStoreCookie() 
	{					
			
		var cookieEnabled=(navigator.cookieEnabled)? true : false
		//if not IE4+ nor NS6+
		if (typeof navigator.cookieEnabled=="undefined" && !cookieEnabled)
		{ 
			document.cookie="testcookie"
			cookieEnabled=(document.cookie.indexOf("testcookie")!=-1)? true : false
		}
		return cookieEnabled;	
	}

	function stripIllegalChars(value) {
		t = "";
		//first we need to escape any "\n" or "/" or "\"
		value = value.toLowerCase();
		for (i = 0; i < value.length; i++) {
			if (value.charAt(i) != '\n' && value.charAt(i) != '/' && value.charAt(i) != "\\")
			{
				t += value.charAt(i);
			}
			else if (value.charAt(i) == '\n')
			{
				t += "n";
			}
		}
		return t;
	}
	
	function stripFullPath(tempFileName, lastDir) {
		fileName = tempFileName;

		//anything before the last lastDir will be lost
		filenameStart = 0;
		filenameStart = fileName.lastIndexOf(lastDir);

		if (filenameStart < 0)
			filenameStart = 0;
		filenameFinish = fileName.length;
		
		fileName = fileName.substring(filenameStart + lastDir.length, filenameFinish);

		return fileName;
	}
	
		function switchContent() {
				var y;
				var x=document.getElementById('MFAsetupForm');
				var str;
				for (i in x)
				{
					if(x.elements[i]!=null){
						if(x.elements[i]!=0){
				 			str=x.elements[i].id;
				 			
				 			var myStr=new String(str);
				 			if(myStr!=null){
				 				if(myStr.indexOf('questionID')!=-1){	 				
					 				
				 					var temp = new String(document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':questionID').value);
				 			
				 				if(temp!=""){			 
				 					
				 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':commandlink').style.display='inline';
				 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':question').style.display='inline';
				 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':selectBox').style.display='none';
				 				}else{
				 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':selectBox').style.display='inline';
				 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':commandlink').style.display='none';
				 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':question').style.display='none';
				 				}
				 				}
				 			}
				 		}
					}
				
				}	
				document.getElementById('MFAsetupForm:repeatId:0:answer').focus();
			}
		
		function switchContentNoFocus() {
			// This version of switch content removes the "focus()" call at the end of the method
			// Introduced for the Accessibility project to fix tabbing order.
			// New method needed to avoid impacting MBNA which is out of scope for this project.
			var y;
			var x=document.getElementById('MFAsetupForm');
			var str;
			for (i in x)
			{
				if(x.elements[i]!=null){
					if(x.elements[i]!=0){
			 			str=x.elements[i].id;
			 			
			 			var myStr=new String(str);
			 			if(myStr!=null){
			 				if(myStr.indexOf('questionID')!=-1){	 				
				 				
			 					var temp = new String(document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':questionID').value);
			 			
			 				if(temp!=""){			 
			 					
			 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':commandlink').style.display='inline';
			 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':question').style.display='inline';
			 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':selectBox').style.display='none';
			 				}else{
			 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':selectBox').style.display='inline';
			 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':commandlink').style.display='none';
			 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':question').style.display='none';
			 				}
			 				}
			 			}
			 		}
				}
			
			}	
		}
		
		function switchContentSFA() 
		{			
			var y;
				var x=document.getElementById('mfaUpdate');
				var str;
				for (i in x)
				{
					if(x.elements[i]!=null){
						if(x.elements[i]!=0){
				 			str=x.elements[i].id;				 			
				 			var myStr=new String(str);
				 			if(myStr!=null){
				 				if(myStr.indexOf('questionID')!=-1){	 				
				 				
				 					var temp = new String(document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':questionID').value);
				 			
				 				if(temp==""){				 				
				 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':commandlink').style.display='none';
				 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':question').style.display='none';
				 				}else{
				 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':selectBox').style.display='none';
				 				}
				 				}
				 			}
				 		}
					}
				
				}
				if(document.getElementById('mfaUpdate:repeatId:0:answer') != null)
				{
					document.getElementById('mfaUpdate:repeatId:0:answer').focus();
				}
		}
		
		function switchContentSFANoFocus() 
		{		
			// This version of switch content removes the "focus()" call at the end of the method
			// Introduced for the Accessibility project to fix tabbing order.
			// New method needed to avoid impacting MBNA which is out of scope for this project.
			var y;
				var x=document.getElementById('mfaUpdate');
				var str;
				for (i in x)
				{
					if(x.elements[i]!=null){
						if(x.elements[i]!=0){
				 			str=x.elements[i].id;				 			
				 			var myStr=new String(str);
				 			if(myStr!=null){
				 				if(myStr.indexOf('questionID')!=-1){	 				
				 				
				 					var temp = new String(document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':questionID').value);
				 			
				 				if(temp==""){				 				
				 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':commandlink').style.display='none';
				 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':question').style.display='none';
				 				}else{
				 					document.getElementById(myStr.substring(0, myStr.lastIndexOf(':'))+':selectBox').style.display='none';
				 				}
				 				}
				 			}
				 		}
					}
				
				}
		}
	
			var numberOfQuestions = 5;
		var clickCounter = new Array(numberOfQuestions);
		for (var j=0; j<numberOfQuestions; j++) {
			clickCounter[j] = 0;
		}

		function clickDDL(e) {
			var i = getId(e);
			var beforeElement = getBeforeElement(e);

			if (clickCounter[i] == 0) {
				clickCounter[i] = 1;				
			} else {
				if (document.getElementById(beforeElement+i+':selectBox').selectedIndex > 0) {
					lockQuestion(e);
					clickCounter[i] = 0;					
				}else if (document.getElementById(beforeElement+i+':selectBox').selectedIndex == 0){
					document.getElementById(beforeElement+i+':questionID').value = "";
				}
				}			
		}
		
		function pageLoadMFAUpdateQuestions(e){
			var i = getId(e);
			var beforeElement = getBeforeElement(e);

			for (var i=0; i<numberOfQuestions; i++) {
				if (document.getElementById(beforeElement+i+':selectBox'))
					if (document.getElementById(beforeElement+i+':selectBox').selectedIndex > 0) {
						lockQuestion(e);
					}
			}
			if (document.getElementById(beforeElement+'0:selectBox').style.disabled != "disabled") {
				document.getElementById(beforeElement+'0:selectBox').focus();
			}
		}
		
		function clearTextBox(e){
			var i = getId(e);
			var beforeElement = getBeforeElement(e);
			
			document.getElementById(beforeElement+i+':answer').value="";
			document.getElementById(beforeElement+i+':confirmAnswer').value="";
		}

		function lockQuestion(e) {
			var i = getId(e);
			var beforeElement = getBeforeElement(e);
			
			if (document.getElementById(beforeElement+i+':selectBox').selectedIndex > 0) {
				var text = document.getElementById(beforeElement+i+':selectBox').options[document.getElementById(beforeElement+i+':selectBox').selectedIndex].text;				
				document.getElementById(beforeElement+i+':selectBox').style.display = "none";				
				document.getElementById(beforeElement+i+':question').innerHTML = text;	
				document.getElementById(beforeElement+i+':questionHidden').value = text;			   
			    document.getElementById(beforeElement+i+':questionID').value = new String(document.getElementById(beforeElement+i+':selectBox').value);	
				document.getElementById(beforeElement+i+':question').style.display = "inline";
				document.getElementById(beforeElement+i+':commandlink').style.display = "inline";
				document.getElementById(beforeElement+i+':selectBox').style.disabled = "disabled";
				document.getElementById(beforeElement+i+':answer').focus();
			}
		}
		
		function unlockQuestion(e) {
			var i = getId(e);
			var beforeElement = getBeforeElement(e);
			var selectBoxList=document.getElementById(beforeElement+i+':selectBox');			
			var selectedItem = document.getElementById(beforeElement+i+':question').innerHTML;
			for(j=0;j<selectBoxList.length;j++){
				var textSelectBoxList = selectBoxList.options[j].text;			
				if(textSelectBoxList!=null && (textSelectBoxList.trim() == selectedItem.trim())){
					selectBoxList.selectedIndex=j;				
					break;
				}
			}
			document.getElementById(beforeElement+i+':question').style.display = "none";	
			document.getElementById(beforeElement+i+':commandlink').style.display = "none";
			document.getElementById(beforeElement+i+':selectBox').style.display = "inline";
			document.getElementById(beforeElement+i+':selectBox').focus();
		}

		function getId(e){
			var eventElementID = getEventElementID(e);
			
			eventElementID = eventElementID.substring(0, eventElementID.lastIndexOf(':'));
			var id = eventElementID.substring(eventElementID.lastIndexOf(':')+1,eventElementID.length);
			
			return id;
		}

		function getFormName(e){
			var eventElementID = getEventElementID(e);
			var formName = eventElementID.substring(0, eventElementID.indexOf(':'));

			return formName;
		}

		function getBeforeElement(e){
			var eventElementID = getEventElementID(e);
			eventElementID = eventElementID.substring(0, eventElementID.lastIndexOf(':'));
			var beforeElement = eventElementID.substring(0, eventElementID.lastIndexOf(':')+1);

			return beforeElement;
		}
		
		function getEventElementID(e){
			var eventElementID;
			var myArray=new Array();
			if (!e){
			  var e=window.event;
			 }
			if (e.target){
				if(e.target.id!= ""){
				  	 eventElementID=e.target.id;					
				} else {
					eventElementID=e.target.parentNode.id;
				}
			}
			else if (e.srcElement){
			  eventElementID=e.srcElement.id;
			}			
			return eventElementID;
		}
