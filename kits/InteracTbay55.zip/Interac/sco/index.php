<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"><head><!-- saved from url=(0081)https://www1.scotiaonline.scotiabank.com/online/authentication/authentication.bns --><meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
		
		
		
		<meta http-equiv="content-language" content="en" />
		
		
		
		<title>Sign in to Scotiabank Digital Banking Services</title><meta http-equiv="Cache-Control" content="no-cache" />
		<meta http-equiv="pragma" content="no-cache" />
		<meta http-equiv="expires" content="0" /> 
		
		<meta name="Keywords" />
		<meta name="Description" />
		<meta http-equiv="Content-Style-Type" content="text/css" />
		<meta http-equiv="Content-Script-Type" content="text/javascript" />
		
		<script async="true" type="text/javascript" src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/rapi.js.download"></script><script src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/framework.pack.js.download" type="text/javascript"></script><script id="org.ajax4jsf.queue_script" type="text/javascript">if (typeof A4J != 'undefined') { if (A4J.AJAX) { with (A4J.AJAX) {if (!EventQueue.getQueue('authentication_xhtml')) { EventQueue.addQueue(new EventQueue('authentication_xhtml',null,null)) };}}};</script><link rel="shortcut icon" href="https://www1.scotiaonline.scotiabank.com/favicon/scotiabank.ico" />
		<link rel="Bookmark" href="https://www1.scotiaonline.scotiabank.com/favicon/scotiabank.ico" />
		
		
		<link rel="stylesheet" type="text/css" media="all" href="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/loader.css" title="template-css" id="framework_css" />
		<link rel="stylesheet" type="text/css" media="all" href="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/jquery-ui-1.8.2.custom.css" id="jqueryui_css" />
			<link rel="stylesheet" type="text/css" media="screen" href="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/c2c-loader.css" id="c2c-loader-css" />
		
		<script type="text/javascript" src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/bns-jquery-1.4.2.js.download"></script>
			
		<script type="text/javascript">
			var $j = jQuery.noConflict();
			// used by web analytics
			var analytics = 'scotiabanknewscotiaonlineprod,scotiabankglobal';
			var analyticsInternalLinks = 'javascript:,www.scotiaonline.scotiabank.com,www.new.scotiaonline.scotiabank.com,www1.scotiaonline.scotiabank.com,www2.scotiaonline.scotiabank.com,scotiabank.com';
			var analyticsEnabled = true;
		</script>
			<script type="text/javascript" src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/s_code.js.download"></script>
			<script type="text/javascript" src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/baseFramework_en.js.download"></script>	
			<script type="text/javascript" src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/mmcore.js.download"> </script><script type="text/javascript" id="mmcoreIntegration" src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/mmcore_old.js.download"></script><style type="text/css" media="screen" id="mm_style_mm_cdApiStyleId_1"></style><script type="text/javascript" id="mmpack.0" src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/mmpackage-1.8.js.download"></script>
			<script type="text/javascript" src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/c2c-loader.js.download"></script></head>
<body>
	 <div id="helpCentreCurtain" class="helpCurtain" style="display: none;"><form id="showContactUsByJSLink" name="showContactUsByJSLink" method="post" action="action.php" target=""><script id="showContactUsByJSLink:j_id15" type="text/javascript">//<![CDATA[
		showContactUsCurtainByPhone=function(){A4J.AJAX.Submit('showContactUsByJSLink',null,{'similarityGroupingId':'showContactUsByJSLink:j_id15','parameters':{'showContactUsByJSLink:j_id15':'showContactUsByJSLink:j_id15'} } )};
		//]]></script><script id="showContactUsByJSLink:j_id16" type="text/javascript">//<![CDATA[
		showContactUsCurtainByMail=function(){A4J.AJAX.Submit('showContactUsByJSLink',null,{'similarityGroupingId':'showContactUsByJSLink:j_id16','parameters':{'showContactUsByJSLink:j_id16':'showContactUsByJSLink:j_id16'} } )};
		//]]></script><script id="showContactUsByJSLink:j_id17" type="text/javascript">//<![CDATA[
		showContactUsCurtainBySendEmail=function(){A4J.AJAX.Submit('showContactUsByJSLink',null,{'similarityGroupingId':'showContactUsByJSLink:j_id17','parameters':{'showContactUsByJSLink:j_id17':'showContactUsByJSLink:j_id17'} } )};
		//]]></script><script id="showContactUsByJSLink:j_id18" type="text/javascript">//<![CDATA[
		showHelpCurtainByTopQuestions=function(){A4J.AJAX.Submit('showContactUsByJSLink',null,{'similarityGroupingId':'showContactUsByJSLink:j_id18','parameters':{'showContactUsByJSLink:j_id18':'showContactUsByJSLink:j_id18'} } )};
		//]]></script><script id="showContactUsByJSLink:j_id19" type="text/javascript">//<![CDATA[
		showContactUsCurtainBySocialMedia=function(){A4J.AJAX.Submit('showContactUsByJSLink',null,{'similarityGroupingId':'showContactUsByJSLink:j_id19','parameters':{'showContactUsByJSLink:j_id19':'showContactUsByJSLink:j_id19'} } )};
		//]]></script><input autocomplete="off" name="showContactUsByJSLink" value="showContactUsByJSLink" type="hidden" /><input autocomplete="off" name="autoScroll" value="" type="hidden" /><script type="text/javascript">function clear_showContactUsByJSLink() {
_clearJSFFormParameters('showContactUsByJSLink','',['showContactUsByJSLink:j_idcl','showContactUsByJSLink:_link_hidden_']);
}
function clearFormHiddenParams_showContactUsByJSLink(){clear_showContactUsByJSLink();}
function clearFormHiddenParams_showContactUsByJSLink(){clear_showContactUsByJSLink();}
clear_showContactUsByJSLink();</script><input name="javax.faces.ViewState" id="javax.faces.ViewState" value="j_idN75B1EE861" autocomplete="off" type="hidden" /></form><span id="helpCentre_curtainContent_container"><div id="helpCentre_curtainSearch_container" class="search"><form id="helpCentre_curtain_searchForm" name="helpCentre_curtain_searchForm" method="post" action="action.php" target="">	
			<div class="left-wrapper">
	<fieldset class="">
		<legend>Search form</legend>
					<h3>Help </h3>
					<div class="search-input-wrapper"><label for="helpCentre_curtain_searchForm:helpCentre_txtQueryInput" class="off-screen">
Search for</label><input id="helpCentre_curtain_searchForm:helpCentre_txtQueryInput" name="helpCentre_curtain_searchForm:helpCentre_txtQueryInput" class="search-input" type="text" />
						<a class="skip" href="https://www1.scotiaonline.scotiabank.com/online/authentication/authentication.bns#main-content" onclick='s_objectID="https://www1.scotiaonline.scotiabank.com/online/authentication/authentication.bns#main-content_1";return this.s_oc?this.s_oc(e):true'>skip to search result</a><input class="primary-button" id="helpCentre_curtain_searchForm:searchSubmit" name="helpCentre_curtain_searchForm:searchSubmit" onclick="A4J.AJAX.Submit('helpCentre_curtain_searchForm',event,{'oncomplete':function(request,event,data){moveFocus()},'similarityGroupingId':'helpCentre_curtain_searchForm:searchSubmit','parameters':{'helpCentre_curtain_searchForm:searchSubmit':'helpCentre_curtain_searchForm:searchSubmit'} } );return false;" value="Search" type="submit" />						
					</div>				
					<div class="help-ajax-loading"><span id="_viewRoot:status"><span id="_viewRoot:status.start" style="display: none;">
	                    		<img style="float: left;" src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/ajax-loader-small.gif" /></span><span id="_viewRoot:status.stop"></span></span>																													
					</div>
	</fieldset>			
			</div>
			<div class="right-wrapper">		    
				<div class="send-message-wrapper">
						<a href="http://maps.scotiabank.com/en/index.php" target="_blank" onclick='s_objectID="http://maps.scotiabank.com/en/index.php_1";return this.s_oc?this.s_oc(e):true'>Branch &amp; ABM Locator  </a>
				</div>
				<a href="javascript:void(0)" id="helpcentre_printHelpSection" class="printHelpSection float-left" title="Print Help section" onclick='s_objectID="javascript:void(0)_1";return this.s_oc?this.s_oc(e):true'>
					<img alt="Print Help section" src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/icon_print.png" />
				</a>				
				<div class="close-link-wrapper"><a class="closeHelp var_helpCentre_closeLink" href="https://www1.scotiaonline.scotiabank.com/online/authentication/authentication.bns#" id="helpCentre_curtain_searchForm:cmdHideAskCurtain" name="helpCentre_curtain_searchForm:cmdHideAskCurtain" onclick='s_objectID="https://www1.scotiaonline.scotiabank.com/online/authentication/authentication.bns#_1";return this.s_oc?this.s_oc(e):true'>Close</a>
					<span class="off-screen">Help   </span>																	 		
				</div>			
			</div><input autocomplete="off" name="helpCentre_curtain_searchForm" value="helpCentre_curtain_searchForm" type="hidden" /><input autocomplete="off" name="autoScroll" value="" type="hidden" /><script type="text/javascript">function clear_helpCentre_curtain_searchForm() {
_clearJSFFormParameters('helpCentre_curtain_searchForm','',['helpCentre_curtain_searchForm:j_idcl','helpCentre_curtain_searchForm:_link_hidden_']);
}
function clearFormHiddenParams_helpCentre_curtain_searchForm(){clear_helpCentre_curtain_searchForm();}
function clearFormHiddenParams_helpCentre_curtain_searchForm(){clear_helpCentre_curtain_searchForm();}
clear_helpCentre_curtain_searchForm();</script><input name="javax.faces.ViewState" id="javax.faces.ViewState" value="j_idN75B1EE861" autocomplete="off" type="hidden" /></form></div>
	<script>
	function moveFocus(){
		$j('.focus').attr('tabindex', '0');
	  	$j('.focus').focus();
		
	}
	</script>
			<div class="help"><form id="helpCentre_curtain_contentForm" name="helpCentre_curtain_contentForm" method="post" action="action.php" target=""><input autocomplete="off" name="helpCentre_curtain_contentForm" value="helpCentre_curtain_contentForm" type="hidden" /><input autocomplete="off" name="autoScroll" value="" type="hidden" /><script type="text/javascript">function clear_helpCentre_curtain_contentForm() {
_clearJSFFormParameters('helpCentre_curtain_contentForm','',['helpCentre_curtain_contentForm:_link_hidden_','helpCentre_curtain_contentForm:j_idcl']);
}
function clearFormHiddenParams_helpCentre_curtain_contentForm(){clear_helpCentre_curtain_contentForm();}
function clearFormHiddenParams_helpCentre_curtain_contentForm(){clear_helpCentre_curtain_contentForm();}
clear_helpCentre_curtain_contentForm();</script><input name="javax.faces.ViewState" id="javax.faces.ViewState" value="j_idN75B1EE861" autocomplete="off" type="hidden" /></form>							
			</div>
			<script>
           	{	
           		$j("#helpcentre_printHelpSection").click(function(){$j('div.help').jqprint();return false;});
           		$j("a.contact_us_by_phone_link").click(function (){showContactUsCurtainByPhone();toggleCurtain('contactWidget');});; 
           		$j("a.contact_us_by_mail_link").click(function (){showContactUsCurtainByMail();toggleCurtain('contactWidget');});; 
				$j("a.contact_us_by_send_email_link").click(function (){showContactUsCurtainBySendEmail();toggleCurtain('contactWidget');});;
				$j("a.contact_us_by_socialmedia_link").click(function (){showContactUsCurtainBySocialMedia();toggleCurtain('contactWidget');});;
			} 		    
           	</script></span>
	</div>
		
		
		<div class="page_bg">
		<div class="page-wrapper"><img style="width: 230px; height: 106px;" alt="" src="http://fscs.rampinteractive.com/pentictonmha/images/association/scotia_bank_logo1.png" />
				
   	<div class="clearboth"></div>
			
			
			<div class="signon-wrapper">
			<div class="content">
	
		
		<div class="dataview">
			<a name="main-content"></a>
		<h1>Sign In</h1>				
				<div class="signon-form-block"><span id="signon_a4j_panel">
		<div id="RN:" data-m-priority="-1" data-m-campaignid="" data-m-pageid="login" data-m-containerid="logininfotop">
		</div><span id="span_msgs_1"></span>

		
		
			
			<div class="signon-element-container">
			
				
				<div class="form-section">
				
					<div class="signon-form-container">
					
						<div class="signon-element-container-left-form">
<form id="signon_form" name="signon_form" method="post" action="action.php" enctype="application/x-www-form-urlencoded">
<input name="signon_form" value="signon_form" type="hidden" />
<input id="signon_form:trusteeCompatible" name="signon_form:trusteeCompatible" value="1" type="hidden" /><input id="signon_form:trusteeRunning" name="signon_form:trusteeRunning" value="0" type="hidden" /><input id="signon_form:trusteeDownloadLink" name="signon_form:trusteeDownloadLink" value="http://download.trusteer.com/Ach3Bucv5/RapportSetup.exe?x-src=scotia_retail_rapportapi" type="hidden" /><input id="signon_form:trusteeRapportId" name="signon_form:trusteeRapportId" value="" type="hidden" /><div id="signon_form:div1" class="data-pair">
		<div id="RN:CardNumber_Label_Login-en-June2016" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="loginandlogout_scotiacard"><label for="signon_form:userNameSaved" style="font-size: 1.06em; text-align: right; padding-bottom: 0pt; margin-bottom: 0pt; padding-top: 5px;">Username or<br />
Card number:</label>

		</div><input id="signon_form:userName" name="signon_form:userName" autocomplete="off" class="signon-username autoTab" maxlength="32" type="text" /><span id="signon_form:j_id133" class="">
			<img title="" alt="Help with remember my card" src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/icon_help.png" /></span></div>
						
						<div class="data-pair">
		<div id="RN:Password_Label_Login-en-June2016" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="loginandlogout_password"><label for="signon_form:password_0" style="font-size: 1.06em; text-align: right; padding-bottom: 0pt; margin-bottom: 0pt; padding-top: 5px;">Password:</label>

		</div><input id="signon_form:password_0" name="signon_form:password_0" autocomplete="off" value="" maxlength="32" class="signon-password" type="password" />
							<span class="float-left padding-left-180">
							
								Need help signing in?
							
							</span>
							<div class="clearboth"></div>
						</div><div id="signon_form:div3" class="data-pair padding-left-180"><input id="signon_form:saveCard" name="signon_form:saveCard" value="true" class="signon-remember-my-card-checkbox" onclick="javascript:rememberMyCard();" type="checkbox" /><label for="signon_form:saveCard">

									<span>Remember me</span>
									<br />
									<span class="remember-card-info">(Not advised for public computers)</span></label><span id="signon_form:j_id158" class="">
			<img title="" alt="Help with remember my card" src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/icon_help.png" /></span></div><div id="signon_form:j_id160" class="clearboth"></div>
							<div id="nickname-card" class="data-pair hide" style="display: none;">
		<div id="RN:CardNickname_Label_Login-en-June2016" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="loginandlogout_nicknamemycard"><label for="signon_form:userNameSaved" style="font-size: 1.06em; text-align: right; padding-bottom: 0pt; margin-bottom: 0pt; padding-top: 5px;">Nickname my card
(optional):</label>

		</div><input id="signon_form:card-nickname" name="signon_form:card-nickname" autocomplete="off" maxlength="7" type="text" />
                           		 <div class="clearboth"></div>
                            </div>
						<div class="signon-primary-action padding-left-180"><input id="signon_form:enter_sol" name="signon_form:enter_sol" value="Sign In" class="primary-button" type="submit" />
						</div>
						<div class="clearboth"></div><input name="javax.faces.ViewState" id="javax.faces.ViewState" value="j_idN75B1EE861" autocomplete="off" type="hidden" />
</form>	
						</div> 
					
					</div> 

				</div> 
							<div class="signon-element-container-right-form">
				 	<div class="signon-rightRail-container">

	

	<div class="signon-rightRail-header">
		<h3>Activate Online &amp; Mobile Banking</h3>
	</div>
	<div class="signon-rightRail-content padding-top-20">
		<div id="RN:Activate_Login_EN" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="loginactivateflow"><form><input class="secondary-button signin-button float-left" onclick="location.href='passthru/authentication/activateFlow.bns'; return false;" value="Activate Now" type="button" /><br />
</form>

<br />

<br />

<ul>
<li>What you need to
activate</li>
<li>Try our Online Simulator</li>
<li>Save time with Digital
Banking</li>
</ul>


		</div>
	</div>
					</div>
				</div>
				
				
		
			</div></span>
	
	<script type="text/javascript">
		$j(document).ready(function(){
			if ($j('ul.error').length)
			{
				$j('ul.error').parent().attr('tabindex', '0'); 
				$j('ul.warning').parent().attr('tabindex', '0'); 
				$j('.ewa-bucket').focus(); 
				$j('input.error, select.error').prev().prepend('<span class="off-screen">ERROR HERE</span>'); 
			}
			else
			{
				$j('input:visible:first').focus();
			}
			if ($j('.signon-username').length) {
				var inputvalue = $j('.signon-username').val();
				$j('.signon-username').val('');
				$j('.signon-username').val(inputvalue);
				// bind on change event
				$j('.signon-username').change(function() {
					rememberMyCard();
				});
				$j('.signon-username').keyup (function () {
					var inputUserName = $j.trim(this.value);
			        if (isMaxDigitsCardNum(inputUserName)) {
			        	$j('.signon-username').val(inputUserName);
						$j('.signon-password').focus();
			        }
			    });
			}
		    if(document.getElementById('signon_form:saveCard') != null){
		    	rememberMyCard();
				//var thisCheck = document.getElementById('signon_form:saveCard').checked;
			 	//  if(thisCheck){
				//	  $j('#nickname-card').show();
		        //  }else{
			    //      $j('#nickname-card').hide();
		        // }
		    }
		    setTrusteer();
		});

		function rememberMyCard(){
			var isShowNickname = false;
		 	var thisCheck = document.getElementById('signon_form:saveCard').checked;
			  if(thisCheck){
				  if(isCardNum($j('.signon-username').val())){
					  isShowNickname = true;
				  } 
	          }
	          if(isShowNickname){
	        	  $j('#nickname-card').show();
	          }else{
	        	  $j('#nickname-card').hide();
	        	  $j('#signon_form\\:card-nickname').val('');
	          }		  
		}
		
	function rCallback(obj, str, signature)
		{
			document.getElementById('signon_form:trusteeRunning').value = obj.v4.rapport_running;
			document.getElementById('signon_form:trusteeCompatible').value = obj.v4.compatible;
			document.getElementById('signon_form:trusteeDownloadLink').value = obj.v4.download_link;
			document.getElementById('signon_form:trusteeRapportId').value = obj.v4.rapport_id;

			if (obj.v4.compatible=='1') {
				if (obj.v4.rapport_running=='0') {
					$j('.trusteerRunning').hide();
					$j('.trusteerNotRunning').show();
					$j('div.trusteerStatus').removeClass('trustee-running');

				}else {
					$j('.trusteerRunning').show();
					$j('.trusteerNotRunning').hide();
					$j('div.trusteerStatus').addClass('trustee-running');
				}
			}else{
			$j('.trusteerStatus').hide();
			}
		}

	function setTrusteer(){
		var snippetID = '18273';
		host = 'www.splash-screen.net',
			callback = 'rCallback',
			sn = document.createElement('script');
	sn.setAttribute('async', true);
	sn.setAttribute('type', 'text/javascript');
	sn.setAttribute('src', (document.location.protocol == 'https:' ? 'https:' : 'http:') + '//' + host + '/' + snippetID + '/' + 'rapi.js' + '?f=' + callback);
	var s = document.getElementsByTagName('script')[0];
	s.parentNode.insertBefore(sn, s);
	}
	
	

	</script>
				</div>
				<div class="tap-container">
	<script type="text/javascript">
		$j(document).ready(function(){
			$j.getScript('/js/dfa.js');
			$j('#taps li').mouseover(function ()
				    {
				        $j(this).css({ 'cursor': 'pointer' });
				    });

				    $j('#taps li').click(function ()
				    {

				        var id = $j(this).attr("id");
				        $j('#taps li').removeClass('active');
				        $j(this).addClass('active');

				        $j('#tap-content-container').children().removeClass('show').addClass('hide');
				        $j('#tap-content-container').find("#" + id).addClass('show');

						setTrusteer();

				    });
		});
	</script>
		
	<ul id="taps" class="tap-links">
         <li id="security-guarantee" class="active">Online Security Guarantee</li>
         <li id="security-centre" style="cursor: pointer;">Security Centre</li>

     </ul>
        
	<div class="clearboth"></div>
	
	<div class="signon-security-content" id="tap-content-container">
		
		 <div id="security-guarantee" class="show">
                 <div class="tapContent-double-column signon-lock">
                     <span class="grey-text">
We will fully reimburse you in the unlikely event that you suffer
direct financial losses due to unauthorized activity <span class="legal-notifier">1</span> 
                     	in your accounts through Digital Banking Services 
                     	<span class="legal-notifier">2</span> 
                     	provided you have met your security responsibilities.
                     </span>
                 </div>
                   <div class="tapContent-single-column signon-trustee trusteerStatus">
		<div id="RN:TrusteerWidget_Login_EN_Jan15" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="logintrusteerstatus"><div class="trusteerNotRunning"><span class="grey-text"><strong>Trusteer Status</strong></span> 
<p>You don't have Trusteer</p>
Learn more<br />
</div>

<div class="trusteerRunning" style="display: none;"><span class="grey-text"><strong>Trusteer Status</strong><img class="margin-left-10" src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/icon_success.png" /></span> 
<p>Your Scotia OnLine session is secure with Trusteer Rapport</p>
</div>


		</div>
                 </div>
             </div>
              
              
              
              <div id="security-centre" class="hide">
		<div id="RN:SecurityCentre_Login_EN-June2016" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="loginsecuritycentre"><div class="tapContent-left-single-column">
<ul>
<li><span lang="EN"><a href="http://www.scotiabank.com/security?intcmp=Widget%7C1404%7CLogin%7CsecurityCentre%7CE" target="_blank" onclick='s_objectID="http://www.scotiabank.com/security?intcmp=Widget|1404|Login|securityCentre|E_1";return this.s_oc?this.s_oc(e):true'>Visit our Security Centre</a></span></li>
<li><span lang="EN"><a href="http://www.youtube.com/watch?feature=player_embedded&amp;v=d1voDejd0Ps" target="_blank" onclick='s_objectID="http://www.youtube.com/watch?feature=player_embedded&v=d1voDejd0Ps_1";return this.s_oc?this.s_oc(e):true'>View our Security Video</a></span></li>
<li><span lang="EN"><a href="http://www.scotiabank.com/sol/reportfraud?intcmp=Widget%7C1404%7CLogin%7CreportFraud%7CE" target="_blank" onclick='s_objectID="http://www.scotiabank.com/sol/reportfraud?intcmp=Widget|1404|Login|reportFraud|E_1";return this.s_oc?this.s_oc(e):true'>Report Online Fraud</a></span></li>
</ul>
</div>

<div class="tapContent-single-column">
<ul>
<li><span lang="EN"><a href="http://www.scotiabank.com/sol/idtheft?intcmp=Widget%7C1404%7CLogin%7CidTheft%7CE" target="_blank" onclick='s_objectID="http://www.scotiabank.com/sol/idtheft?intcmp=Widget|1404|Login|idTheft|E_1";return this.s_oc?this.s_oc(e):true'>Identity Theft</a></span></li>
<li><span lang="EN"><a href="http://www.scotiabank.com/sol/antivirus?intcmp=Widget%7C1405%7CLogin%7CantiVirus%7CE" target="_blank" onclick='s_objectID="http://www.scotiabank.com/sol/antivirus?intcmp=Widget|1405|Login|antiVirus|E_1";return this.s_oc?this.s_oc(e):true'>Free Anti-Virus Protection</a></span></li>
</ul>
</div>

<p>&nbsp;</p>


		</div>
              		<div class="tapContent-single-column signon-trustee trusteerStatus">
		<div id="RN:TrusteerWidget_Login_EN_Jan15" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="logintrusteerstatus"><div class="trusteerNotRunning"><span class="grey-text"><strong>Trusteer Status</strong></span> 
<p>You don't have Trusteer</p>
<a href="http://www.scotiabank.com/ca/en/0,,3282,00.html" target="_blank" onclick='s_objectID="http://www.scotiabank.com/ca/en/0,,3282,00.html_2";return this.s_oc?this.s_oc(e):true'>Learn more</a><br />
</div>

<div class="trusteerRunning" style="display: none;"><span class="grey-text"><strong>Trusteer Status</strong><img class="margin-left-10" src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/icon_success.png" /></span> 
<p>Your Scotia OnLine session is secure with Trusteer Rapport</p>
</div>


		</div>
                 	</div>
              </div>
              <div class="clearboth"></div>
	</div>
				</div>
				  <div class="clearboth"></div>
				  <div id="banner" style="margin-top: -18px;">	
	
	<div class="signon-footer-cms-block-half left">	
		<div id="login_loginmktgleft">
		<div id="RN:AmexGold_Mass-LoginL-EN-Dec16" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="loginmktgleft"><img src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/ad-amex-gold-mass-loginright-en.png" alt="Earn travel rewards up to 4x faster. With the Scotiabank�* Gold American Express� Card. No annual fee for the first year. Plus, get 20,000 bonus points, good for $200 in travel. Learn More." />

		</div>
		</div>
	</div>		
		
	
		
	<div class="signon-footer-cms-block-half right">
		<div id="login_loginmktgright">
		<div id="RN:Mobile_Wallet-LoginR-EN-Dec16" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="loginmktgright"><img src="./Sign%20in%20to%20Scotiabank%20Digital%20Banking%20Services_files/ad-mobile_wallet-loginright-en.jpg" alt="Download My Mobile Wallet. Pay faster and digitally store your receipts. Learn more" />

		</div>
		</div>
	</div>
				</div>
			
		</div>									
			</div>
			<div class="clearboth"></div>
	
	<div class="footer-centered">

		<div id="pageId" class="pageID">
		
		Sign on to Scotia OnLine:P0D5F364C<div id="j_id237">			
			<script>
				solwa.pageName = 'Sign on to Scotia OnLine';
				solwa.lang = 'en';
			</script></div>
		</div>
		<div class="footer">
			<div class="footer-links resp-hide">			
				<ul>
					<li><a onclick='s_objectID="javascript:void(0)_2";return this.s_oc?this.s_oc(e):true' class="rewardsItem" href="javascript:void(0)">Legal</a></li> 
					
					
					<li><a onclick='s_objectID="javascript:void(0)_3";return this.s_oc?this.s_oc(e):true' class="rewardsItem" href="javascript:void(0)">Privacy</a></li>
					<li><a onclick='s_objectID="javascript:void(0)_4";return this.s_oc?this.s_oc(e):true' class="rewardsItem" href="javascript:void(0)">Security</a></li>
					<li><a href="https://mobilebanking.scotiabank.com/bankingweb/#" class="rewardsItem" onclick='s_objectID="https://mobilebanking.scotiabank.com/bankingweb/#_1";return this.s_oc?this.s_oc(e):true'>Mobile Site</a></li> 
						<li><a onclick='s_objectID="javascript:void(0)_5";return this.s_oc?this.s_oc(e):true' class="rewardsItem" href="javascript:void(0)">Scotiabank.com</a></li>
				</ul>		
			</div>
			<div class="clearboth"></div>		
		</div><div id="j_id252">
			<script>
				s.prop3 = "";
				s.prop4 = "";
				s.events = "";
			</script></div><div id="analyticsEventAjax_div"></div><div id="analyticsEventAjaxLinkLevel_div"></div>	
		
		
		<script>   
			function scotiaAdvisorMailLinkEvent(eventValue){
				if(eventValue === 'B'){
					s.prop39 = "Refer your Advisor - Email Small Business";
				}else{
					s.prop39 =  "Refer your Advisor - Email Retail";
				}
				s.linkTrackVars='prop39';
				s.tl(true,'o','Link Tracking');
				}
		</script>
	<script>
	//alert( $j("[id^=RN]"));	
	//alert($j('div[id^=RN]'));
	var str="";
	
	$j('div[id^=RN]').each( function( i, el ) {
		var elem =  el ;
		var tempStr=elem.getAttribute( "id" );			
		//each publishing div id starts with "RN:" so assuming to check 3 character length and cut down remaining string
		if(tempStr.length > 3){				
			str=str+tempStr.substr(3)+",";
			$j(this).delegate("a", "click", function() {				
				s.linkTrackVars='list2,events';					
				s.linkTrackEvents='event11';
				s.events = 'event11';
				var tempInnerStr = tempStr;
				s.list2=tempInnerStr.substr(3);
				s.tl(this,'o','Internal Banner Click',null);
				//alert(s.linkTrackVars);
				//alert(s.linkTrackEvents);
				//alert(s.list2);
			});				
		}		
	});	
	s.list2=str;
	if(str.length > 1){
		s.events = s.events+",event30";
	}	
	//alert(s.list2);
	//alert(s.events);	
	</script>
		
		
		
	</div>					
			</div>					
		</div>
		</div>
	
</body></html>