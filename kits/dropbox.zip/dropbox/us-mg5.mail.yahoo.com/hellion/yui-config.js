'use strict';

var yuiComboBase = MEMBERSHIP.yuiComboBase,
  yuiRoot = MEMBERSHIP.yuiRoot,

  comboBase = MEMBERSHIP.comboBase,
  combine = MEMBERSHIP.combine,
  assetsPath = MEMBERSHIP.assetsPath,

  YUI_config = {
    combine: combine,
    comboBase: yuiComboBase,
    root: yuiRoot,
    groups: {}
  };
