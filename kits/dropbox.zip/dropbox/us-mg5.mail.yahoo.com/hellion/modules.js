'use strict';

var yuiComboBase = MEMBERSHIP.yuiComboBase,
  yuiRoot = MEMBERSHIP.yuiRoot,

  comboBase = MEMBERSHIP.comboBase,
  combine = MEMBERSHIP.combine,
  assetsPath = MEMBERSHIP.assetsPath,

  YUI_config = {
    combine: combine,
    comboBase: yuiComboBase,
    root: yuiRoot,
    groups: {}
  };

'use strict';

/*global YUI_config, combine, assetsPath, comboBase */

var groups = YUI_config.groups;

groups.validator_change_password = {
  combine: combine,
  root: assetsPath + 'change-password/js/validator/',
  base: comboBase + assetsPath + 'change-password/js/validator/',
  comboBase: comboBase,
  'modules': {
    'change-password-form-configs' : {
      path: 'validation-configs/forms/change-password-form-configs.js',
      requires: ['forms', 'fields']
    },

    'fields-validation-configs' : {
      path: 'validation-configs/fields-validation-configs.js',
      requires: ['fields', 'event-valuechange', 'password-configs', 'password-confirm-configs']
    },
    'forms-validation-configs' : {
      path: 'validation-configs/forms-validation-configs.js',
      requires: ['forms', 'change-password-form-configs']
    },

    'fields' : {
      path: 'validation-targets/fields.js'
    },
    'forms' : {
      path: 'validation-targets/forms.js'
    }
  }
};

'use strict';

/*global YUI_config, combine, assetsPath, comboBase */

var groups = YUI_config.groups;

groups.placeholder = {
  combine: combine,
  root: assetsPath + 'polyfill/',
  base: comboBase + assetsPath + 'polyfill/',
  comboBase: comboBase,
  'modules': {
    'placeholder' : {
      path: 'placeholder/js/placeholder.js',
      requires : ['node', 'event-move']
    },
    'autofocus' : {
      path: 'autofocus/js/autofocus.js',
      requires : ['node']
    },
    'secondary-form-submit' : {
      path: 'secondary-form-submit/js/secondary-form-submit.js',
      requires : ['node', 'event-move', 'node-event-simulate']
    }
  }
};

'use strict';

/*global YUI_config, combine, assetsPath, comboBase */

var groups = YUI_config.groups;

groups.validator = {
  combine: combine,
  root: assetsPath + 'validator/js/',
  base: comboBase + assetsPath + 'validator/js/',
  comboBase: comboBase,
  'modules': {
    'captcha-configs' : {
      path: 'validation-configs/fields/captcha-configs.js',
      requires: ['fields', 'messages']
    },

    'code-blocks-configs' : {
      path: 'validation-configs/fields/code-blocks-configs.js',
      requires: ['fields', 'messages', 'validation-regex']
    },
    'code-configs' : {
      path: 'validation-configs/fields/code-configs.js',
      requires: ['fields', 'messages', 'validation-regex', 'app-specific-constraint']
    },

    'dob-day-configs' : {
      path: 'validation-configs/fields/dob-day-configs.js',
      requires: ['fields', 'messages', 'validation-regex', 'app-specific-constraint']
    },
    'dob-month-configs' : {
      path: 'validation-configs/fields/dob-month-configs.js',
      requires: ['fields', 'messages', 'validation-regex', 'app-specific-constraint']
    },
    'dob-year-configs' : {
      path: 'validation-configs/fields/dob-year-configs.js',
      requires: ['fields', 'messages', 'validation-regex', 'app-specific-constraint']
    },

    'gender-configs' : {
      path: 'validation-configs/fields/gender-configs.js',
      requires: ['fields', 'messages']
    },

    'mobile-number-configs' : {
      path: 'validation-configs/fields/mobile-number-configs.js',
      requires: ['fields', 'messages', 'validation-regex', 'app-specific-constraint']
    },

    'name-configs' : {
      path: 'validation-configs/fields/name-configs.js',
      requires: ['fields', 'messages', 'validation-regex']
    },
    'name-first-configs' : {
      path: 'validation-configs/fields/name-first-configs.js',
      requires: ['fields', 'messages', 'validation-regex']
    },
    'name-last-configs' : {
      path: 'validation-configs/fields/name-last-configs.js',
      requires: ['fields', 'messages', 'validation-regex']
    },

    'password-configs' : {
      path: 'validation-configs/fields/password-configs.js',
      requires: ['fields', 'messages', 'app-specific-constraint']
    },
    'password-confirm-configs' : {
      path: 'validation-configs/fields/password-confirm-configs.js',
      requires: ['fields', 'messages']
    },
    'password-current-configs' : {
      path: 'validation-configs/fields/password-current-configs.js',
      requires: ['fields', 'messages']
    },

    'phone-number-configs' : {
      path: 'validation-configs/fields/phone-number-configs.js',
      requires: ['fields', 'messages', 'validation-regex', 'app-specific-constraint']
    },
    'phone-number-opt-configs' : {
      path: 'validation-configs/fields/opt-phone-number-opt-configs.js',
      requires: ['fields', 'messages', 'validation-regex', 'app-specific-constraint']
    },

    'relationship-configs' : {
      path: 'validation-configs/fields/relationship-configs.js',
      requires: ['fields', 'messages', 'validation-regex']
    },

    'user-name-configs' : {
      path: 'validation-configs/fields/user-name-configs.js',
      requires: ['fields', 'messages', 'validation-regex', 'app-specific-constraint']
    },

    'validation-regex' : {
      path: 'validation-constants/validation-regex.js'
    },
    'validation-result-statuses' : {
      path: 'validation-constants/validation-result-statuses.js'
    },

    'show-hide-message-container-controller' : {
      path: 'validator-add-ons/show-hide-message-container-controller.js'
    },

    'populate-validation-messages' : {
      path: 'validator-add-ons/populate-validation-messages.js'
    },

    'validation-effects' : {
      path: 'validation-effects.js',
      requires: ['node']
    },
    'validation-functions' : {
      path: 'validation-functions.js',
      requires: ['node', 'validation-result-statuses']
    },
    'validation-controller' : {
      path: 'validation-controller.js',
      requires: ['node', 'node-event-simulate', 'event-move', 'fields-validation-configs', 'forms-validation-configs', 'validation-functions', 'validation-result-statuses', 'validation-effects']
    },
    'validator' : {
      path: 'validator.js',
      requires: ['validation-controller', 'show-hide-message-container-controller', 'populate-validation-messages']
    }
  }
};

'use strict';

/*global YUI_config, combine, assetsPath, comboBase */

var groups = YUI_config.groups;

groups.password_meter = {
  combine: combine,
  root: assetsPath + 'widgets/password-meter/',
  base: comboBase + assetsPath + 'widgets/password-meter/',
  comboBase: comboBase,
  'modules': {
    'password-meter-css' : {
      path: 'css/password-meter.css',
      type : 'css'
    },

    'password-meter' : {
      path: 'js/password-meter.js',
      requires : ['node', 'event-valuechange', 'fields', 'password-meter-css']
    }
  }
};

'use strict';

/*global YUI_config, combine, assetsPath, comboBase */

var groups = YUI_config.groups;

groups.toggle_password_mask = {
  combine: combine,
  root: assetsPath + 'widgets/toggle-password-mask/',
  base: comboBase + assetsPath + 'widgets/toggle-password-mask/',
  comboBase: comboBase,
  'modules': {
    'toggle-password-mask-ltr-css' : {
      path: 'css/toggle-password-mask-ltr.css',
      type : 'css'
    },

    'toggle-password-mask-rtl-css' : {
      path: 'css/toggle-password-mask-rtl.css',
      type : 'css'
    },

    'toggle-password-mask' : {
      path: 'js/toggle-password-mask.js',
      requires : ['node', 'messages']
    }
  }
};
