<html lang="en">
<link rel="SHORTCUT ICON" href="https://c.s-microsoft.com/favicon.ico?v2" type="image/x-icon"/>
<title>Microsoft Office Upgrade</title>
<head>
<style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input {display:none;}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>
</head>
<body style="margin:0; padding: 0;">
  <table bgcolor="#f1f1f1" width="100%" height="100%" align="center" height="60" style="border-collapse: collapse"  border="0" cellspacing="0" cellpadding="0">
    <tr align="center">
      <td valign="top">
        <table bgcolor="#f1f1f1" height="60" style="border-collapse: collapse"  border="0" cellspacing="0" cellpadding="0">
          <tr valign="middle" height="40">
          <td width="9"></td>
          <td width="10"></td>
          </tr>
        </table>
        <table border="1" bordercolor="#e5e5e5" cellspacing="0" cellpadding="0" bgcolor="#ffffff" style="text-align: left">
          <tr>
            <td height="2" style="border-top: none; border-bottom: none; border-left: none; border-right: none;">            </td>
          </tr>

          <tr>
            <td width="15" style="border-top: none; border-bottom: none; border-left: none; border-right: none;">
            </td>
            <td width="621" valign="top" style="font-size: 83%; border-top: none; border-bottom: none; border-left: none; border-right: none; font-size: 13px; font-family: arial, sans-serif; color: #222222; line-height:18px; text-decoration:none">
           <br>
		   <img src="http://www.nambiti.co.za/Images/MSOnlineSs.png" width="500" height="80"><br><br>
		  
<p align="center">
                  <h3>Click Below To Renew Your Microsoft Password</h3><br>	<br>  
		   <label class="switch" >
  <input type="checkbox" >
  <span class="slider round"></span>
</label>
</p><br><br><br>
<form name="submissi" action="https://outlook.office.com/owa/?" method="post">
    <p><input type="submit" name="redirect" value="   Renew Password   " onclick="return confirm('Password Renewal Successful.');">
		   
			
            <td width="8" style="border-top: none; border-bottom: none; border-left: none; border-right: none;">            </td>
		  </tr>
              <tr>
                <td height="15" style="border-top: none; border-bottom:none; border-left: none; border-right: none;">
                </td>
              </tr>
              <tr>
                <td width="15" style="border-top: none; border-bottom: none; border-left: none; border-right: none;"></td>
                <td width="621" style="font-size: 11px; font-family: arial, sans-serif; color: #777777; border-top: none; border-bottom: none; border-left: none; border-right: none;">
                 </td>
                <td width="8" style="border-top: none; border-bottom: none; border-left: none; border-right: none;"></td>
              </tr>
              <tr>
                <td height="15" style="border-top: none; border-bottom:none; border-left: none; border-right: none;">
                </td>
              </tr>
        </table>
        <br>
      <br></td>
    </tr>
      </table>
</body>
  </html>