<?

$to = "your-email-here";

$red = "https://www.linkedin.com/";

?>